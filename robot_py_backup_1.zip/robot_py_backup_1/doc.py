#!/usr/bin/env python3
import json
import computer as pc

dataSensor = {"state_sensor": True}
dataActuator = {"actuator_data":"A"}
    
pc.writeData("sensor_goal.json", dataSensor)
pc.writeData("actuator_goal.json", dataActuator)
