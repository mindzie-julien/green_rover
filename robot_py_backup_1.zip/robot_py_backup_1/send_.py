from smbus2 import SMBus, i2c_msg
import time
import json

MOTOR_ADDRESS_1 = 0x8
SENSOR_ADDRESS_2 = 0x9
ASK_FOR_LENGTH = 0x0
ASK_FOR_DATA = 0x1
I2C_LENGTH_LIMIT = 32
SLEEP_TIME = 0

with SMBus(1) as bus:

    time.sleep(SLEEP_TIME)
    def ask_data_lenght(address):
        # Ask for length response
        write = i2c_msg.write(address, [ASK_FOR_LENGTH])
        bus.i2c_rdwr(write)

        time.sleep(SLEEP_TIME)

        # Answer
        read = i2c_msg.read(address, 1)
        bus.i2c_rdwr(read)
        responseLength = list(read)[0]

        return responseLength

    time.sleep(SLEEP_TIME)


    def send_json(data, address):
        # Envoie des données au format JSON à l'esclave
        json_data = json.dumps(data)

        # Envoi du JSON à l'Arduino par blocs
        for i in range(0, len(json_data), I2C_LENGTH_LIMIT):
            write_data = [ord(c) for c in json_data[i:i+I2C_LENGTH_LIMIT]]
            write = i2c_msg.write(address, [ASK_FOR_DATA] + write_data)
            bus.i2c_rdwr(write)
        print("json data sent !")


"""
    TEST DU CODE:

    lenght = ask_data_lenght(MOTOR_ADDRESS_1)
    send_json('{"message": "Hello from Raspberry Pi!"}', MOTOR_ADDRESS_1)
    print("")
    print("json data sent !")
"""
