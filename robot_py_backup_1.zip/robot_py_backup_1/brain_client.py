#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from rclpy.action import ActionClient
import action_class as actions
import computer as pc
import time
import threading
import queue
import json
from motion_server import MotionThreadServer
from actuator_server import ActuatorThreadServer
from sensor_server import SensorThreadServer
import brain

def main(input_motion_queue, output_motion_queue):
    
    brain.main(input_motion_queue, output_motion_queue)
    pass

class MotionThreadClient(threading.Thread):
    def __init__(self, brainActionClient):
        threading.Thread.__init__(self)
        self.brainActionClient = brainActionClient
        
        brainActionClient.get_logger().info('motion_client online')
    
    def run(self):
        #print("motion")
        
        while True:
            data = pc.readData("motion_goal.json")
            if bool(data):
                
                
                
                target = data["target"]
                order = data["order"]
                emergency_stop = False
                self.brainActionClient.send_motion_goal(target, order, emergency_stop)
                print("test node")
                rclpy.spin_once(self.brainActionClient)
            time.sleep(15)    
        
        #print("motion")
        
class SensorThreadClient(threading.Thread):
    def __init__(self, brainActionClient):
        threading.Thread.__init__(self)
        self.brainActionClient = brainActionClient
        
        brainActionClient.get_logger().info('sensor_client online')
        
    def run(self):
        #print("sensor")
        while True:
            data = pc.readData("sensor_goal.json")
            if bool(data):
                
                
                
                sensor_state = data["state_sensor"]
                
                self.brainActionClient.send_sensor_goal(sensor_state)
                print("test node")
                rclpy.spin(self.brainActionClient)
            time.sleep(0.01)
        
        
       
        #print("sensor")

class ActuatorThreadClient(threading.Thread):
    def __init__(self, brainActionClient):
        threading.Thread.__init__(self)
        self.brainActionClient = brainActionClient
        
        brainActionClient.get_logger().info('actuator_client online')
        
    def run(self):
               
        while True:
             data = pc.readData("actuator_goal.json")
             if bool(data):
                
                 
                 actuator_data = data["actuator_data"]
                
                 self.brainActionClient.send_actuator_goal(actuator_data)
                 print("test node")
                 rclpy.spin(self.brainActionClient)
             time.sleep(0.01)
        #print("actuator")
        
"""class BrainThreadClient(threading.Thread):        
    def __init__(self):
        threading.Thread.__init__(self)
        

    def run(self):
        #rclpy.init()
        brain_action_client = actions.BrainActionClient()
        brain_action_client.get_logger().info('brain_client online')
    #motionThreadClient = MotionThreadClient(brain_action_client, input_motion_queue, output_motion_queue)
    #sensorThreadClient = SensorThreadClient(brain_action_client, output_sensor_queue)
        actuatorThreadClient = ActuatorThreadClient(brain_action_client, )    
        time.sleep(1)
    
    #motionThreadClient.start()
    #sensorThreadClient.start()
        actuatorThreadClient.start()"""



if __name__ == '__main__':
    
    
    input_motion_queue = queue.Queue()
    input_actuator_queue = queue.Queue()
    output_motion_queue = queue.Queue()
    output_sensor_queue = queue.Queue()
    
    """actuator_server.main(input_actuator_queue)
    sensor_server.main(output_sensor_queue)
    motion_server.main(input_motion_queue, output_motion_queue)#, input_actuator_queue, output_sensor_queue)"""
    ######################################################################################################################
    ######################################     à vérifier      ###########################################################
    ######################################################################################################################
    #
    #
    
    ########################################################################################################################
    #
    #
    
    time.sleep(1)
    
    brainThreadClient = BrainThreadClient(input_actuator_queue)
    brainThreadClient.start()
    
    main(input_motion_queue, output_motion_queue)
    
    print("end")
    time.sleep(60)
    #motionThreadClient.join()
    #sensorThreadClient.join()
    #actuatorThreadClient.join()
