#!/usr/bin/env python3
import subprocess
subprocess.call(["python3", "doc.py"])
print("doc")
subprocess.call(["python3", "init_sensor_server.py"])
print("init_sensor_server")
subprocess.call(["python3", "init_motion_server.py"])
print("init_motion_server")
subprocess.call(["python3", "init_actuator_server.py"])
print("init_actuator_server")
subprocess.call(["python3", "brain.py"])
print("brain")
subprocess.call(["python3", "init_actuator_client.py"])
print("init_actuator_client")
subprocess.call(["python3", "init_motion_client.py"])
print("init_motion_client")
subprocess.call(["python3", "init_sensor_client.py"])
print("init_sensor_client")

