#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from rclpy.action import ActionClient
import action_class as actions
import time
import threading
import queue
import json
import motion_server
import actuator_server
import sensor_server
import brain

class MotionThreadServer(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        
        
    def run(self):
        #rclpy.init()
        motion_action_server = actions.MotionActionServer()
        motion_action_server.get_logger().info('motion_server online')
        
        rclpy.spin(motion_action_server)

"""def main(input_motion_queue, output_motion_queue):
    #rclpy.init(None)
    
    motion_action_server = actions.MotionActionServer(input_motion_queue, output_motion_queue)
    motion_action_server.get_logger().info('motion_server online')
    rclpy.spin(motion_action_server)"""

if __name__ == '__main__':
    #main()
    print("run brain_client.py")
