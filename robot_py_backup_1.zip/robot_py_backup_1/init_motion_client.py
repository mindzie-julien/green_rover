#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from rclpy.action import ActionClient
import action_class as actions
import time
import threading
import queue
import json
from brain_client import MotionThreadClient
from action_class import BrainActionClient

if __name__ == '__main__':
    rclpy.init()
    brain_action_client = actions.BrainActionClient()
    motionThreadClient = MotionThreadClient(brain_action_client)
    motionThreadClient.start()
    
