import pigpio
import time

# Créer une instance de pigpio
pi = pigpio.pi('soft', 8888)

# Définir le numéro de GPIO
gpio_num = 16

# Configurer le GPIO comme entrée
pi.set_mode(gpio_num, pigpio.INPUT)

# Activer la résistance de pull-up interne
pi.set_pull_up_down(gpio_num, pigpio.PUD_UP)

# Définir une fonction de rappel pour gérer les interruptions
def my_callback(gpio, level, tick):
    print("GPIO {} est passé au niveau {} à {}".format(gpio, level, tick))

# Configurer l'interruption pour les deux bords (rising et falling)
cb = pi.callback(gpio_num, pigpio.EITHER_EDGE, my_callback)

try:
    # Boucle infinie pour attendre les interruptions
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    # Désactiver la fonction de rappel avant de quitter
    cb.cancel()

# Terminer la session pigpio
pi.stop()

