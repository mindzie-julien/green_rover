#!usr/bin/env python3
from smbus2 import SMBus, i2c_msg
import smbus2
import threading
import time
import json
import computer as pc


I2C_SLAVE_ADDR_SENSOR = 0x9
I2C_SLAVE_ADDR_ACTUATOR = 0x7
I2C_SLAVE_ADDR_MOTION = 0x8
ASK_FOR_LENGTH = 0x0
ASK_FOR_DATA = 0x1
I2C_LENGTH_LIMIT = 32
SLEEP_TIME = 0.05

distance = 0

class MotionThreadGet(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        
    
    def run(self):
        main()



    
def ask_data_lenght():
    bus_ = SMBus(1)
    # Ask for length response
    #bus_ = smbus2.SMBus(1)
    write = i2c_msg.write(I2C_SLAVE_ADDR_MOTION, [ASK_FOR_LENGTH])
    bus_.i2c_rdwr(write)
        
    time.sleep(SLEEP_TIME)

    # Answer
    read = i2c_msg.read(I2C_SLAVE_ADDR_MOTION, 1)
    
    bus_.i2c_rdwr(read)
    responseLength = list(read)[0]
    print(responseLength)
    return responseLength


def receive_json():
# Ask for data reponse
    bus = SMBus(1)
    #bus = smbus2.SMBus(1)
    responseLength = ask_data_lenght()
    write = i2c_msg.write(I2C_SLAVE_ADDR_MOTION, [ASK_FOR_DATA])
    bus.i2c_rdwr(write)

    time.sleep(SLEEP_TIME)

    response = str()

    # Answer: Iterate over I2C_LENGTH_LIMIT bytes blocks, plus last [0,I2C_LENGTH_LIMIT] block
    for responseIndex in range(0, (responseLength // I2C_LENGTH_LIMIT) + 1, 1):
        read = i2c_msg.read( \
            I2C_SLAVE_ADDR_MOTION, \
            I2C_LENGTH_LIMIT if (responseIndex != (responseLength // I2C_LENGTH_LIMIT)) else (responseLength % I2C_LENGTH_LIMIT))
        bus.i2c_rdwr(read)
        response +=  "".join([chr(i) for i in list(read)])

    parsedJson = json.loads(response)
    return parsedJson
    

    
def main():
    
    while True:
        try:
            time.sleep(SLEEP_TIME )
            #reception des données du déplacement
            data = {}
            data = receive_json()
            if bool(data):
                #pc.setDataToFile("motionData.json", data)
                print(data)
                pass
            #reception des données des capteurs
            #data = {}
            #data = receive_json(I2C_SLAVE_ADDR_SENSOR)
            if not bool(data):
                #pc.setDataToFile("sensorData.json", data)
                #pc.setDataToFile("motion_sensorData.json", data)
                print("not bool")
                print(data)
                pass
        except json.decoder.JSONDecodeError:
            time.sleep(1)
            print("decode error")
        except OSError:
             time.sleep(1)
             print("os error")

if __name__ == '__main__':
    #main()
    
    
    #lenght = ask_data_lenght()
    #print("test")
    response = receive_json()
    print("Length: {0}".format(lenght))
    print("Response: {0}".format(response))
    print(json.dumps(response, indent = 4))
    print(response)    
