#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from rclpy.action import ActionClient
import action_class as actions
import time
import threading
import queue
import json
from motion_server import MotionThreadServer

if __name__ == '__main__':
    rclpy.init()
    motionThreadServer = MotionThreadServer()
    motionThreadServer.start()
    
