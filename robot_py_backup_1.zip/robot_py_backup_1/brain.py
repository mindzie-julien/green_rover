#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import action_class as actions
import time
import threading

import json
import computer as pc
from send import MotionThreadSend
from get import MotionThreadGet

def main():
    # démarrage de la lecture et écriture des données du systéme
    motionThreadSend = MotionThreadSend()
    motionThreadGet = MotionThreadGet()
    #motionThreadSend.start()
    #motionThreadGet.start()
    #
    strategy = pc.getDataFromFile("strategy.json")
    dataCoordAreaJson = pc.getDataFromFile("coordinate_area.json")
    
    
    for area, action in strategy.items():
        #dataCoordAreaJson = pc.getDataFromFile("coordinate_area.json")
        areaCoord = dataCoordAreaJson.get(area)
        speed = pc.selectSpeed(areaCoord)
        endPointKey = pc.selectLastTagRoute(area)
        
        path = pc.traceRoute(endPointKey)
        path.append(area)
        for i in range(len(path) -1):
            #ajouter le code pour les actions
            data = {}
            data["target"] = path[i]
            data["order"] = speed
            
            jsonData = json.dumps(data)
            pc.writeData("motion_goal.json", data)
            time.sleep(15)  
            """while not pc.reachedPosition( dataCoordAreaJson[ path[i] ] ):
                print("test")
                time.sleep(0.5)"""#todo a verifier mais recalcule de la vitesse
            
        data = {}   
        data["target"] = path[-1]
        data["order"] = speed#au moin la pour la vitesse
         
        jsonData = json.dumps(data)
        pc.writeData("motion_goal.json", data)
        """while not pc.reachedPosition(path[i]):
            time.sleep(0.01)"""
            
if __name__ == '__main__':
    main()          
            
    

