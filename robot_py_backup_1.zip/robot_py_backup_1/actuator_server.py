#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from rclpy.action import ActionClient
import action_class as actions
import time
import threading
import queue
import json
import motion_server
import actuator_server
import sensor_server
import brain

class ActuatorThreadServer(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        
        
    def run(self):
        #rclpy.init()
        actuator_action_server = actions.ActuatorActionServer()
        actuator_action_server.get_logger().info('actuator_server online')
        
        rclpy.spin(actuator_action_server)

"""def main(input_actuator_queue):
    #rclpy.init()
    
    actuator_action_server = actions.ActuatorActionServer(input_actuator_queue)
    actuator_action_server.get_logger().info('actuator_server online')
    rclpy.spin(actuator_action_server)"""
    
if __name__ == '__main__':
    #main()
    print("run brain_client.py")
