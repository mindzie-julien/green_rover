import RPi.GPIO as GPIO
import time
import subprocess
# Utiliser la numérotation BCM pour les GPIO
GPIO.setmode(GPIO.BCM)

# Définir le numéro de GPIO
gpio_num = 16
launchBoolean = True


# Configurer le GPIO comme entrée en mode pull-up
GPIO.setup(gpio_num, GPIO.IN, pull_up_down=GPIO.PUD_UP)

# Définir une fonction de rappel pour gérer les interruptions
def my_callback(channel):
    global launchBoolean
    launchBoolean = False
    print("go")

# Configurer l'interruption pour les deux bords (rising et falling)
GPIO.add_event_detect(gpio_num, GPIO.BOTH, callback=my_callback, bouncetime=2000)

try:
    # Boucle infinie pour attendre les interruptions
    while launchBoolean:
        time.sleep(1)
        #print("do")
    print("go")
    #subprocess.call(["bash", "start.sh])
except KeyboardInterrupt:
    # Nettoyer les ressources GPIO avant de quitter
    GPIO.cleanup()


