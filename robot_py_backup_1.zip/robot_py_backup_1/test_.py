import get__ as get

if __name__ == '__main__':    

    lenght = get.ask_data_lenght()
    response = get.receive_json()
    print("Length: {0}".format(lenght))
    print("Response: {0}".format(response))
    print(json.dumps(response, indent = 4))
    print(response)
