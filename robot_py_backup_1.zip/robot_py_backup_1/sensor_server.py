#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from rclpy.action import ActionClient
import action_class as actions
import time
import threading
import queue
import json
import motion_server
import actuator_server
import sensor_server
import brain

class SensorThreadServer(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        
        
    def run(self):
        #rclpy.init()
        sensor_action_server = actions.SensorActionServer()
        sensor_action_server.get_logger().info('sensor_server online')
        rclpy.spin(sensor_action_server)


"""def main(output_sensor_queue):
    #rclpy.init(None)

    sensor_action_server = actions.SensorActionServer(output_sensor_queue)
    sensor_action_server.get_logger().info('sensor_server online')
    rclpy.spin(sensor_action_server) """

if __name__ == '__main__':
    #main()
    print("run brain_client.py")
