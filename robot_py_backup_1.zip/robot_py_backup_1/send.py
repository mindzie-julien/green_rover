#!usr/bin/env python3
from smbus2 import SMBus, i2c_msg
from pyi2c import I2C
import threading
import time
import json
import computer as pc

I2C_SLAVE_ADDR_SENSOR = 0x9
I2C_SLAVE_ADDR_ACTUATOR = 0x7
I2C_SLAVE_ADDR_MOTION = 0x8
ASK_FOR_LENGTH = 0x0
ASK_FOR_DATA = 0x1
I2C_LENGTH_LIMIT = 32 # attention pour la taille de la donnée ne peut pas exceder 32 caractères sinon message couper par envoi
SLEEP_TIME = 0.1
i2c = I2C(1)

class MotionThreadSend(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        
    
    def run(self):
        main()
        

            


    
def ask_data_lenght(I2C_SLAVE_ADDR):
    bus = SMBus(1)
   # Ask for length response
    write = i2c_msg.write(I2C_SLAVE_ADDR, [ASK_FOR_LENGTH])
    bus.i2c_rdwr(write)
    time.sleep(SLEEP_TIME)

    # Answer
    read = i2c_msg.read(I2C_SLAVE_ADDR, 1)
    bus.i2c_rdwr(read)
    responseLength = list(read)[0]

    return responseLength



def send_json(data, I2C_SLAVE_ADDR):
    try:
        bus = SMBus(1)
    # Envoie des données au format JSON à l'esclave
        json_data = json.dumps(data)

    # Envoi du JSON à l'Arduino par blocs
        for i in range(0, len(json_data), I2C_LENGTH_LIMIT):
            write_data = [ord(c) for c in json_data[i:i+I2C_LENGTH_LIMIT]]
            write = i2c_msg.write(I2C_SLAVE_ADDR, [ASK_FOR_DATA] + write_data)
            bus.i2c_rdwr(write)
    except IOError:
        bus.close()
        time.sleep(0.01)
        bus = SMBus(1)
    
def main():
    
    while True:
    
        time.sleep(SLEEP_TIME)
        
        data = {"t": 1}
        json_data = json.dumps(data)
        #i2c.write(I2C_SLAVE_ADDR_MOTION, json_data)
        time.sleep(SLEEP_TIME)
        t = i2c.read(I2C_SLAVE_ADDR_MOTION)
        print(t)
        #send_json(data, I2C_SLAVE_ADDR_MOTION)
        """motionCommands = pc.readData("motionCommands.json")
        if bool(motionCommands):
            dataMotion = motionCommands
            data["motion"] = dataMotion
              
            send_json(data, I2C_SLAVE_ADDR_MOTION)
        
        data = {}
        actuatorCommands = pc.readData("actuatorCommands.json")
        if bool(actuatorCommands):
            dataActuator = actuatorCommands
            data["actuator"] = dataActuator
            
            send_json(data, I2C_SLAVE_ADDR_ACTUATOR)"""
    
if __name__ == '__main__':
    main()
	
    
