// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from data_flow:msg/HandlingCommandsData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__HANDLING_COMMANDS_DATA__STRUCT_H_
#define DATA_FLOW__MSG__DETAIL__HANDLING_COMMANDS_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/HandlingCommandsData in the package data_flow.
typedef struct data_flow__msg__HandlingCommandsData
{
  uint8_t actuator_pliers_forward[2];
  uint8_t actuator_pliers_backward[2];
  uint8_t actuator_solar_panel_forward;
  uint8_t actuator_solar_panel_backward;
  uint8_t actuator_level_hand_forward;
  uint8_t actuator_level_hand_backward;
} data_flow__msg__HandlingCommandsData;

// Struct for a sequence of data_flow__msg__HandlingCommandsData.
typedef struct data_flow__msg__HandlingCommandsData__Sequence
{
  data_flow__msg__HandlingCommandsData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__msg__HandlingCommandsData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DATA_FLOW__MSG__DETAIL__HANDLING_COMMANDS_DATA__STRUCT_H_
