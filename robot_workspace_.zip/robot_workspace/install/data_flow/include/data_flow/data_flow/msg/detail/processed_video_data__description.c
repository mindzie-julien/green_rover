// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from data_flow:msg/ProcessedVideoData.idl
// generated code does not contain a copyright notice

#include "data_flow/msg/detail/processed_video_data__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_data_flow
const rosidl_type_hash_t *
data_flow__msg__ProcessedVideoData__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xde, 0xb7, 0xb1, 0x6b, 0x8d, 0x2d, 0xa5, 0x67,
      0xc2, 0x76, 0x8a, 0x4a, 0x28, 0x30, 0x6d, 0xdc,
      0x96, 0xb3, 0xc8, 0x75, 0xbe, 0x6f, 0x22, 0x5b,
      0x60, 0x90, 0xd6, 0x99, 0xa9, 0x75, 0x6c, 0xbb,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char data_flow__msg__ProcessedVideoData__TYPE_NAME[] = "data_flow/msg/ProcessedVideoData";

// Define type names, field names, and default values
static char data_flow__msg__ProcessedVideoData__FIELD_NAME__target_deviation_pourcentage[] = "target_deviation_pourcentage";
static char data_flow__msg__ProcessedVideoData__FIELD_NAME__target_detection[] = "target_detection";
static char data_flow__msg__ProcessedVideoData__FIELD_NAME__target_navigation_detection[] = "target_navigation_detection";

static rosidl_runtime_c__type_description__Field data_flow__msg__ProcessedVideoData__FIELDS[] = {
  {
    {data_flow__msg__ProcessedVideoData__FIELD_NAME__target_deviation_pourcentage, 28, 28},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__ProcessedVideoData__FIELD_NAME__target_detection, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__ProcessedVideoData__FIELD_NAME__target_navigation_detection, 27, 27},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
data_flow__msg__ProcessedVideoData__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {data_flow__msg__ProcessedVideoData__TYPE_NAME, 32, 32},
      {data_flow__msg__ProcessedVideoData__FIELDS, 3, 3},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "string SMALL_BLUE_AREA =\"sba\"\n"
  "string LARGE_BLUE_AREA =\"lba\"\n"
  "string SMALL_YELLOW_AREA =\"sya\"\n"
  "string LARGE_YELLOW_AREA =\"lya\"\n"
  "string SOLAR_PANEL_AREA =\"spa\"\n"
  "string NORMAL_PLANT =\"np\"\n"
  "string FRAGILE_PLANT =\"fp\"\n"
  "string PLANT_UPSIDE_DOWN_RIGHT =\"pudr\"\n"
  "string PLANT_UPSIDE_DOWN_LEFT =\"pudl\"\n"
  "string PLANT_UPSIDE_DOWN_FORWARD =\"pudf\"\n"
  "string PLANT_UPSIDE_DOWN_BACKWARD =\"pudb\"\n"
  "string OVERTUNED_POT_RIGHT =\"opr\"\n"
  "string OVERTUNED_POT_LEFT =\"opl\"\n"
  "string OVERTUNED_POT_FORWARD =\"opf\"\n"
  "string OVERTUNED_POT_BACKWARD =\"opb\"\n"
  "string CENTER =\"center\"\n"
  "\n"
  "float32 target_deviation_pourcentage\n"
  "string target_detection\n"
  "string target_navigation_detection";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
data_flow__msg__ProcessedVideoData__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {data_flow__msg__ProcessedVideoData__TYPE_NAME, 32, 32},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 629, 629},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
data_flow__msg__ProcessedVideoData__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *data_flow__msg__ProcessedVideoData__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
