// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from data_flow:msg/ActionCommandsData.idl
// generated code does not contain a copyright notice

#include "data_flow/msg/detail/action_commands_data__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_data_flow
const rosidl_type_hash_t *
data_flow__msg__ActionCommandsData__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x87, 0xcc, 0xca, 0x7d, 0xeb, 0x38, 0x09, 0x6b,
      0x2b, 0xdf, 0x24, 0x0c, 0x01, 0x20, 0x15, 0x66,
      0x79, 0xb5, 0xae, 0xc3, 0x51, 0x8c, 0x97, 0x62,
      0x5c, 0xa6, 0xf6, 0x99, 0x2b, 0xe8, 0xb9, 0xe7,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char data_flow__msg__ActionCommandsData__TYPE_NAME[] = "data_flow/msg/ActionCommandsData";

// Define type names, field names, and default values
static char data_flow__msg__ActionCommandsData__FIELD_NAME__target[] = "target";
static char data_flow__msg__ActionCommandsData__FIELD_NAME__emergency_stop[] = "emergency_stop";

static rosidl_runtime_c__type_description__Field data_flow__msg__ActionCommandsData__FIELDS[] = {
  {
    {data_flow__msg__ActionCommandsData__FIELD_NAME__target, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__ActionCommandsData__FIELD_NAME__emergency_stop, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
data_flow__msg__ActionCommandsData__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {data_flow__msg__ActionCommandsData__TYPE_NAME, 32, 32},
      {data_flow__msg__ActionCommandsData__FIELDS, 2, 2},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "string SMALL_BLUE_SIDE_BLUE =\"sbsb\"\n"
  "string SMALL_BLUE_SIDE_YELLOW =\"sbsy\"\n"
  "string LARGE_BLUE_AREA =\"lba\"\n"
  "string SMALL_YELLOW_SIDE_BLUE =\"sysb\"\n"
  "string SMALL_YELLOW_SIDE_YELLOW =\"sysy\"\n"
  "string LARGE_YELLOW_AREA =\"lya\"\n"
  "string PLANT_AREA_FORWARD_SIDE_BLUE =\"pafsb\"\n"
  "string PLANT_AREA_BACKWARD_SIDE_BLUE =\"pabsb\"\n"
  "string PLANT_AREA_FORWARD_SIDE_MIDDLE =\"pafsm\"\n"
  "string PLANT_AREA_BACKWARD_SIDE_MIDDLE =\"pabsm\"\n"
  "string PLANT_AREA_FORWARD_SIDE_YELLOW =\"pafsy\"\n"
  "string PLANT_AREA_BACKWARD_SIDE_YELLOW =\"pabsy\"\n"
  "string POT_AREA_FORWARD_SIDE_BLUE =\"Pafsb\"\n"
  "string POT_AREA_BACKWARD_SIDE_BLUE =\"Pabsb\"\n"
  "string POT_AREA_FORWARD_SIDE_MIDDLE =\"Pafsm\"\n"
  "string POT_AREA_BACKWARD_SIDE_MIDDLE =\"Pabsm\"\n"
  "string POT_AREA_FORWARD_SIDE_YELLOW =\"Pafsy\"\n"
  "string POT_AREA_BACKWARD_SIDE_YELLOW =\"Pabsy\"\n"
  "string GARDEN_AREA_FORWARD_SIDE_BLUE =\"gafsb\"\n"
  "string GARDEN_AREA_BACKWARD_SIDE_BLUE =\"gabsb\"\n"
  "string GARDEN_AREA_FORWARD_SIDE_MIDDLE =\"gafsm\"\n"
  "string GARDEN_AREA_BACKWARD_SIDE_MIDDLE =\"gabsm\"\n"
  "string GARDEN_AREA_FORWARD_SIDE_YELLOW =\"gafsy\"\n"
  "string GARDEN_AREA_BACKWARD_SIDE_YELLOW =\"gabsy\"\n"
  "string SOLAR_AREA_BLUE_SIDE_BLUE =\"sabsb\"\n"
  "string SOLAR_AREA_MIDDLE_SIDE_BLUE =\"samsb\"\n"
  "string SOLAR_AREA_YELLOW_SIDE_BLUE =\"saysb\"\n"
  "string SOLAR_AREA_BLUE_SIDE_YELLOW =\"sabsy\"\n"
  "string SOLAR_AREA_MIDDLE_SIDE_YELLOW =\"samsy\"\n"
  "string SOLAR_AREA_YELLOW_SIDE_YELLOW =\"saysy\"\n"
  "string CENTER =\"center\"\n"
  "\n"
  "string target\n"
  "bool emergency_stop\n"
  " # set true occur emergency stop\n"
  " # set false not occur emergency stop";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
data_flow__msg__ActionCommandsData__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {data_flow__msg__ActionCommandsData__TYPE_NAME, 32, 32},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 1447, 1447},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
data_flow__msg__ActionCommandsData__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *data_flow__msg__ActionCommandsData__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
