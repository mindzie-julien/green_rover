// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from data_flow:msg/SensorData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__SENSOR_DATA__TRAITS_HPP_
#define DATA_FLOW__MSG__DETAIL__SENSOR_DATA__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "data_flow/msg/detail/sensor_data__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace data_flow
{

namespace msg
{

inline void to_flow_style_yaml(
  const SensorData & msg,
  std::ostream & out)
{
  out << "{";
  // member: obstacle_distance_forward
  {
    out << "obstacle_distance_forward: ";
    rosidl_generator_traits::value_to_yaml(msg.obstacle_distance_forward, out);
    out << ", ";
  }

  // member: obstacle_distance_backward
  {
    out << "obstacle_distance_backward: ";
    rosidl_generator_traits::value_to_yaml(msg.obstacle_distance_backward, out);
    out << ", ";
  }

  // member: obstacle_distance_side_1
  {
    out << "obstacle_distance_side_1: ";
    rosidl_generator_traits::value_to_yaml(msg.obstacle_distance_side_1, out);
    out << ", ";
  }

  // member: obstacle_distance_side_2
  {
    out << "obstacle_distance_side_2: ";
    rosidl_generator_traits::value_to_yaml(msg.obstacle_distance_side_2, out);
    out << ", ";
  }

  // member: angle_delta
  {
    out << "angle_delta: ";
    rosidl_generator_traits::value_to_yaml(msg.angle_delta, out);
    out << ", ";
  }

  // member: target_deviation_pourcentage
  {
    out << "target_deviation_pourcentage: ";
    rosidl_generator_traits::value_to_yaml(msg.target_deviation_pourcentage, out);
    out << ", ";
  }

  // member: acceleration
  {
    out << "acceleration: ";
    rosidl_generator_traits::value_to_yaml(msg.acceleration, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SensorData & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: obstacle_distance_forward
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "obstacle_distance_forward: ";
    rosidl_generator_traits::value_to_yaml(msg.obstacle_distance_forward, out);
    out << "\n";
  }

  // member: obstacle_distance_backward
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "obstacle_distance_backward: ";
    rosidl_generator_traits::value_to_yaml(msg.obstacle_distance_backward, out);
    out << "\n";
  }

  // member: obstacle_distance_side_1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "obstacle_distance_side_1: ";
    rosidl_generator_traits::value_to_yaml(msg.obstacle_distance_side_1, out);
    out << "\n";
  }

  // member: obstacle_distance_side_2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "obstacle_distance_side_2: ";
    rosidl_generator_traits::value_to_yaml(msg.obstacle_distance_side_2, out);
    out << "\n";
  }

  // member: angle_delta
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "angle_delta: ";
    rosidl_generator_traits::value_to_yaml(msg.angle_delta, out);
    out << "\n";
  }

  // member: target_deviation_pourcentage
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "target_deviation_pourcentage: ";
    rosidl_generator_traits::value_to_yaml(msg.target_deviation_pourcentage, out);
    out << "\n";
  }

  // member: acceleration
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "acceleration: ";
    rosidl_generator_traits::value_to_yaml(msg.acceleration, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SensorData & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace data_flow

namespace rosidl_generator_traits
{

[[deprecated("use data_flow::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const data_flow::msg::SensorData & msg,
  std::ostream & out, size_t indentation = 0)
{
  data_flow::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use data_flow::msg::to_yaml() instead")]]
inline std::string to_yaml(const data_flow::msg::SensorData & msg)
{
  return data_flow::msg::to_yaml(msg);
}

template<>
inline const char * data_type<data_flow::msg::SensorData>()
{
  return "data_flow::msg::SensorData";
}

template<>
inline const char * name<data_flow::msg::SensorData>()
{
  return "data_flow/msg/SensorData";
}

template<>
struct has_fixed_size<data_flow::msg::SensorData>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<data_flow::msg::SensorData>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<data_flow::msg::SensorData>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DATA_FLOW__MSG__DETAIL__SENSOR_DATA__TRAITS_HPP_
