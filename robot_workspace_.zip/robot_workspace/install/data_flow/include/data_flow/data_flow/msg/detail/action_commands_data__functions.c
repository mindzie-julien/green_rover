// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from data_flow:msg/ActionCommandsData.idl
// generated code does not contain a copyright notice
#include "data_flow/msg/detail/action_commands_data__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `target`
#include "rosidl_runtime_c/string_functions.h"

bool
data_flow__msg__ActionCommandsData__init(data_flow__msg__ActionCommandsData * msg)
{
  if (!msg) {
    return false;
  }
  // target
  if (!rosidl_runtime_c__String__init(&msg->target)) {
    data_flow__msg__ActionCommandsData__fini(msg);
    return false;
  }
  // emergency_stop
  return true;
}

void
data_flow__msg__ActionCommandsData__fini(data_flow__msg__ActionCommandsData * msg)
{
  if (!msg) {
    return;
  }
  // target
  rosidl_runtime_c__String__fini(&msg->target);
  // emergency_stop
}

bool
data_flow__msg__ActionCommandsData__are_equal(const data_flow__msg__ActionCommandsData * lhs, const data_flow__msg__ActionCommandsData * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // target
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->target), &(rhs->target)))
  {
    return false;
  }
  // emergency_stop
  if (lhs->emergency_stop != rhs->emergency_stop) {
    return false;
  }
  return true;
}

bool
data_flow__msg__ActionCommandsData__copy(
  const data_flow__msg__ActionCommandsData * input,
  data_flow__msg__ActionCommandsData * output)
{
  if (!input || !output) {
    return false;
  }
  // target
  if (!rosidl_runtime_c__String__copy(
      &(input->target), &(output->target)))
  {
    return false;
  }
  // emergency_stop
  output->emergency_stop = input->emergency_stop;
  return true;
}

data_flow__msg__ActionCommandsData *
data_flow__msg__ActionCommandsData__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_flow__msg__ActionCommandsData * msg = (data_flow__msg__ActionCommandsData *)allocator.allocate(sizeof(data_flow__msg__ActionCommandsData), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(data_flow__msg__ActionCommandsData));
  bool success = data_flow__msg__ActionCommandsData__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
data_flow__msg__ActionCommandsData__destroy(data_flow__msg__ActionCommandsData * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    data_flow__msg__ActionCommandsData__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
data_flow__msg__ActionCommandsData__Sequence__init(data_flow__msg__ActionCommandsData__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_flow__msg__ActionCommandsData * data = NULL;

  if (size) {
    data = (data_flow__msg__ActionCommandsData *)allocator.zero_allocate(size, sizeof(data_flow__msg__ActionCommandsData), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = data_flow__msg__ActionCommandsData__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        data_flow__msg__ActionCommandsData__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
data_flow__msg__ActionCommandsData__Sequence__fini(data_flow__msg__ActionCommandsData__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      data_flow__msg__ActionCommandsData__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

data_flow__msg__ActionCommandsData__Sequence *
data_flow__msg__ActionCommandsData__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_flow__msg__ActionCommandsData__Sequence * array = (data_flow__msg__ActionCommandsData__Sequence *)allocator.allocate(sizeof(data_flow__msg__ActionCommandsData__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = data_flow__msg__ActionCommandsData__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
data_flow__msg__ActionCommandsData__Sequence__destroy(data_flow__msg__ActionCommandsData__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    data_flow__msg__ActionCommandsData__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
data_flow__msg__ActionCommandsData__Sequence__are_equal(const data_flow__msg__ActionCommandsData__Sequence * lhs, const data_flow__msg__ActionCommandsData__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!data_flow__msg__ActionCommandsData__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
data_flow__msg__ActionCommandsData__Sequence__copy(
  const data_flow__msg__ActionCommandsData__Sequence * input,
  data_flow__msg__ActionCommandsData__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(data_flow__msg__ActionCommandsData);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    data_flow__msg__ActionCommandsData * data =
      (data_flow__msg__ActionCommandsData *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!data_flow__msg__ActionCommandsData__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          data_flow__msg__ActionCommandsData__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!data_flow__msg__ActionCommandsData__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
