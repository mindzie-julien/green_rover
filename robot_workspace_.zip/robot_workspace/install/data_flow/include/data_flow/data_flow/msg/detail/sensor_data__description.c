// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from data_flow:msg/SensorData.idl
// generated code does not contain a copyright notice

#include "data_flow/msg/detail/sensor_data__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_data_flow
const rosidl_type_hash_t *
data_flow__msg__SensorData__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xb9, 0x8b, 0x89, 0xa6, 0xe3, 0xe7, 0x21, 0x80,
      0xc1, 0x8c, 0x51, 0xee, 0x9b, 0x30, 0xec, 0x4a,
      0xef, 0xec, 0x44, 0x4c, 0x01, 0x26, 0xd6, 0x84,
      0x68, 0xf9, 0x60, 0x9c, 0x30, 0x60, 0xb5, 0xed,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char data_flow__msg__SensorData__TYPE_NAME[] = "data_flow/msg/SensorData";

// Define type names, field names, and default values
static char data_flow__msg__SensorData__FIELD_NAME__obstacle_distance_forward[] = "obstacle_distance_forward";
static char data_flow__msg__SensorData__FIELD_NAME__obstacle_distance_backward[] = "obstacle_distance_backward";
static char data_flow__msg__SensorData__FIELD_NAME__obstacle_distance_side_1[] = "obstacle_distance_side_1";
static char data_flow__msg__SensorData__FIELD_NAME__obstacle_distance_side_2[] = "obstacle_distance_side_2";
static char data_flow__msg__SensorData__FIELD_NAME__angle_delta[] = "angle_delta";
static char data_flow__msg__SensorData__FIELD_NAME__target_deviation_pourcentage[] = "target_deviation_pourcentage";
static char data_flow__msg__SensorData__FIELD_NAME__acceleration[] = "acceleration";

static rosidl_runtime_c__type_description__Field data_flow__msg__SensorData__FIELDS[] = {
  {
    {data_flow__msg__SensorData__FIELD_NAME__obstacle_distance_forward, 25, 25},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__SensorData__FIELD_NAME__obstacle_distance_backward, 26, 26},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__SensorData__FIELD_NAME__obstacle_distance_side_1, 24, 24},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__SensorData__FIELD_NAME__obstacle_distance_side_2, 24, 24},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__SensorData__FIELD_NAME__angle_delta, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__SensorData__FIELD_NAME__target_deviation_pourcentage, 28, 28},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__SensorData__FIELD_NAME__acceleration, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
data_flow__msg__SensorData__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {data_flow__msg__SensorData__TYPE_NAME, 24, 24},
      {data_flow__msg__SensorData__FIELDS, 7, 7},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "float32 obstacle_distance_forward\n"
  "float32 obstacle_distance_backward\n"
  "float32 obstacle_distance_side_1\n"
  "float32 obstacle_distance_side_2\n"
  "float32 angle_delta\n"
  "float32 target_deviation_pourcentage\n"
  "float32 acceleration";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
data_flow__msg__SensorData__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {data_flow__msg__SensorData__TYPE_NAME, 24, 24},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 213, 213},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
data_flow__msg__SensorData__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *data_flow__msg__SensorData__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
