// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from data_flow:msg/MotionData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__MOTION_DATA__TRAITS_HPP_
#define DATA_FLOW__MSG__DETAIL__MOTION_DATA__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "data_flow/msg/detail/motion_data__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace data_flow
{

namespace msg
{

inline void to_flow_style_yaml(
  const MotionData & msg,
  std::ostream & out)
{
  out << "{";
  // member: direction
  {
    out << "direction: ";
    rosidl_generator_traits::value_to_yaml(msg.direction, out);
    out << ", ";
  }

  // member: rotation_sense
  {
    out << "rotation_sense: ";
    rosidl_generator_traits::value_to_yaml(msg.rotation_sense, out);
    out << ", ";
  }

  // member: distance_completed
  {
    out << "distance_completed: ";
    rosidl_generator_traits::value_to_yaml(msg.distance_completed, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MotionData & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: direction
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "direction: ";
    rosidl_generator_traits::value_to_yaml(msg.direction, out);
    out << "\n";
  }

  // member: rotation_sense
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rotation_sense: ";
    rosidl_generator_traits::value_to_yaml(msg.rotation_sense, out);
    out << "\n";
  }

  // member: distance_completed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "distance_completed: ";
    rosidl_generator_traits::value_to_yaml(msg.distance_completed, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MotionData & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace data_flow

namespace rosidl_generator_traits
{

[[deprecated("use data_flow::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const data_flow::msg::MotionData & msg,
  std::ostream & out, size_t indentation = 0)
{
  data_flow::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use data_flow::msg::to_yaml() instead")]]
inline std::string to_yaml(const data_flow::msg::MotionData & msg)
{
  return data_flow::msg::to_yaml(msg);
}

template<>
inline const char * data_type<data_flow::msg::MotionData>()
{
  return "data_flow::msg::MotionData";
}

template<>
inline const char * name<data_flow::msg::MotionData>()
{
  return "data_flow/msg/MotionData";
}

template<>
struct has_fixed_size<data_flow::msg::MotionData>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<data_flow::msg::MotionData>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<data_flow::msg::MotionData>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DATA_FLOW__MSG__DETAIL__MOTION_DATA__TRAITS_HPP_
