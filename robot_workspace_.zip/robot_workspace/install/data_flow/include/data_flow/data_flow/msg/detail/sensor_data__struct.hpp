// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from data_flow:msg/SensorData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__SENSOR_DATA__STRUCT_HPP_
#define DATA_FLOW__MSG__DETAIL__SENSOR_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__data_flow__msg__SensorData __attribute__((deprecated))
#else
# define DEPRECATED__data_flow__msg__SensorData __declspec(deprecated)
#endif

namespace data_flow
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SensorData_
{
  using Type = SensorData_<ContainerAllocator>;

  explicit SensorData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->obstacle_distance_forward = 0.0f;
      this->obstacle_distance_backward = 0.0f;
      this->obstacle_distance_side_1 = 0.0f;
      this->obstacle_distance_side_2 = 0.0f;
      this->angle_delta = 0.0f;
      this->target_deviation_pourcentage = 0.0f;
      this->acceleration = 0.0f;
    }
  }

  explicit SensorData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->obstacle_distance_forward = 0.0f;
      this->obstacle_distance_backward = 0.0f;
      this->obstacle_distance_side_1 = 0.0f;
      this->obstacle_distance_side_2 = 0.0f;
      this->angle_delta = 0.0f;
      this->target_deviation_pourcentage = 0.0f;
      this->acceleration = 0.0f;
    }
  }

  // field types and members
  using _obstacle_distance_forward_type =
    float;
  _obstacle_distance_forward_type obstacle_distance_forward;
  using _obstacle_distance_backward_type =
    float;
  _obstacle_distance_backward_type obstacle_distance_backward;
  using _obstacle_distance_side_1_type =
    float;
  _obstacle_distance_side_1_type obstacle_distance_side_1;
  using _obstacle_distance_side_2_type =
    float;
  _obstacle_distance_side_2_type obstacle_distance_side_2;
  using _angle_delta_type =
    float;
  _angle_delta_type angle_delta;
  using _target_deviation_pourcentage_type =
    float;
  _target_deviation_pourcentage_type target_deviation_pourcentage;
  using _acceleration_type =
    float;
  _acceleration_type acceleration;

  // setters for named parameter idiom
  Type & set__obstacle_distance_forward(
    const float & _arg)
  {
    this->obstacle_distance_forward = _arg;
    return *this;
  }
  Type & set__obstacle_distance_backward(
    const float & _arg)
  {
    this->obstacle_distance_backward = _arg;
    return *this;
  }
  Type & set__obstacle_distance_side_1(
    const float & _arg)
  {
    this->obstacle_distance_side_1 = _arg;
    return *this;
  }
  Type & set__obstacle_distance_side_2(
    const float & _arg)
  {
    this->obstacle_distance_side_2 = _arg;
    return *this;
  }
  Type & set__angle_delta(
    const float & _arg)
  {
    this->angle_delta = _arg;
    return *this;
  }
  Type & set__target_deviation_pourcentage(
    const float & _arg)
  {
    this->target_deviation_pourcentage = _arg;
    return *this;
  }
  Type & set__acceleration(
    const float & _arg)
  {
    this->acceleration = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    data_flow::msg::SensorData_<ContainerAllocator> *;
  using ConstRawPtr =
    const data_flow::msg::SensorData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<data_flow::msg::SensorData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<data_flow::msg::SensorData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      data_flow::msg::SensorData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<data_flow::msg::SensorData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      data_flow::msg::SensorData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<data_flow::msg::SensorData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<data_flow::msg::SensorData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<data_flow::msg::SensorData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__data_flow__msg__SensorData
    std::shared_ptr<data_flow::msg::SensorData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__data_flow__msg__SensorData
    std::shared_ptr<data_flow::msg::SensorData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SensorData_ & other) const
  {
    if (this->obstacle_distance_forward != other.obstacle_distance_forward) {
      return false;
    }
    if (this->obstacle_distance_backward != other.obstacle_distance_backward) {
      return false;
    }
    if (this->obstacle_distance_side_1 != other.obstacle_distance_side_1) {
      return false;
    }
    if (this->obstacle_distance_side_2 != other.obstacle_distance_side_2) {
      return false;
    }
    if (this->angle_delta != other.angle_delta) {
      return false;
    }
    if (this->target_deviation_pourcentage != other.target_deviation_pourcentage) {
      return false;
    }
    if (this->acceleration != other.acceleration) {
      return false;
    }
    return true;
  }
  bool operator!=(const SensorData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SensorData_

// alias to use template instance with default allocator
using SensorData =
  data_flow::msg::SensorData_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace data_flow

#endif  // DATA_FLOW__MSG__DETAIL__SENSOR_DATA__STRUCT_HPP_
