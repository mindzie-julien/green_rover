// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from data_flow:msg/HandlingCommandsData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__HANDLING_COMMANDS_DATA__BUILDER_HPP_
#define DATA_FLOW__MSG__DETAIL__HANDLING_COMMANDS_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "data_flow/msg/detail/handling_commands_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace data_flow
{

namespace msg
{

namespace builder
{

class Init_HandlingCommandsData_actuator_level_hand_backward
{
public:
  explicit Init_HandlingCommandsData_actuator_level_hand_backward(::data_flow::msg::HandlingCommandsData & msg)
  : msg_(msg)
  {}
  ::data_flow::msg::HandlingCommandsData actuator_level_hand_backward(::data_flow::msg::HandlingCommandsData::_actuator_level_hand_backward_type arg)
  {
    msg_.actuator_level_hand_backward = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::msg::HandlingCommandsData msg_;
};

class Init_HandlingCommandsData_actuator_level_hand_forward
{
public:
  explicit Init_HandlingCommandsData_actuator_level_hand_forward(::data_flow::msg::HandlingCommandsData & msg)
  : msg_(msg)
  {}
  Init_HandlingCommandsData_actuator_level_hand_backward actuator_level_hand_forward(::data_flow::msg::HandlingCommandsData::_actuator_level_hand_forward_type arg)
  {
    msg_.actuator_level_hand_forward = std::move(arg);
    return Init_HandlingCommandsData_actuator_level_hand_backward(msg_);
  }

private:
  ::data_flow::msg::HandlingCommandsData msg_;
};

class Init_HandlingCommandsData_actuator_solar_panel_backward
{
public:
  explicit Init_HandlingCommandsData_actuator_solar_panel_backward(::data_flow::msg::HandlingCommandsData & msg)
  : msg_(msg)
  {}
  Init_HandlingCommandsData_actuator_level_hand_forward actuator_solar_panel_backward(::data_flow::msg::HandlingCommandsData::_actuator_solar_panel_backward_type arg)
  {
    msg_.actuator_solar_panel_backward = std::move(arg);
    return Init_HandlingCommandsData_actuator_level_hand_forward(msg_);
  }

private:
  ::data_flow::msg::HandlingCommandsData msg_;
};

class Init_HandlingCommandsData_actuator_solar_panel_forward
{
public:
  explicit Init_HandlingCommandsData_actuator_solar_panel_forward(::data_flow::msg::HandlingCommandsData & msg)
  : msg_(msg)
  {}
  Init_HandlingCommandsData_actuator_solar_panel_backward actuator_solar_panel_forward(::data_flow::msg::HandlingCommandsData::_actuator_solar_panel_forward_type arg)
  {
    msg_.actuator_solar_panel_forward = std::move(arg);
    return Init_HandlingCommandsData_actuator_solar_panel_backward(msg_);
  }

private:
  ::data_flow::msg::HandlingCommandsData msg_;
};

class Init_HandlingCommandsData_actuator_pliers_backward
{
public:
  explicit Init_HandlingCommandsData_actuator_pliers_backward(::data_flow::msg::HandlingCommandsData & msg)
  : msg_(msg)
  {}
  Init_HandlingCommandsData_actuator_solar_panel_forward actuator_pliers_backward(::data_flow::msg::HandlingCommandsData::_actuator_pliers_backward_type arg)
  {
    msg_.actuator_pliers_backward = std::move(arg);
    return Init_HandlingCommandsData_actuator_solar_panel_forward(msg_);
  }

private:
  ::data_flow::msg::HandlingCommandsData msg_;
};

class Init_HandlingCommandsData_actuator_pliers_forward
{
public:
  Init_HandlingCommandsData_actuator_pliers_forward()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_HandlingCommandsData_actuator_pliers_backward actuator_pliers_forward(::data_flow::msg::HandlingCommandsData::_actuator_pliers_forward_type arg)
  {
    msg_.actuator_pliers_forward = std::move(arg);
    return Init_HandlingCommandsData_actuator_pliers_backward(msg_);
  }

private:
  ::data_flow::msg::HandlingCommandsData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::msg::HandlingCommandsData>()
{
  return data_flow::msg::builder::Init_HandlingCommandsData_actuator_pliers_forward();
}

}  // namespace data_flow

#endif  // DATA_FLOW__MSG__DETAIL__HANDLING_COMMANDS_DATA__BUILDER_HPP_
