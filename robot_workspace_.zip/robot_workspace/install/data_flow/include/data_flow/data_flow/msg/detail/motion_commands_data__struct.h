// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from data_flow:msg/MotionCommandsData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__MOTION_COMMANDS_DATA__STRUCT_H_
#define DATA_FLOW__MSG__DETAIL__MOTION_COMMANDS_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/MotionCommandsData in the package data_flow.
typedef struct data_flow__msg__MotionCommandsData
{
  float angle_delta_command;
  float distance_motion_command;
  /// set true occur emergency stop
  /// set false not occur emergency stop
  bool emergency_stop;
  float target_deviation_pourcentage;
  float acceleration;
} data_flow__msg__MotionCommandsData;

// Struct for a sequence of data_flow__msg__MotionCommandsData.
typedef struct data_flow__msg__MotionCommandsData__Sequence
{
  data_flow__msg__MotionCommandsData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__msg__MotionCommandsData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DATA_FLOW__MSG__DETAIL__MOTION_COMMANDS_DATA__STRUCT_H_
