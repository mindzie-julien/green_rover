// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from data_flow:msg/MotionData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__MOTION_DATA__STRUCT_HPP_
#define DATA_FLOW__MSG__DETAIL__MOTION_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__data_flow__msg__MotionData __attribute__((deprecated))
#else
# define DEPRECATED__data_flow__msg__MotionData __declspec(deprecated)
#endif

namespace data_flow
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct MotionData_
{
  using Type = MotionData_<ContainerAllocator>;

  explicit MotionData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->direction = "";
      this->rotation_sense = "";
      this->distance_completed = 0.0f;
    }
  }

  explicit MotionData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : direction(_alloc),
    rotation_sense(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->direction = "";
      this->rotation_sense = "";
      this->distance_completed = 0.0f;
    }
  }

  // field types and members
  using _direction_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _direction_type direction;
  using _rotation_sense_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _rotation_sense_type rotation_sense;
  using _distance_completed_type =
    float;
  _distance_completed_type distance_completed;

  // setters for named parameter idiom
  Type & set__direction(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->direction = _arg;
    return *this;
  }
  Type & set__rotation_sense(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->rotation_sense = _arg;
    return *this;
  }
  Type & set__distance_completed(
    const float & _arg)
  {
    this->distance_completed = _arg;
    return *this;
  }

  // constant declarations
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> FORWARD;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> BACKWARD;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> RIGHT;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> LEFT;

  // pointer types
  using RawPtr =
    data_flow::msg::MotionData_<ContainerAllocator> *;
  using ConstRawPtr =
    const data_flow::msg::MotionData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<data_flow::msg::MotionData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<data_flow::msg::MotionData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      data_flow::msg::MotionData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<data_flow::msg::MotionData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      data_flow::msg::MotionData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<data_flow::msg::MotionData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<data_flow::msg::MotionData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<data_flow::msg::MotionData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__data_flow__msg__MotionData
    std::shared_ptr<data_flow::msg::MotionData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__data_flow__msg__MotionData
    std::shared_ptr<data_flow::msg::MotionData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MotionData_ & other) const
  {
    if (this->direction != other.direction) {
      return false;
    }
    if (this->rotation_sense != other.rotation_sense) {
      return false;
    }
    if (this->distance_completed != other.distance_completed) {
      return false;
    }
    return true;
  }
  bool operator!=(const MotionData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MotionData_

// alias to use template instance with default allocator
using MotionData =
  data_flow::msg::MotionData_<std::allocator<void>>;

// constant definitions
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
MotionData_<ContainerAllocator>::FORWARD = "forward";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
MotionData_<ContainerAllocator>::BACKWARD = "backward";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
MotionData_<ContainerAllocator>::RIGHT = "right";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
MotionData_<ContainerAllocator>::LEFT = "left";

}  // namespace msg

}  // namespace data_flow

#endif  // DATA_FLOW__MSG__DETAIL__MOTION_DATA__STRUCT_HPP_
