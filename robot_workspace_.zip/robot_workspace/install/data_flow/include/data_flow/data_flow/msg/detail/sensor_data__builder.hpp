// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from data_flow:msg/SensorData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__SENSOR_DATA__BUILDER_HPP_
#define DATA_FLOW__MSG__DETAIL__SENSOR_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "data_flow/msg/detail/sensor_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace data_flow
{

namespace msg
{

namespace builder
{

class Init_SensorData_acceleration
{
public:
  explicit Init_SensorData_acceleration(::data_flow::msg::SensorData & msg)
  : msg_(msg)
  {}
  ::data_flow::msg::SensorData acceleration(::data_flow::msg::SensorData::_acceleration_type arg)
  {
    msg_.acceleration = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::msg::SensorData msg_;
};

class Init_SensorData_target_deviation_pourcentage
{
public:
  explicit Init_SensorData_target_deviation_pourcentage(::data_flow::msg::SensorData & msg)
  : msg_(msg)
  {}
  Init_SensorData_acceleration target_deviation_pourcentage(::data_flow::msg::SensorData::_target_deviation_pourcentage_type arg)
  {
    msg_.target_deviation_pourcentage = std::move(arg);
    return Init_SensorData_acceleration(msg_);
  }

private:
  ::data_flow::msg::SensorData msg_;
};

class Init_SensorData_angle_delta
{
public:
  explicit Init_SensorData_angle_delta(::data_flow::msg::SensorData & msg)
  : msg_(msg)
  {}
  Init_SensorData_target_deviation_pourcentage angle_delta(::data_flow::msg::SensorData::_angle_delta_type arg)
  {
    msg_.angle_delta = std::move(arg);
    return Init_SensorData_target_deviation_pourcentage(msg_);
  }

private:
  ::data_flow::msg::SensorData msg_;
};

class Init_SensorData_obstacle_distance_side_2
{
public:
  explicit Init_SensorData_obstacle_distance_side_2(::data_flow::msg::SensorData & msg)
  : msg_(msg)
  {}
  Init_SensorData_angle_delta obstacle_distance_side_2(::data_flow::msg::SensorData::_obstacle_distance_side_2_type arg)
  {
    msg_.obstacle_distance_side_2 = std::move(arg);
    return Init_SensorData_angle_delta(msg_);
  }

private:
  ::data_flow::msg::SensorData msg_;
};

class Init_SensorData_obstacle_distance_side_1
{
public:
  explicit Init_SensorData_obstacle_distance_side_1(::data_flow::msg::SensorData & msg)
  : msg_(msg)
  {}
  Init_SensorData_obstacle_distance_side_2 obstacle_distance_side_1(::data_flow::msg::SensorData::_obstacle_distance_side_1_type arg)
  {
    msg_.obstacle_distance_side_1 = std::move(arg);
    return Init_SensorData_obstacle_distance_side_2(msg_);
  }

private:
  ::data_flow::msg::SensorData msg_;
};

class Init_SensorData_obstacle_distance_backward
{
public:
  explicit Init_SensorData_obstacle_distance_backward(::data_flow::msg::SensorData & msg)
  : msg_(msg)
  {}
  Init_SensorData_obstacle_distance_side_1 obstacle_distance_backward(::data_flow::msg::SensorData::_obstacle_distance_backward_type arg)
  {
    msg_.obstacle_distance_backward = std::move(arg);
    return Init_SensorData_obstacle_distance_side_1(msg_);
  }

private:
  ::data_flow::msg::SensorData msg_;
};

class Init_SensorData_obstacle_distance_forward
{
public:
  Init_SensorData_obstacle_distance_forward()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SensorData_obstacle_distance_backward obstacle_distance_forward(::data_flow::msg::SensorData::_obstacle_distance_forward_type arg)
  {
    msg_.obstacle_distance_forward = std::move(arg);
    return Init_SensorData_obstacle_distance_backward(msg_);
  }

private:
  ::data_flow::msg::SensorData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::msg::SensorData>()
{
  return data_flow::msg::builder::Init_SensorData_obstacle_distance_forward();
}

}  // namespace data_flow

#endif  // DATA_FLOW__MSG__DETAIL__SENSOR_DATA__BUILDER_HPP_
