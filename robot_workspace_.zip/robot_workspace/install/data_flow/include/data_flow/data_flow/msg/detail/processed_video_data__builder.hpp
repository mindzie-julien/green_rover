// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from data_flow:msg/ProcessedVideoData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__PROCESSED_VIDEO_DATA__BUILDER_HPP_
#define DATA_FLOW__MSG__DETAIL__PROCESSED_VIDEO_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "data_flow/msg/detail/processed_video_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace data_flow
{

namespace msg
{

namespace builder
{

class Init_ProcessedVideoData_target_navigation_detection
{
public:
  explicit Init_ProcessedVideoData_target_navigation_detection(::data_flow::msg::ProcessedVideoData & msg)
  : msg_(msg)
  {}
  ::data_flow::msg::ProcessedVideoData target_navigation_detection(::data_flow::msg::ProcessedVideoData::_target_navigation_detection_type arg)
  {
    msg_.target_navigation_detection = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::msg::ProcessedVideoData msg_;
};

class Init_ProcessedVideoData_target_detection
{
public:
  explicit Init_ProcessedVideoData_target_detection(::data_flow::msg::ProcessedVideoData & msg)
  : msg_(msg)
  {}
  Init_ProcessedVideoData_target_navigation_detection target_detection(::data_flow::msg::ProcessedVideoData::_target_detection_type arg)
  {
    msg_.target_detection = std::move(arg);
    return Init_ProcessedVideoData_target_navigation_detection(msg_);
  }

private:
  ::data_flow::msg::ProcessedVideoData msg_;
};

class Init_ProcessedVideoData_target_deviation_pourcentage
{
public:
  Init_ProcessedVideoData_target_deviation_pourcentage()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ProcessedVideoData_target_detection target_deviation_pourcentage(::data_flow::msg::ProcessedVideoData::_target_deviation_pourcentage_type arg)
  {
    msg_.target_deviation_pourcentage = std::move(arg);
    return Init_ProcessedVideoData_target_detection(msg_);
  }

private:
  ::data_flow::msg::ProcessedVideoData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::msg::ProcessedVideoData>()
{
  return data_flow::msg::builder::Init_ProcessedVideoData_target_deviation_pourcentage();
}

}  // namespace data_flow

#endif  // DATA_FLOW__MSG__DETAIL__PROCESSED_VIDEO_DATA__BUILDER_HPP_
