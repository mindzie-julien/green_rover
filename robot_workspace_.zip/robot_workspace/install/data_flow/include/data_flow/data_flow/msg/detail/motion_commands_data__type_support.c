// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from data_flow:msg/MotionCommandsData.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "data_flow/msg/detail/motion_commands_data__rosidl_typesupport_introspection_c.h"
#include "data_flow/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "data_flow/msg/detail/motion_commands_data__functions.h"
#include "data_flow/msg/detail/motion_commands_data__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void data_flow__msg__MotionCommandsData__rosidl_typesupport_introspection_c__MotionCommandsData_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  data_flow__msg__MotionCommandsData__init(message_memory);
}

void data_flow__msg__MotionCommandsData__rosidl_typesupport_introspection_c__MotionCommandsData_fini_function(void * message_memory)
{
  data_flow__msg__MotionCommandsData__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember data_flow__msg__MotionCommandsData__rosidl_typesupport_introspection_c__MotionCommandsData_message_member_array[5] = {
  {
    "angle_delta_command",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(data_flow__msg__MotionCommandsData, angle_delta_command),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "distance_motion_command",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(data_flow__msg__MotionCommandsData, distance_motion_command),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "emergency_stop",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(data_flow__msg__MotionCommandsData, emergency_stop),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "target_deviation_pourcentage",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(data_flow__msg__MotionCommandsData, target_deviation_pourcentage),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "acceleration",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(data_flow__msg__MotionCommandsData, acceleration),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers data_flow__msg__MotionCommandsData__rosidl_typesupport_introspection_c__MotionCommandsData_message_members = {
  "data_flow__msg",  // message namespace
  "MotionCommandsData",  // message name
  5,  // number of fields
  sizeof(data_flow__msg__MotionCommandsData),
  data_flow__msg__MotionCommandsData__rosidl_typesupport_introspection_c__MotionCommandsData_message_member_array,  // message members
  data_flow__msg__MotionCommandsData__rosidl_typesupport_introspection_c__MotionCommandsData_init_function,  // function to initialize message memory (memory has to be allocated)
  data_flow__msg__MotionCommandsData__rosidl_typesupport_introspection_c__MotionCommandsData_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t data_flow__msg__MotionCommandsData__rosidl_typesupport_introspection_c__MotionCommandsData_message_type_support_handle = {
  0,
  &data_flow__msg__MotionCommandsData__rosidl_typesupport_introspection_c__MotionCommandsData_message_members,
  get_message_typesupport_handle_function,
  &data_flow__msg__MotionCommandsData__get_type_hash,
  &data_flow__msg__MotionCommandsData__get_type_description,
  &data_flow__msg__MotionCommandsData__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_data_flow
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, data_flow, msg, MotionCommandsData)() {
  if (!data_flow__msg__MotionCommandsData__rosidl_typesupport_introspection_c__MotionCommandsData_message_type_support_handle.typesupport_identifier) {
    data_flow__msg__MotionCommandsData__rosidl_typesupport_introspection_c__MotionCommandsData_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &data_flow__msg__MotionCommandsData__rosidl_typesupport_introspection_c__MotionCommandsData_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
