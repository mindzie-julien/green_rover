// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from data_flow:msg/MotionData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__MOTION_DATA__BUILDER_HPP_
#define DATA_FLOW__MSG__DETAIL__MOTION_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "data_flow/msg/detail/motion_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace data_flow
{

namespace msg
{

namespace builder
{

class Init_MotionData_distance_completed
{
public:
  explicit Init_MotionData_distance_completed(::data_flow::msg::MotionData & msg)
  : msg_(msg)
  {}
  ::data_flow::msg::MotionData distance_completed(::data_flow::msg::MotionData::_distance_completed_type arg)
  {
    msg_.distance_completed = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::msg::MotionData msg_;
};

class Init_MotionData_rotation_sense
{
public:
  explicit Init_MotionData_rotation_sense(::data_flow::msg::MotionData & msg)
  : msg_(msg)
  {}
  Init_MotionData_distance_completed rotation_sense(::data_flow::msg::MotionData::_rotation_sense_type arg)
  {
    msg_.rotation_sense = std::move(arg);
    return Init_MotionData_distance_completed(msg_);
  }

private:
  ::data_flow::msg::MotionData msg_;
};

class Init_MotionData_direction
{
public:
  Init_MotionData_direction()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MotionData_rotation_sense direction(::data_flow::msg::MotionData::_direction_type arg)
  {
    msg_.direction = std::move(arg);
    return Init_MotionData_rotation_sense(msg_);
  }

private:
  ::data_flow::msg::MotionData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::msg::MotionData>()
{
  return data_flow::msg::builder::Init_MotionData_direction();
}

}  // namespace data_flow

#endif  // DATA_FLOW__MSG__DETAIL__MOTION_DATA__BUILDER_HPP_
