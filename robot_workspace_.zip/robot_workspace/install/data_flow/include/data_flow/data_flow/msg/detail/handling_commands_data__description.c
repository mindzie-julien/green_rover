// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from data_flow:msg/HandlingCommandsData.idl
// generated code does not contain a copyright notice

#include "data_flow/msg/detail/handling_commands_data__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_data_flow
const rosidl_type_hash_t *
data_flow__msg__HandlingCommandsData__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xb3, 0x94, 0x09, 0xa5, 0x49, 0x44, 0x07, 0x35,
      0xc7, 0x65, 0xb1, 0x67, 0x74, 0x51, 0xcc, 0x4b,
      0x47, 0x87, 0xd6, 0xb0, 0x48, 0x05, 0x2d, 0xad,
      0x98, 0xea, 0x97, 0xcb, 0x47, 0xe2, 0x3d, 0xce,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char data_flow__msg__HandlingCommandsData__TYPE_NAME[] = "data_flow/msg/HandlingCommandsData";

// Define type names, field names, and default values
static char data_flow__msg__HandlingCommandsData__FIELD_NAME__actuator_pliers_forward[] = "actuator_pliers_forward";
static char data_flow__msg__HandlingCommandsData__FIELD_NAME__actuator_pliers_backward[] = "actuator_pliers_backward";
static char data_flow__msg__HandlingCommandsData__FIELD_NAME__actuator_solar_panel_forward[] = "actuator_solar_panel_forward";
static char data_flow__msg__HandlingCommandsData__FIELD_NAME__actuator_solar_panel_backward[] = "actuator_solar_panel_backward";
static char data_flow__msg__HandlingCommandsData__FIELD_NAME__actuator_level_hand_forward[] = "actuator_level_hand_forward";
static char data_flow__msg__HandlingCommandsData__FIELD_NAME__actuator_level_hand_backward[] = "actuator_level_hand_backward";

static rosidl_runtime_c__type_description__Field data_flow__msg__HandlingCommandsData__FIELDS[] = {
  {
    {data_flow__msg__HandlingCommandsData__FIELD_NAME__actuator_pliers_forward, 23, 23},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8_ARRAY,
      2,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__HandlingCommandsData__FIELD_NAME__actuator_pliers_backward, 24, 24},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8_ARRAY,
      2,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__HandlingCommandsData__FIELD_NAME__actuator_solar_panel_forward, 28, 28},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__HandlingCommandsData__FIELD_NAME__actuator_solar_panel_backward, 29, 29},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__HandlingCommandsData__FIELD_NAME__actuator_level_hand_forward, 27, 27},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__HandlingCommandsData__FIELD_NAME__actuator_level_hand_backward, 28, 28},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
data_flow__msg__HandlingCommandsData__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {data_flow__msg__HandlingCommandsData__TYPE_NAME, 34, 34},
      {data_flow__msg__HandlingCommandsData__FIELDS, 6, 6},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "uint8[2] actuator_pliers_forward\n"
  "uint8[2] actuator_pliers_backward\n"
  "uint8 actuator_solar_panel_forward\n"
  "uint8 actuator_solar_panel_backward\n"
  "uint8 actuator_level_hand_forward\n"
  "uint8 actuator_level_hand_backward";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
data_flow__msg__HandlingCommandsData__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {data_flow__msg__HandlingCommandsData__TYPE_NAME, 34, 34},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 207, 207},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
data_flow__msg__HandlingCommandsData__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *data_flow__msg__HandlingCommandsData__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
