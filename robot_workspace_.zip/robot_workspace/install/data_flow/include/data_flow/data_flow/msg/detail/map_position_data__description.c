// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from data_flow:msg/MapPositionData.idl
// generated code does not contain a copyright notice

#include "data_flow/msg/detail/map_position_data__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_data_flow
const rosidl_type_hash_t *
data_flow__msg__MapPositionData__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xee, 0x1f, 0x22, 0x0e, 0x7d, 0x86, 0x8c, 0xe0,
      0xa6, 0x86, 0xa1, 0xad, 0x9b, 0x0f, 0x28, 0x89,
      0x7e, 0x1d, 0x36, 0x94, 0x10, 0xf4, 0xe4, 0x72,
      0x2d, 0xac, 0x9d, 0x99, 0x19, 0x83, 0xe1, 0x0a,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char data_flow__msg__MapPositionData__TYPE_NAME[] = "data_flow/msg/MapPositionData";

// Define type names, field names, and default values
static char data_flow__msg__MapPositionData__FIELD_NAME__coord_x[] = "coord_x";
static char data_flow__msg__MapPositionData__FIELD_NAME__coord_y[] = "coord_y";

static rosidl_runtime_c__type_description__Field data_flow__msg__MapPositionData__FIELDS[] = {
  {
    {data_flow__msg__MapPositionData__FIELD_NAME__coord_x, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__MapPositionData__FIELD_NAME__coord_y, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
data_flow__msg__MapPositionData__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {data_flow__msg__MapPositionData__TYPE_NAME, 29, 29},
      {data_flow__msg__MapPositionData__FIELDS, 2, 2},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "float32 coord_x\n"
  "float32 coord_y";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
data_flow__msg__MapPositionData__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {data_flow__msg__MapPositionData__TYPE_NAME, 29, 29},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 32, 32},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
data_flow__msg__MapPositionData__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *data_flow__msg__MapPositionData__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
