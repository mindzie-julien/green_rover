// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from data_flow:msg/ActionCommandsData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__ACTION_COMMANDS_DATA__BUILDER_HPP_
#define DATA_FLOW__MSG__DETAIL__ACTION_COMMANDS_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "data_flow/msg/detail/action_commands_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace data_flow
{

namespace msg
{

namespace builder
{

class Init_ActionCommandsData_emergency_stop
{
public:
  explicit Init_ActionCommandsData_emergency_stop(::data_flow::msg::ActionCommandsData & msg)
  : msg_(msg)
  {}
  ::data_flow::msg::ActionCommandsData emergency_stop(::data_flow::msg::ActionCommandsData::_emergency_stop_type arg)
  {
    msg_.emergency_stop = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::msg::ActionCommandsData msg_;
};

class Init_ActionCommandsData_target
{
public:
  Init_ActionCommandsData_target()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ActionCommandsData_emergency_stop target(::data_flow::msg::ActionCommandsData::_target_type arg)
  {
    msg_.target = std::move(arg);
    return Init_ActionCommandsData_emergency_stop(msg_);
  }

private:
  ::data_flow::msg::ActionCommandsData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::msg::ActionCommandsData>()
{
  return data_flow::msg::builder::Init_ActionCommandsData_target();
}

}  // namespace data_flow

#endif  // DATA_FLOW__MSG__DETAIL__ACTION_COMMANDS_DATA__BUILDER_HPP_
