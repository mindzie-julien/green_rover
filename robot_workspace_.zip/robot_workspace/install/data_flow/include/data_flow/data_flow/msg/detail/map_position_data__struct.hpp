// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from data_flow:msg/MapPositionData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__MAP_POSITION_DATA__STRUCT_HPP_
#define DATA_FLOW__MSG__DETAIL__MAP_POSITION_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__data_flow__msg__MapPositionData __attribute__((deprecated))
#else
# define DEPRECATED__data_flow__msg__MapPositionData __declspec(deprecated)
#endif

namespace data_flow
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct MapPositionData_
{
  using Type = MapPositionData_<ContainerAllocator>;

  explicit MapPositionData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->coord_x = 0.0f;
      this->coord_y = 0.0f;
    }
  }

  explicit MapPositionData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->coord_x = 0.0f;
      this->coord_y = 0.0f;
    }
  }

  // field types and members
  using _coord_x_type =
    float;
  _coord_x_type coord_x;
  using _coord_y_type =
    float;
  _coord_y_type coord_y;

  // setters for named parameter idiom
  Type & set__coord_x(
    const float & _arg)
  {
    this->coord_x = _arg;
    return *this;
  }
  Type & set__coord_y(
    const float & _arg)
  {
    this->coord_y = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    data_flow::msg::MapPositionData_<ContainerAllocator> *;
  using ConstRawPtr =
    const data_flow::msg::MapPositionData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<data_flow::msg::MapPositionData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<data_flow::msg::MapPositionData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      data_flow::msg::MapPositionData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<data_flow::msg::MapPositionData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      data_flow::msg::MapPositionData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<data_flow::msg::MapPositionData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<data_flow::msg::MapPositionData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<data_flow::msg::MapPositionData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__data_flow__msg__MapPositionData
    std::shared_ptr<data_flow::msg::MapPositionData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__data_flow__msg__MapPositionData
    std::shared_ptr<data_flow::msg::MapPositionData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MapPositionData_ & other) const
  {
    if (this->coord_x != other.coord_x) {
      return false;
    }
    if (this->coord_y != other.coord_y) {
      return false;
    }
    return true;
  }
  bool operator!=(const MapPositionData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MapPositionData_

// alias to use template instance with default allocator
using MapPositionData =
  data_flow::msg::MapPositionData_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace data_flow

#endif  // DATA_FLOW__MSG__DETAIL__MAP_POSITION_DATA__STRUCT_HPP_
