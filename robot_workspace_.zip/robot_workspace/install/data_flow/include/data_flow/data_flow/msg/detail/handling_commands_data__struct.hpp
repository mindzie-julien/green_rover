// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from data_flow:msg/HandlingCommandsData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__HANDLING_COMMANDS_DATA__STRUCT_HPP_
#define DATA_FLOW__MSG__DETAIL__HANDLING_COMMANDS_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__data_flow__msg__HandlingCommandsData __attribute__((deprecated))
#else
# define DEPRECATED__data_flow__msg__HandlingCommandsData __declspec(deprecated)
#endif

namespace data_flow
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct HandlingCommandsData_
{
  using Type = HandlingCommandsData_<ContainerAllocator>;

  explicit HandlingCommandsData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<uint8_t, 2>::iterator, uint8_t>(this->actuator_pliers_forward.begin(), this->actuator_pliers_forward.end(), 0);
      std::fill<typename std::array<uint8_t, 2>::iterator, uint8_t>(this->actuator_pliers_backward.begin(), this->actuator_pliers_backward.end(), 0);
      this->actuator_solar_panel_forward = 0;
      this->actuator_solar_panel_backward = 0;
      this->actuator_level_hand_forward = 0;
      this->actuator_level_hand_backward = 0;
    }
  }

  explicit HandlingCommandsData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : actuator_pliers_forward(_alloc),
    actuator_pliers_backward(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<uint8_t, 2>::iterator, uint8_t>(this->actuator_pliers_forward.begin(), this->actuator_pliers_forward.end(), 0);
      std::fill<typename std::array<uint8_t, 2>::iterator, uint8_t>(this->actuator_pliers_backward.begin(), this->actuator_pliers_backward.end(), 0);
      this->actuator_solar_panel_forward = 0;
      this->actuator_solar_panel_backward = 0;
      this->actuator_level_hand_forward = 0;
      this->actuator_level_hand_backward = 0;
    }
  }

  // field types and members
  using _actuator_pliers_forward_type =
    std::array<uint8_t, 2>;
  _actuator_pliers_forward_type actuator_pliers_forward;
  using _actuator_pliers_backward_type =
    std::array<uint8_t, 2>;
  _actuator_pliers_backward_type actuator_pliers_backward;
  using _actuator_solar_panel_forward_type =
    uint8_t;
  _actuator_solar_panel_forward_type actuator_solar_panel_forward;
  using _actuator_solar_panel_backward_type =
    uint8_t;
  _actuator_solar_panel_backward_type actuator_solar_panel_backward;
  using _actuator_level_hand_forward_type =
    uint8_t;
  _actuator_level_hand_forward_type actuator_level_hand_forward;
  using _actuator_level_hand_backward_type =
    uint8_t;
  _actuator_level_hand_backward_type actuator_level_hand_backward;

  // setters for named parameter idiom
  Type & set__actuator_pliers_forward(
    const std::array<uint8_t, 2> & _arg)
  {
    this->actuator_pliers_forward = _arg;
    return *this;
  }
  Type & set__actuator_pliers_backward(
    const std::array<uint8_t, 2> & _arg)
  {
    this->actuator_pliers_backward = _arg;
    return *this;
  }
  Type & set__actuator_solar_panel_forward(
    const uint8_t & _arg)
  {
    this->actuator_solar_panel_forward = _arg;
    return *this;
  }
  Type & set__actuator_solar_panel_backward(
    const uint8_t & _arg)
  {
    this->actuator_solar_panel_backward = _arg;
    return *this;
  }
  Type & set__actuator_level_hand_forward(
    const uint8_t & _arg)
  {
    this->actuator_level_hand_forward = _arg;
    return *this;
  }
  Type & set__actuator_level_hand_backward(
    const uint8_t & _arg)
  {
    this->actuator_level_hand_backward = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    data_flow::msg::HandlingCommandsData_<ContainerAllocator> *;
  using ConstRawPtr =
    const data_flow::msg::HandlingCommandsData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<data_flow::msg::HandlingCommandsData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<data_flow::msg::HandlingCommandsData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      data_flow::msg::HandlingCommandsData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<data_flow::msg::HandlingCommandsData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      data_flow::msg::HandlingCommandsData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<data_flow::msg::HandlingCommandsData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<data_flow::msg::HandlingCommandsData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<data_flow::msg::HandlingCommandsData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__data_flow__msg__HandlingCommandsData
    std::shared_ptr<data_flow::msg::HandlingCommandsData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__data_flow__msg__HandlingCommandsData
    std::shared_ptr<data_flow::msg::HandlingCommandsData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const HandlingCommandsData_ & other) const
  {
    if (this->actuator_pliers_forward != other.actuator_pliers_forward) {
      return false;
    }
    if (this->actuator_pliers_backward != other.actuator_pliers_backward) {
      return false;
    }
    if (this->actuator_solar_panel_forward != other.actuator_solar_panel_forward) {
      return false;
    }
    if (this->actuator_solar_panel_backward != other.actuator_solar_panel_backward) {
      return false;
    }
    if (this->actuator_level_hand_forward != other.actuator_level_hand_forward) {
      return false;
    }
    if (this->actuator_level_hand_backward != other.actuator_level_hand_backward) {
      return false;
    }
    return true;
  }
  bool operator!=(const HandlingCommandsData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct HandlingCommandsData_

// alias to use template instance with default allocator
using HandlingCommandsData =
  data_flow::msg::HandlingCommandsData_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace data_flow

#endif  // DATA_FLOW__MSG__DETAIL__HANDLING_COMMANDS_DATA__STRUCT_HPP_
