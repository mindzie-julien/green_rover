// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from data_flow:msg/MotionCommandsData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__MOTION_COMMANDS_DATA__STRUCT_HPP_
#define DATA_FLOW__MSG__DETAIL__MOTION_COMMANDS_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__data_flow__msg__MotionCommandsData __attribute__((deprecated))
#else
# define DEPRECATED__data_flow__msg__MotionCommandsData __declspec(deprecated)
#endif

namespace data_flow
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct MotionCommandsData_
{
  using Type = MotionCommandsData_<ContainerAllocator>;

  explicit MotionCommandsData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->angle_delta_command = 0.0f;
      this->distance_motion_command = 0.0f;
      this->emergency_stop = false;
      this->target_deviation_pourcentage = 0.0f;
      this->acceleration = 0.0f;
    }
  }

  explicit MotionCommandsData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->angle_delta_command = 0.0f;
      this->distance_motion_command = 0.0f;
      this->emergency_stop = false;
      this->target_deviation_pourcentage = 0.0f;
      this->acceleration = 0.0f;
    }
  }

  // field types and members
  using _angle_delta_command_type =
    float;
  _angle_delta_command_type angle_delta_command;
  using _distance_motion_command_type =
    float;
  _distance_motion_command_type distance_motion_command;
  using _emergency_stop_type =
    bool;
  _emergency_stop_type emergency_stop;
  using _target_deviation_pourcentage_type =
    float;
  _target_deviation_pourcentage_type target_deviation_pourcentage;
  using _acceleration_type =
    float;
  _acceleration_type acceleration;

  // setters for named parameter idiom
  Type & set__angle_delta_command(
    const float & _arg)
  {
    this->angle_delta_command = _arg;
    return *this;
  }
  Type & set__distance_motion_command(
    const float & _arg)
  {
    this->distance_motion_command = _arg;
    return *this;
  }
  Type & set__emergency_stop(
    const bool & _arg)
  {
    this->emergency_stop = _arg;
    return *this;
  }
  Type & set__target_deviation_pourcentage(
    const float & _arg)
  {
    this->target_deviation_pourcentage = _arg;
    return *this;
  }
  Type & set__acceleration(
    const float & _arg)
  {
    this->acceleration = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    data_flow::msg::MotionCommandsData_<ContainerAllocator> *;
  using ConstRawPtr =
    const data_flow::msg::MotionCommandsData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<data_flow::msg::MotionCommandsData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<data_flow::msg::MotionCommandsData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      data_flow::msg::MotionCommandsData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<data_flow::msg::MotionCommandsData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      data_flow::msg::MotionCommandsData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<data_flow::msg::MotionCommandsData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<data_flow::msg::MotionCommandsData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<data_flow::msg::MotionCommandsData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__data_flow__msg__MotionCommandsData
    std::shared_ptr<data_flow::msg::MotionCommandsData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__data_flow__msg__MotionCommandsData
    std::shared_ptr<data_flow::msg::MotionCommandsData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MotionCommandsData_ & other) const
  {
    if (this->angle_delta_command != other.angle_delta_command) {
      return false;
    }
    if (this->distance_motion_command != other.distance_motion_command) {
      return false;
    }
    if (this->emergency_stop != other.emergency_stop) {
      return false;
    }
    if (this->target_deviation_pourcentage != other.target_deviation_pourcentage) {
      return false;
    }
    if (this->acceleration != other.acceleration) {
      return false;
    }
    return true;
  }
  bool operator!=(const MotionCommandsData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MotionCommandsData_

// alias to use template instance with default allocator
using MotionCommandsData =
  data_flow::msg::MotionCommandsData_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace data_flow

#endif  // DATA_FLOW__MSG__DETAIL__MOTION_COMMANDS_DATA__STRUCT_HPP_
