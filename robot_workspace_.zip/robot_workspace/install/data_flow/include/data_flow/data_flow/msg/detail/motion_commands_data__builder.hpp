// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from data_flow:msg/MotionCommandsData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__MOTION_COMMANDS_DATA__BUILDER_HPP_
#define DATA_FLOW__MSG__DETAIL__MOTION_COMMANDS_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "data_flow/msg/detail/motion_commands_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace data_flow
{

namespace msg
{

namespace builder
{

class Init_MotionCommandsData_acceleration
{
public:
  explicit Init_MotionCommandsData_acceleration(::data_flow::msg::MotionCommandsData & msg)
  : msg_(msg)
  {}
  ::data_flow::msg::MotionCommandsData acceleration(::data_flow::msg::MotionCommandsData::_acceleration_type arg)
  {
    msg_.acceleration = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::msg::MotionCommandsData msg_;
};

class Init_MotionCommandsData_target_deviation_pourcentage
{
public:
  explicit Init_MotionCommandsData_target_deviation_pourcentage(::data_flow::msg::MotionCommandsData & msg)
  : msg_(msg)
  {}
  Init_MotionCommandsData_acceleration target_deviation_pourcentage(::data_flow::msg::MotionCommandsData::_target_deviation_pourcentage_type arg)
  {
    msg_.target_deviation_pourcentage = std::move(arg);
    return Init_MotionCommandsData_acceleration(msg_);
  }

private:
  ::data_flow::msg::MotionCommandsData msg_;
};

class Init_MotionCommandsData_emergency_stop
{
public:
  explicit Init_MotionCommandsData_emergency_stop(::data_flow::msg::MotionCommandsData & msg)
  : msg_(msg)
  {}
  Init_MotionCommandsData_target_deviation_pourcentage emergency_stop(::data_flow::msg::MotionCommandsData::_emergency_stop_type arg)
  {
    msg_.emergency_stop = std::move(arg);
    return Init_MotionCommandsData_target_deviation_pourcentage(msg_);
  }

private:
  ::data_flow::msg::MotionCommandsData msg_;
};

class Init_MotionCommandsData_distance_motion_command
{
public:
  explicit Init_MotionCommandsData_distance_motion_command(::data_flow::msg::MotionCommandsData & msg)
  : msg_(msg)
  {}
  Init_MotionCommandsData_emergency_stop distance_motion_command(::data_flow::msg::MotionCommandsData::_distance_motion_command_type arg)
  {
    msg_.distance_motion_command = std::move(arg);
    return Init_MotionCommandsData_emergency_stop(msg_);
  }

private:
  ::data_flow::msg::MotionCommandsData msg_;
};

class Init_MotionCommandsData_angle_delta_command
{
public:
  Init_MotionCommandsData_angle_delta_command()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MotionCommandsData_distance_motion_command angle_delta_command(::data_flow::msg::MotionCommandsData::_angle_delta_command_type arg)
  {
    msg_.angle_delta_command = std::move(arg);
    return Init_MotionCommandsData_distance_motion_command(msg_);
  }

private:
  ::data_flow::msg::MotionCommandsData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::msg::MotionCommandsData>()
{
  return data_flow::msg::builder::Init_MotionCommandsData_angle_delta_command();
}

}  // namespace data_flow

#endif  // DATA_FLOW__MSG__DETAIL__MOTION_COMMANDS_DATA__BUILDER_HPP_
