// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from data_flow:msg/MotionCommandsData.idl
// generated code does not contain a copyright notice

#include "data_flow/msg/detail/motion_commands_data__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_data_flow
const rosidl_type_hash_t *
data_flow__msg__MotionCommandsData__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x4b, 0xb1, 0xd5, 0x1d, 0x21, 0x03, 0x20, 0x56,
      0x63, 0x3f, 0x38, 0x7a, 0xae, 0xde, 0x76, 0x85,
      0xe2, 0xd1, 0xec, 0xf6, 0xa8, 0x89, 0xa9, 0xd0,
      0x59, 0xf9, 0xa3, 0x7c, 0x7f, 0xb9, 0x63, 0x15,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char data_flow__msg__MotionCommandsData__TYPE_NAME[] = "data_flow/msg/MotionCommandsData";

// Define type names, field names, and default values
static char data_flow__msg__MotionCommandsData__FIELD_NAME__angle_delta_command[] = "angle_delta_command";
static char data_flow__msg__MotionCommandsData__FIELD_NAME__distance_motion_command[] = "distance_motion_command";
static char data_flow__msg__MotionCommandsData__FIELD_NAME__emergency_stop[] = "emergency_stop";
static char data_flow__msg__MotionCommandsData__FIELD_NAME__target_deviation_pourcentage[] = "target_deviation_pourcentage";
static char data_flow__msg__MotionCommandsData__FIELD_NAME__acceleration[] = "acceleration";

static rosidl_runtime_c__type_description__Field data_flow__msg__MotionCommandsData__FIELDS[] = {
  {
    {data_flow__msg__MotionCommandsData__FIELD_NAME__angle_delta_command, 19, 19},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__MotionCommandsData__FIELD_NAME__distance_motion_command, 23, 23},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__MotionCommandsData__FIELD_NAME__emergency_stop, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__MotionCommandsData__FIELD_NAME__target_deviation_pourcentage, 28, 28},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__MotionCommandsData__FIELD_NAME__acceleration, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
data_flow__msg__MotionCommandsData__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {data_flow__msg__MotionCommandsData__TYPE_NAME, 32, 32},
      {data_flow__msg__MotionCommandsData__FIELDS, 5, 5},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "float32 angle_delta_command\n"
  "float32 distance_motion_command\n"
  "bool emergency_stop\n"
  " # set true occur emergency stop\n"
  " # set false not occur emergency stop\n"
  "float32 target_deviation_pourcentage\n"
  "float32 acceleration";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
data_flow__msg__MotionCommandsData__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {data_flow__msg__MotionCommandsData__TYPE_NAME, 32, 32},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 209, 209},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
data_flow__msg__MotionCommandsData__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *data_flow__msg__MotionCommandsData__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
