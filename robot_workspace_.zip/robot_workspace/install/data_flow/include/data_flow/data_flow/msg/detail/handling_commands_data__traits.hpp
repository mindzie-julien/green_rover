// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from data_flow:msg/HandlingCommandsData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__HANDLING_COMMANDS_DATA__TRAITS_HPP_
#define DATA_FLOW__MSG__DETAIL__HANDLING_COMMANDS_DATA__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "data_flow/msg/detail/handling_commands_data__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace data_flow
{

namespace msg
{

inline void to_flow_style_yaml(
  const HandlingCommandsData & msg,
  std::ostream & out)
{
  out << "{";
  // member: actuator_pliers_forward
  {
    if (msg.actuator_pliers_forward.size() == 0) {
      out << "actuator_pliers_forward: []";
    } else {
      out << "actuator_pliers_forward: [";
      size_t pending_items = msg.actuator_pliers_forward.size();
      for (auto item : msg.actuator_pliers_forward) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: actuator_pliers_backward
  {
    if (msg.actuator_pliers_backward.size() == 0) {
      out << "actuator_pliers_backward: []";
    } else {
      out << "actuator_pliers_backward: [";
      size_t pending_items = msg.actuator_pliers_backward.size();
      for (auto item : msg.actuator_pliers_backward) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: actuator_solar_panel_forward
  {
    out << "actuator_solar_panel_forward: ";
    rosidl_generator_traits::value_to_yaml(msg.actuator_solar_panel_forward, out);
    out << ", ";
  }

  // member: actuator_solar_panel_backward
  {
    out << "actuator_solar_panel_backward: ";
    rosidl_generator_traits::value_to_yaml(msg.actuator_solar_panel_backward, out);
    out << ", ";
  }

  // member: actuator_level_hand_forward
  {
    out << "actuator_level_hand_forward: ";
    rosidl_generator_traits::value_to_yaml(msg.actuator_level_hand_forward, out);
    out << ", ";
  }

  // member: actuator_level_hand_backward
  {
    out << "actuator_level_hand_backward: ";
    rosidl_generator_traits::value_to_yaml(msg.actuator_level_hand_backward, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const HandlingCommandsData & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: actuator_pliers_forward
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.actuator_pliers_forward.size() == 0) {
      out << "actuator_pliers_forward: []\n";
    } else {
      out << "actuator_pliers_forward:\n";
      for (auto item : msg.actuator_pliers_forward) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: actuator_pliers_backward
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.actuator_pliers_backward.size() == 0) {
      out << "actuator_pliers_backward: []\n";
    } else {
      out << "actuator_pliers_backward:\n";
      for (auto item : msg.actuator_pliers_backward) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: actuator_solar_panel_forward
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "actuator_solar_panel_forward: ";
    rosidl_generator_traits::value_to_yaml(msg.actuator_solar_panel_forward, out);
    out << "\n";
  }

  // member: actuator_solar_panel_backward
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "actuator_solar_panel_backward: ";
    rosidl_generator_traits::value_to_yaml(msg.actuator_solar_panel_backward, out);
    out << "\n";
  }

  // member: actuator_level_hand_forward
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "actuator_level_hand_forward: ";
    rosidl_generator_traits::value_to_yaml(msg.actuator_level_hand_forward, out);
    out << "\n";
  }

  // member: actuator_level_hand_backward
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "actuator_level_hand_backward: ";
    rosidl_generator_traits::value_to_yaml(msg.actuator_level_hand_backward, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const HandlingCommandsData & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace data_flow

namespace rosidl_generator_traits
{

[[deprecated("use data_flow::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const data_flow::msg::HandlingCommandsData & msg,
  std::ostream & out, size_t indentation = 0)
{
  data_flow::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use data_flow::msg::to_yaml() instead")]]
inline std::string to_yaml(const data_flow::msg::HandlingCommandsData & msg)
{
  return data_flow::msg::to_yaml(msg);
}

template<>
inline const char * data_type<data_flow::msg::HandlingCommandsData>()
{
  return "data_flow::msg::HandlingCommandsData";
}

template<>
inline const char * name<data_flow::msg::HandlingCommandsData>()
{
  return "data_flow/msg/HandlingCommandsData";
}

template<>
struct has_fixed_size<data_flow::msg::HandlingCommandsData>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<data_flow::msg::HandlingCommandsData>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<data_flow::msg::HandlingCommandsData>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DATA_FLOW__MSG__DETAIL__HANDLING_COMMANDS_DATA__TRAITS_HPP_
