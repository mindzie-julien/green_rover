// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from data_flow:msg/ActionCommandsData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__ACTION_COMMANDS_DATA__STRUCT_H_
#define DATA_FLOW__MSG__DETAIL__ACTION_COMMANDS_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Constant 'SMALL_BLUE_SIDE_BLUE'.
static const char * const data_flow__msg__ActionCommandsData__SMALL_BLUE_SIDE_BLUE = "sbsb";

/// Constant 'SMALL_BLUE_SIDE_YELLOW'.
static const char * const data_flow__msg__ActionCommandsData__SMALL_BLUE_SIDE_YELLOW = "sbsy";

/// Constant 'LARGE_BLUE_AREA'.
static const char * const data_flow__msg__ActionCommandsData__LARGE_BLUE_AREA = "lba";

/// Constant 'SMALL_YELLOW_SIDE_BLUE'.
static const char * const data_flow__msg__ActionCommandsData__SMALL_YELLOW_SIDE_BLUE = "sysb";

/// Constant 'SMALL_YELLOW_SIDE_YELLOW'.
static const char * const data_flow__msg__ActionCommandsData__SMALL_YELLOW_SIDE_YELLOW = "sysy";

/// Constant 'LARGE_YELLOW_AREA'.
static const char * const data_flow__msg__ActionCommandsData__LARGE_YELLOW_AREA = "lya";

/// Constant 'PLANT_AREA_FORWARD_SIDE_BLUE'.
static const char * const data_flow__msg__ActionCommandsData__PLANT_AREA_FORWARD_SIDE_BLUE = "pafsb";

/// Constant 'PLANT_AREA_BACKWARD_SIDE_BLUE'.
static const char * const data_flow__msg__ActionCommandsData__PLANT_AREA_BACKWARD_SIDE_BLUE = "pabsb";

/// Constant 'PLANT_AREA_FORWARD_SIDE_MIDDLE'.
static const char * const data_flow__msg__ActionCommandsData__PLANT_AREA_FORWARD_SIDE_MIDDLE = "pafsm";

/// Constant 'PLANT_AREA_BACKWARD_SIDE_MIDDLE'.
static const char * const data_flow__msg__ActionCommandsData__PLANT_AREA_BACKWARD_SIDE_MIDDLE = "pabsm";

/// Constant 'PLANT_AREA_FORWARD_SIDE_YELLOW'.
static const char * const data_flow__msg__ActionCommandsData__PLANT_AREA_FORWARD_SIDE_YELLOW = "pafsy";

/// Constant 'PLANT_AREA_BACKWARD_SIDE_YELLOW'.
static const char * const data_flow__msg__ActionCommandsData__PLANT_AREA_BACKWARD_SIDE_YELLOW = "pabsy";

/// Constant 'POT_AREA_FORWARD_SIDE_BLUE'.
static const char * const data_flow__msg__ActionCommandsData__POT_AREA_FORWARD_SIDE_BLUE = "Pafsb";

/// Constant 'POT_AREA_BACKWARD_SIDE_BLUE'.
static const char * const data_flow__msg__ActionCommandsData__POT_AREA_BACKWARD_SIDE_BLUE = "Pabsb";

/// Constant 'POT_AREA_FORWARD_SIDE_MIDDLE'.
static const char * const data_flow__msg__ActionCommandsData__POT_AREA_FORWARD_SIDE_MIDDLE = "Pafsm";

/// Constant 'POT_AREA_BACKWARD_SIDE_MIDDLE'.
static const char * const data_flow__msg__ActionCommandsData__POT_AREA_BACKWARD_SIDE_MIDDLE = "Pabsm";

/// Constant 'POT_AREA_FORWARD_SIDE_YELLOW'.
static const char * const data_flow__msg__ActionCommandsData__POT_AREA_FORWARD_SIDE_YELLOW = "Pafsy";

/// Constant 'POT_AREA_BACKWARD_SIDE_YELLOW'.
static const char * const data_flow__msg__ActionCommandsData__POT_AREA_BACKWARD_SIDE_YELLOW = "Pabsy";

/// Constant 'GARDEN_AREA_FORWARD_SIDE_BLUE'.
static const char * const data_flow__msg__ActionCommandsData__GARDEN_AREA_FORWARD_SIDE_BLUE = "gafsb";

/// Constant 'GARDEN_AREA_BACKWARD_SIDE_BLUE'.
static const char * const data_flow__msg__ActionCommandsData__GARDEN_AREA_BACKWARD_SIDE_BLUE = "gabsb";

/// Constant 'GARDEN_AREA_FORWARD_SIDE_MIDDLE'.
static const char * const data_flow__msg__ActionCommandsData__GARDEN_AREA_FORWARD_SIDE_MIDDLE = "gafsm";

/// Constant 'GARDEN_AREA_BACKWARD_SIDE_MIDDLE'.
static const char * const data_flow__msg__ActionCommandsData__GARDEN_AREA_BACKWARD_SIDE_MIDDLE = "gabsm";

/// Constant 'GARDEN_AREA_FORWARD_SIDE_YELLOW'.
static const char * const data_flow__msg__ActionCommandsData__GARDEN_AREA_FORWARD_SIDE_YELLOW = "gafsy";

/// Constant 'GARDEN_AREA_BACKWARD_SIDE_YELLOW'.
static const char * const data_flow__msg__ActionCommandsData__GARDEN_AREA_BACKWARD_SIDE_YELLOW = "gabsy";

/// Constant 'SOLAR_AREA_BLUE_SIDE_BLUE'.
static const char * const data_flow__msg__ActionCommandsData__SOLAR_AREA_BLUE_SIDE_BLUE = "sabsb";

/// Constant 'SOLAR_AREA_MIDDLE_SIDE_BLUE'.
static const char * const data_flow__msg__ActionCommandsData__SOLAR_AREA_MIDDLE_SIDE_BLUE = "samsb";

/// Constant 'SOLAR_AREA_YELLOW_SIDE_BLUE'.
static const char * const data_flow__msg__ActionCommandsData__SOLAR_AREA_YELLOW_SIDE_BLUE = "saysb";

/// Constant 'SOLAR_AREA_BLUE_SIDE_YELLOW'.
static const char * const data_flow__msg__ActionCommandsData__SOLAR_AREA_BLUE_SIDE_YELLOW = "sabsy";

/// Constant 'SOLAR_AREA_MIDDLE_SIDE_YELLOW'.
static const char * const data_flow__msg__ActionCommandsData__SOLAR_AREA_MIDDLE_SIDE_YELLOW = "samsy";

/// Constant 'SOLAR_AREA_YELLOW_SIDE_YELLOW'.
static const char * const data_flow__msg__ActionCommandsData__SOLAR_AREA_YELLOW_SIDE_YELLOW = "saysy";

/// Constant 'CENTER'.
static const char * const data_flow__msg__ActionCommandsData__CENTER = "center";

// Include directives for member types
// Member 'target'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/ActionCommandsData in the package data_flow.
typedef struct data_flow__msg__ActionCommandsData
{
  rosidl_runtime_c__String target;
  /// set true occur emergency stop
  /// set false not occur emergency stop
  bool emergency_stop;
} data_flow__msg__ActionCommandsData;

// Struct for a sequence of data_flow__msg__ActionCommandsData.
typedef struct data_flow__msg__ActionCommandsData__Sequence
{
  data_flow__msg__ActionCommandsData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__msg__ActionCommandsData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DATA_FLOW__MSG__DETAIL__ACTION_COMMANDS_DATA__STRUCT_H_
