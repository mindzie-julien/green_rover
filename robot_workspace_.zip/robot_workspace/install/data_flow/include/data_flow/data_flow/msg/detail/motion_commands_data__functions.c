// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from data_flow:msg/MotionCommandsData.idl
// generated code does not contain a copyright notice
#include "data_flow/msg/detail/motion_commands_data__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
data_flow__msg__MotionCommandsData__init(data_flow__msg__MotionCommandsData * msg)
{
  if (!msg) {
    return false;
  }
  // angle_delta_command
  // distance_motion_command
  // emergency_stop
  // target_deviation_pourcentage
  // acceleration
  return true;
}

void
data_flow__msg__MotionCommandsData__fini(data_flow__msg__MotionCommandsData * msg)
{
  if (!msg) {
    return;
  }
  // angle_delta_command
  // distance_motion_command
  // emergency_stop
  // target_deviation_pourcentage
  // acceleration
}

bool
data_flow__msg__MotionCommandsData__are_equal(const data_flow__msg__MotionCommandsData * lhs, const data_flow__msg__MotionCommandsData * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // angle_delta_command
  if (lhs->angle_delta_command != rhs->angle_delta_command) {
    return false;
  }
  // distance_motion_command
  if (lhs->distance_motion_command != rhs->distance_motion_command) {
    return false;
  }
  // emergency_stop
  if (lhs->emergency_stop != rhs->emergency_stop) {
    return false;
  }
  // target_deviation_pourcentage
  if (lhs->target_deviation_pourcentage != rhs->target_deviation_pourcentage) {
    return false;
  }
  // acceleration
  if (lhs->acceleration != rhs->acceleration) {
    return false;
  }
  return true;
}

bool
data_flow__msg__MotionCommandsData__copy(
  const data_flow__msg__MotionCommandsData * input,
  data_flow__msg__MotionCommandsData * output)
{
  if (!input || !output) {
    return false;
  }
  // angle_delta_command
  output->angle_delta_command = input->angle_delta_command;
  // distance_motion_command
  output->distance_motion_command = input->distance_motion_command;
  // emergency_stop
  output->emergency_stop = input->emergency_stop;
  // target_deviation_pourcentage
  output->target_deviation_pourcentage = input->target_deviation_pourcentage;
  // acceleration
  output->acceleration = input->acceleration;
  return true;
}

data_flow__msg__MotionCommandsData *
data_flow__msg__MotionCommandsData__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_flow__msg__MotionCommandsData * msg = (data_flow__msg__MotionCommandsData *)allocator.allocate(sizeof(data_flow__msg__MotionCommandsData), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(data_flow__msg__MotionCommandsData));
  bool success = data_flow__msg__MotionCommandsData__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
data_flow__msg__MotionCommandsData__destroy(data_flow__msg__MotionCommandsData * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    data_flow__msg__MotionCommandsData__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
data_flow__msg__MotionCommandsData__Sequence__init(data_flow__msg__MotionCommandsData__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_flow__msg__MotionCommandsData * data = NULL;

  if (size) {
    data = (data_flow__msg__MotionCommandsData *)allocator.zero_allocate(size, sizeof(data_flow__msg__MotionCommandsData), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = data_flow__msg__MotionCommandsData__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        data_flow__msg__MotionCommandsData__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
data_flow__msg__MotionCommandsData__Sequence__fini(data_flow__msg__MotionCommandsData__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      data_flow__msg__MotionCommandsData__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

data_flow__msg__MotionCommandsData__Sequence *
data_flow__msg__MotionCommandsData__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_flow__msg__MotionCommandsData__Sequence * array = (data_flow__msg__MotionCommandsData__Sequence *)allocator.allocate(sizeof(data_flow__msg__MotionCommandsData__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = data_flow__msg__MotionCommandsData__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
data_flow__msg__MotionCommandsData__Sequence__destroy(data_flow__msg__MotionCommandsData__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    data_flow__msg__MotionCommandsData__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
data_flow__msg__MotionCommandsData__Sequence__are_equal(const data_flow__msg__MotionCommandsData__Sequence * lhs, const data_flow__msg__MotionCommandsData__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!data_flow__msg__MotionCommandsData__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
data_flow__msg__MotionCommandsData__Sequence__copy(
  const data_flow__msg__MotionCommandsData__Sequence * input,
  data_flow__msg__MotionCommandsData__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(data_flow__msg__MotionCommandsData);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    data_flow__msg__MotionCommandsData * data =
      (data_flow__msg__MotionCommandsData *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!data_flow__msg__MotionCommandsData__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          data_flow__msg__MotionCommandsData__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!data_flow__msg__MotionCommandsData__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
