// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from data_flow:msg/NavigationData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__NAVIGATION_DATA__STRUCT_H_
#define DATA_FLOW__MSG__DETAIL__NAVIGATION_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Constant 'LEFT'.
static const char * const data_flow__msg__NavigationData__LEFT = "left";

// Include directives for member types
// Member 'direction'
// Member 'rotation_sense'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/NavigationData in the package data_flow.
typedef struct data_flow__msg__NavigationData
{
  float coord_x;
  float coord_y;
  float distance;
  rosidl_runtime_c__String direction;
  rosidl_runtime_c__String rotation_sense;
  float distance_completed;
} data_flow__msg__NavigationData;

// Struct for a sequence of data_flow__msg__NavigationData.
typedef struct data_flow__msg__NavigationData__Sequence
{
  data_flow__msg__NavigationData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__msg__NavigationData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DATA_FLOW__MSG__DETAIL__NAVIGATION_DATA__STRUCT_H_
