// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from data_flow:msg/ProcessedVideoData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__PROCESSED_VIDEO_DATA__STRUCT_H_
#define DATA_FLOW__MSG__DETAIL__PROCESSED_VIDEO_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Constant 'SMALL_BLUE_AREA'.
static const char * const data_flow__msg__ProcessedVideoData__SMALL_BLUE_AREA = "sba";

/// Constant 'LARGE_BLUE_AREA'.
static const char * const data_flow__msg__ProcessedVideoData__LARGE_BLUE_AREA = "lba";

/// Constant 'SMALL_YELLOW_AREA'.
static const char * const data_flow__msg__ProcessedVideoData__SMALL_YELLOW_AREA = "sya";

/// Constant 'LARGE_YELLOW_AREA'.
static const char * const data_flow__msg__ProcessedVideoData__LARGE_YELLOW_AREA = "lya";

/// Constant 'SOLAR_PANEL_AREA'.
static const char * const data_flow__msg__ProcessedVideoData__SOLAR_PANEL_AREA = "spa";

/// Constant 'NORMAL_PLANT'.
static const char * const data_flow__msg__ProcessedVideoData__NORMAL_PLANT = "np";

/// Constant 'FRAGILE_PLANT'.
static const char * const data_flow__msg__ProcessedVideoData__FRAGILE_PLANT = "fp";

/// Constant 'PLANT_UPSIDE_DOWN_RIGHT'.
static const char * const data_flow__msg__ProcessedVideoData__PLANT_UPSIDE_DOWN_RIGHT = "pudr";

/// Constant 'PLANT_UPSIDE_DOWN_LEFT'.
static const char * const data_flow__msg__ProcessedVideoData__PLANT_UPSIDE_DOWN_LEFT = "pudl";

/// Constant 'PLANT_UPSIDE_DOWN_FORWARD'.
static const char * const data_flow__msg__ProcessedVideoData__PLANT_UPSIDE_DOWN_FORWARD = "pudf";

/// Constant 'PLANT_UPSIDE_DOWN_BACKWARD'.
static const char * const data_flow__msg__ProcessedVideoData__PLANT_UPSIDE_DOWN_BACKWARD = "pudb";

/// Constant 'OVERTUNED_POT_RIGHT'.
static const char * const data_flow__msg__ProcessedVideoData__OVERTUNED_POT_RIGHT = "opr";

/// Constant 'OVERTUNED_POT_LEFT'.
static const char * const data_flow__msg__ProcessedVideoData__OVERTUNED_POT_LEFT = "opl";

/// Constant 'OVERTUNED_POT_FORWARD'.
static const char * const data_flow__msg__ProcessedVideoData__OVERTUNED_POT_FORWARD = "opf";

/// Constant 'OVERTUNED_POT_BACKWARD'.
static const char * const data_flow__msg__ProcessedVideoData__OVERTUNED_POT_BACKWARD = "opb";

/// Constant 'CENTER'.
static const char * const data_flow__msg__ProcessedVideoData__CENTER = "center";

// Include directives for member types
// Member 'target_detection'
// Member 'target_navigation_detection'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/ProcessedVideoData in the package data_flow.
typedef struct data_flow__msg__ProcessedVideoData
{
  float target_deviation_pourcentage;
  rosidl_runtime_c__String target_detection;
  rosidl_runtime_c__String target_navigation_detection;
} data_flow__msg__ProcessedVideoData;

// Struct for a sequence of data_flow__msg__ProcessedVideoData.
typedef struct data_flow__msg__ProcessedVideoData__Sequence
{
  data_flow__msg__ProcessedVideoData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__msg__ProcessedVideoData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DATA_FLOW__MSG__DETAIL__PROCESSED_VIDEO_DATA__STRUCT_H_
