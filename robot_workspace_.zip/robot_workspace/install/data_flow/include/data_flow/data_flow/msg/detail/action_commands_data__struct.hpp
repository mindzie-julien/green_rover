// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from data_flow:msg/ActionCommandsData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__ACTION_COMMANDS_DATA__STRUCT_HPP_
#define DATA_FLOW__MSG__DETAIL__ACTION_COMMANDS_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__data_flow__msg__ActionCommandsData __attribute__((deprecated))
#else
# define DEPRECATED__data_flow__msg__ActionCommandsData __declspec(deprecated)
#endif

namespace data_flow
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ActionCommandsData_
{
  using Type = ActionCommandsData_<ContainerAllocator>;

  explicit ActionCommandsData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->target = "";
      this->emergency_stop = false;
    }
  }

  explicit ActionCommandsData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : target(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->target = "";
      this->emergency_stop = false;
    }
  }

  // field types and members
  using _target_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _target_type target;
  using _emergency_stop_type =
    bool;
  _emergency_stop_type emergency_stop;

  // setters for named parameter idiom
  Type & set__target(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->target = _arg;
    return *this;
  }
  Type & set__emergency_stop(
    const bool & _arg)
  {
    this->emergency_stop = _arg;
    return *this;
  }

  // constant declarations
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> SMALL_BLUE_SIDE_BLUE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> SMALL_BLUE_SIDE_YELLOW;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> LARGE_BLUE_AREA;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> SMALL_YELLOW_SIDE_BLUE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> SMALL_YELLOW_SIDE_YELLOW;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> LARGE_YELLOW_AREA;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> PLANT_AREA_FORWARD_SIDE_BLUE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> PLANT_AREA_BACKWARD_SIDE_BLUE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> PLANT_AREA_FORWARD_SIDE_MIDDLE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> PLANT_AREA_BACKWARD_SIDE_MIDDLE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> PLANT_AREA_FORWARD_SIDE_YELLOW;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> PLANT_AREA_BACKWARD_SIDE_YELLOW;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> POT_AREA_FORWARD_SIDE_BLUE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> POT_AREA_BACKWARD_SIDE_BLUE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> POT_AREA_FORWARD_SIDE_MIDDLE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> POT_AREA_BACKWARD_SIDE_MIDDLE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> POT_AREA_FORWARD_SIDE_YELLOW;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> POT_AREA_BACKWARD_SIDE_YELLOW;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> GARDEN_AREA_FORWARD_SIDE_BLUE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> GARDEN_AREA_BACKWARD_SIDE_BLUE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> GARDEN_AREA_FORWARD_SIDE_MIDDLE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> GARDEN_AREA_BACKWARD_SIDE_MIDDLE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> GARDEN_AREA_FORWARD_SIDE_YELLOW;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> GARDEN_AREA_BACKWARD_SIDE_YELLOW;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> SOLAR_AREA_BLUE_SIDE_BLUE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> SOLAR_AREA_MIDDLE_SIDE_BLUE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> SOLAR_AREA_YELLOW_SIDE_BLUE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> SOLAR_AREA_BLUE_SIDE_YELLOW;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> SOLAR_AREA_MIDDLE_SIDE_YELLOW;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> SOLAR_AREA_YELLOW_SIDE_YELLOW;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> CENTER;

  // pointer types
  using RawPtr =
    data_flow::msg::ActionCommandsData_<ContainerAllocator> *;
  using ConstRawPtr =
    const data_flow::msg::ActionCommandsData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<data_flow::msg::ActionCommandsData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<data_flow::msg::ActionCommandsData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      data_flow::msg::ActionCommandsData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<data_flow::msg::ActionCommandsData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      data_flow::msg::ActionCommandsData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<data_flow::msg::ActionCommandsData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<data_flow::msg::ActionCommandsData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<data_flow::msg::ActionCommandsData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__data_flow__msg__ActionCommandsData
    std::shared_ptr<data_flow::msg::ActionCommandsData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__data_flow__msg__ActionCommandsData
    std::shared_ptr<data_flow::msg::ActionCommandsData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ActionCommandsData_ & other) const
  {
    if (this->target != other.target) {
      return false;
    }
    if (this->emergency_stop != other.emergency_stop) {
      return false;
    }
    return true;
  }
  bool operator!=(const ActionCommandsData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ActionCommandsData_

// alias to use template instance with default allocator
using ActionCommandsData =
  data_flow::msg::ActionCommandsData_<std::allocator<void>>;

// constant definitions
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::SMALL_BLUE_SIDE_BLUE = "sbsb";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::SMALL_BLUE_SIDE_YELLOW = "sbsy";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::LARGE_BLUE_AREA = "lba";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::SMALL_YELLOW_SIDE_BLUE = "sysb";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::SMALL_YELLOW_SIDE_YELLOW = "sysy";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::LARGE_YELLOW_AREA = "lya";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::PLANT_AREA_FORWARD_SIDE_BLUE = "pafsb";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::PLANT_AREA_BACKWARD_SIDE_BLUE = "pabsb";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::PLANT_AREA_FORWARD_SIDE_MIDDLE = "pafsm";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::PLANT_AREA_BACKWARD_SIDE_MIDDLE = "pabsm";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::PLANT_AREA_FORWARD_SIDE_YELLOW = "pafsy";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::PLANT_AREA_BACKWARD_SIDE_YELLOW = "pabsy";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::POT_AREA_FORWARD_SIDE_BLUE = "Pafsb";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::POT_AREA_BACKWARD_SIDE_BLUE = "Pabsb";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::POT_AREA_FORWARD_SIDE_MIDDLE = "Pafsm";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::POT_AREA_BACKWARD_SIDE_MIDDLE = "Pabsm";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::POT_AREA_FORWARD_SIDE_YELLOW = "Pafsy";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::POT_AREA_BACKWARD_SIDE_YELLOW = "Pabsy";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::GARDEN_AREA_FORWARD_SIDE_BLUE = "gafsb";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::GARDEN_AREA_BACKWARD_SIDE_BLUE = "gabsb";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::GARDEN_AREA_FORWARD_SIDE_MIDDLE = "gafsm";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::GARDEN_AREA_BACKWARD_SIDE_MIDDLE = "gabsm";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::GARDEN_AREA_FORWARD_SIDE_YELLOW = "gafsy";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::GARDEN_AREA_BACKWARD_SIDE_YELLOW = "gabsy";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::SOLAR_AREA_BLUE_SIDE_BLUE = "sabsb";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::SOLAR_AREA_MIDDLE_SIDE_BLUE = "samsb";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::SOLAR_AREA_YELLOW_SIDE_BLUE = "saysb";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::SOLAR_AREA_BLUE_SIDE_YELLOW = "sabsy";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::SOLAR_AREA_MIDDLE_SIDE_YELLOW = "samsy";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::SOLAR_AREA_YELLOW_SIDE_YELLOW = "saysy";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ActionCommandsData_<ContainerAllocator>::CENTER = "center";

}  // namespace msg

}  // namespace data_flow

#endif  // DATA_FLOW__MSG__DETAIL__ACTION_COMMANDS_DATA__STRUCT_HPP_
