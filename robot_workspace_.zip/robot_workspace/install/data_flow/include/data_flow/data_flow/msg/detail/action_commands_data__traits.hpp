// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from data_flow:msg/ActionCommandsData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__ACTION_COMMANDS_DATA__TRAITS_HPP_
#define DATA_FLOW__MSG__DETAIL__ACTION_COMMANDS_DATA__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "data_flow/msg/detail/action_commands_data__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace data_flow
{

namespace msg
{

inline void to_flow_style_yaml(
  const ActionCommandsData & msg,
  std::ostream & out)
{
  out << "{";
  // member: target
  {
    out << "target: ";
    rosidl_generator_traits::value_to_yaml(msg.target, out);
    out << ", ";
  }

  // member: emergency_stop
  {
    out << "emergency_stop: ";
    rosidl_generator_traits::value_to_yaml(msg.emergency_stop, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ActionCommandsData & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: target
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "target: ";
    rosidl_generator_traits::value_to_yaml(msg.target, out);
    out << "\n";
  }

  // member: emergency_stop
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "emergency_stop: ";
    rosidl_generator_traits::value_to_yaml(msg.emergency_stop, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ActionCommandsData & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace data_flow

namespace rosidl_generator_traits
{

[[deprecated("use data_flow::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const data_flow::msg::ActionCommandsData & msg,
  std::ostream & out, size_t indentation = 0)
{
  data_flow::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use data_flow::msg::to_yaml() instead")]]
inline std::string to_yaml(const data_flow::msg::ActionCommandsData & msg)
{
  return data_flow::msg::to_yaml(msg);
}

template<>
inline const char * data_type<data_flow::msg::ActionCommandsData>()
{
  return "data_flow::msg::ActionCommandsData";
}

template<>
inline const char * name<data_flow::msg::ActionCommandsData>()
{
  return "data_flow/msg/ActionCommandsData";
}

template<>
struct has_fixed_size<data_flow::msg::ActionCommandsData>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<data_flow::msg::ActionCommandsData>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<data_flow::msg::ActionCommandsData>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DATA_FLOW__MSG__DETAIL__ACTION_COMMANDS_DATA__TRAITS_HPP_
