// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from data_flow:msg/MotionData.idl
// generated code does not contain a copyright notice

#include "data_flow/msg/detail/motion_data__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_data_flow
const rosidl_type_hash_t *
data_flow__msg__MotionData__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xb9, 0xc9, 0xf2, 0xa7, 0xbd, 0x33, 0xdc, 0x78,
      0x24, 0xa3, 0xc4, 0x0e, 0x66, 0xd0, 0x1a, 0x02,
      0xf0, 0x45, 0x4c, 0x0f, 0x7a, 0x71, 0xb4, 0x91,
      0xc0, 0x7d, 0xb1, 0x16, 0x58, 0x4a, 0xf7, 0xf9,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char data_flow__msg__MotionData__TYPE_NAME[] = "data_flow/msg/MotionData";

// Define type names, field names, and default values
static char data_flow__msg__MotionData__FIELD_NAME__direction[] = "direction";
static char data_flow__msg__MotionData__FIELD_NAME__rotation_sense[] = "rotation_sense";
static char data_flow__msg__MotionData__FIELD_NAME__distance_completed[] = "distance_completed";

static rosidl_runtime_c__type_description__Field data_flow__msg__MotionData__FIELDS[] = {
  {
    {data_flow__msg__MotionData__FIELD_NAME__direction, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__MotionData__FIELD_NAME__rotation_sense, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {data_flow__msg__MotionData__FIELD_NAME__distance_completed, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
data_flow__msg__MotionData__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {data_flow__msg__MotionData__TYPE_NAME, 24, 24},
      {data_flow__msg__MotionData__FIELDS, 3, 3},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "string FORWARD =\"forward\"\n"
  "string BACKWARD =\"backward\"\n"
  "string RIGHT =\"right\"\n"
  "string LEFT =\"left\"\n"
  "\n"
  "string direction\n"
  "string rotation_sense\n"
  "float32 distance_completed";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
data_flow__msg__MotionData__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {data_flow__msg__MotionData__TYPE_NAME, 24, 24},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 163, 163},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
data_flow__msg__MotionData__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *data_flow__msg__MotionData__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
