// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from data_flow:msg/ProcessedVideoData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__PROCESSED_VIDEO_DATA__STRUCT_HPP_
#define DATA_FLOW__MSG__DETAIL__PROCESSED_VIDEO_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__data_flow__msg__ProcessedVideoData __attribute__((deprecated))
#else
# define DEPRECATED__data_flow__msg__ProcessedVideoData __declspec(deprecated)
#endif

namespace data_flow
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ProcessedVideoData_
{
  using Type = ProcessedVideoData_<ContainerAllocator>;

  explicit ProcessedVideoData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->target_deviation_pourcentage = 0.0f;
      this->target_detection = "";
      this->target_navigation_detection = "";
    }
  }

  explicit ProcessedVideoData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : target_detection(_alloc),
    target_navigation_detection(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->target_deviation_pourcentage = 0.0f;
      this->target_detection = "";
      this->target_navigation_detection = "";
    }
  }

  // field types and members
  using _target_deviation_pourcentage_type =
    float;
  _target_deviation_pourcentage_type target_deviation_pourcentage;
  using _target_detection_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _target_detection_type target_detection;
  using _target_navigation_detection_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _target_navigation_detection_type target_navigation_detection;

  // setters for named parameter idiom
  Type & set__target_deviation_pourcentage(
    const float & _arg)
  {
    this->target_deviation_pourcentage = _arg;
    return *this;
  }
  Type & set__target_detection(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->target_detection = _arg;
    return *this;
  }
  Type & set__target_navigation_detection(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->target_navigation_detection = _arg;
    return *this;
  }

  // constant declarations
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> SMALL_BLUE_AREA;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> LARGE_BLUE_AREA;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> SMALL_YELLOW_AREA;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> LARGE_YELLOW_AREA;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> SOLAR_PANEL_AREA;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> NORMAL_PLANT;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> FRAGILE_PLANT;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> PLANT_UPSIDE_DOWN_RIGHT;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> PLANT_UPSIDE_DOWN_LEFT;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> PLANT_UPSIDE_DOWN_FORWARD;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> PLANT_UPSIDE_DOWN_BACKWARD;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> OVERTUNED_POT_RIGHT;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> OVERTUNED_POT_LEFT;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> OVERTUNED_POT_FORWARD;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> OVERTUNED_POT_BACKWARD;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> CENTER;

  // pointer types
  using RawPtr =
    data_flow::msg::ProcessedVideoData_<ContainerAllocator> *;
  using ConstRawPtr =
    const data_flow::msg::ProcessedVideoData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<data_flow::msg::ProcessedVideoData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<data_flow::msg::ProcessedVideoData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      data_flow::msg::ProcessedVideoData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<data_flow::msg::ProcessedVideoData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      data_flow::msg::ProcessedVideoData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<data_flow::msg::ProcessedVideoData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<data_flow::msg::ProcessedVideoData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<data_flow::msg::ProcessedVideoData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__data_flow__msg__ProcessedVideoData
    std::shared_ptr<data_flow::msg::ProcessedVideoData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__data_flow__msg__ProcessedVideoData
    std::shared_ptr<data_flow::msg::ProcessedVideoData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ProcessedVideoData_ & other) const
  {
    if (this->target_deviation_pourcentage != other.target_deviation_pourcentage) {
      return false;
    }
    if (this->target_detection != other.target_detection) {
      return false;
    }
    if (this->target_navigation_detection != other.target_navigation_detection) {
      return false;
    }
    return true;
  }
  bool operator!=(const ProcessedVideoData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ProcessedVideoData_

// alias to use template instance with default allocator
using ProcessedVideoData =
  data_flow::msg::ProcessedVideoData_<std::allocator<void>>;

// constant definitions
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ProcessedVideoData_<ContainerAllocator>::SMALL_BLUE_AREA = "sba";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ProcessedVideoData_<ContainerAllocator>::LARGE_BLUE_AREA = "lba";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ProcessedVideoData_<ContainerAllocator>::SMALL_YELLOW_AREA = "sya";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ProcessedVideoData_<ContainerAllocator>::LARGE_YELLOW_AREA = "lya";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ProcessedVideoData_<ContainerAllocator>::SOLAR_PANEL_AREA = "spa";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ProcessedVideoData_<ContainerAllocator>::NORMAL_PLANT = "np";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ProcessedVideoData_<ContainerAllocator>::FRAGILE_PLANT = "fp";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ProcessedVideoData_<ContainerAllocator>::PLANT_UPSIDE_DOWN_RIGHT = "pudr";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ProcessedVideoData_<ContainerAllocator>::PLANT_UPSIDE_DOWN_LEFT = "pudl";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ProcessedVideoData_<ContainerAllocator>::PLANT_UPSIDE_DOWN_FORWARD = "pudf";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ProcessedVideoData_<ContainerAllocator>::PLANT_UPSIDE_DOWN_BACKWARD = "pudb";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ProcessedVideoData_<ContainerAllocator>::OVERTUNED_POT_RIGHT = "opr";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ProcessedVideoData_<ContainerAllocator>::OVERTUNED_POT_LEFT = "opl";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ProcessedVideoData_<ContainerAllocator>::OVERTUNED_POT_FORWARD = "opf";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ProcessedVideoData_<ContainerAllocator>::OVERTUNED_POT_BACKWARD = "opb";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
ProcessedVideoData_<ContainerAllocator>::CENTER = "center";

}  // namespace msg

}  // namespace data_flow

#endif  // DATA_FLOW__MSG__DETAIL__PROCESSED_VIDEO_DATA__STRUCT_HPP_
