// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from data_flow:msg/MotionData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__MOTION_DATA__STRUCT_H_
#define DATA_FLOW__MSG__DETAIL__MOTION_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Constant 'FORWARD'.
static const char * const data_flow__msg__MotionData__FORWARD = "forward";

/// Constant 'BACKWARD'.
static const char * const data_flow__msg__MotionData__BACKWARD = "backward";

/// Constant 'RIGHT'.
static const char * const data_flow__msg__MotionData__RIGHT = "right";

/// Constant 'LEFT'.
static const char * const data_flow__msg__MotionData__LEFT = "left";

// Include directives for member types
// Member 'direction'
// Member 'rotation_sense'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/MotionData in the package data_flow.
typedef struct data_flow__msg__MotionData
{
  rosidl_runtime_c__String direction;
  rosidl_runtime_c__String rotation_sense;
  float distance_completed;
} data_flow__msg__MotionData;

// Struct for a sequence of data_flow__msg__MotionData.
typedef struct data_flow__msg__MotionData__Sequence
{
  data_flow__msg__MotionData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__msg__MotionData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DATA_FLOW__MSG__DETAIL__MOTION_DATA__STRUCT_H_
