// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from data_flow:msg/MapPositionData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__MAP_POSITION_DATA__BUILDER_HPP_
#define DATA_FLOW__MSG__DETAIL__MAP_POSITION_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "data_flow/msg/detail/map_position_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace data_flow
{

namespace msg
{

namespace builder
{

class Init_MapPositionData_coord_y
{
public:
  explicit Init_MapPositionData_coord_y(::data_flow::msg::MapPositionData & msg)
  : msg_(msg)
  {}
  ::data_flow::msg::MapPositionData coord_y(::data_flow::msg::MapPositionData::_coord_y_type arg)
  {
    msg_.coord_y = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::msg::MapPositionData msg_;
};

class Init_MapPositionData_coord_x
{
public:
  Init_MapPositionData_coord_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MapPositionData_coord_y coord_x(::data_flow::msg::MapPositionData::_coord_x_type arg)
  {
    msg_.coord_x = std::move(arg);
    return Init_MapPositionData_coord_y(msg_);
  }

private:
  ::data_flow::msg::MapPositionData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::msg::MapPositionData>()
{
  return data_flow::msg::builder::Init_MapPositionData_coord_x();
}

}  // namespace data_flow

#endif  // DATA_FLOW__MSG__DETAIL__MAP_POSITION_DATA__BUILDER_HPP_
