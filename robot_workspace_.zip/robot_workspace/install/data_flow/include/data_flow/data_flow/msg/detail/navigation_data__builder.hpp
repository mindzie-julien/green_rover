// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from data_flow:msg/NavigationData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__NAVIGATION_DATA__BUILDER_HPP_
#define DATA_FLOW__MSG__DETAIL__NAVIGATION_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "data_flow/msg/detail/navigation_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace data_flow
{

namespace msg
{

namespace builder
{

class Init_NavigationData_distance_completed
{
public:
  explicit Init_NavigationData_distance_completed(::data_flow::msg::NavigationData & msg)
  : msg_(msg)
  {}
  ::data_flow::msg::NavigationData distance_completed(::data_flow::msg::NavigationData::_distance_completed_type arg)
  {
    msg_.distance_completed = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::msg::NavigationData msg_;
};

class Init_NavigationData_rotation_sense
{
public:
  explicit Init_NavigationData_rotation_sense(::data_flow::msg::NavigationData & msg)
  : msg_(msg)
  {}
  Init_NavigationData_distance_completed rotation_sense(::data_flow::msg::NavigationData::_rotation_sense_type arg)
  {
    msg_.rotation_sense = std::move(arg);
    return Init_NavigationData_distance_completed(msg_);
  }

private:
  ::data_flow::msg::NavigationData msg_;
};

class Init_NavigationData_direction
{
public:
  explicit Init_NavigationData_direction(::data_flow::msg::NavigationData & msg)
  : msg_(msg)
  {}
  Init_NavigationData_rotation_sense direction(::data_flow::msg::NavigationData::_direction_type arg)
  {
    msg_.direction = std::move(arg);
    return Init_NavigationData_rotation_sense(msg_);
  }

private:
  ::data_flow::msg::NavigationData msg_;
};

class Init_NavigationData_distance
{
public:
  explicit Init_NavigationData_distance(::data_flow::msg::NavigationData & msg)
  : msg_(msg)
  {}
  Init_NavigationData_direction distance(::data_flow::msg::NavigationData::_distance_type arg)
  {
    msg_.distance = std::move(arg);
    return Init_NavigationData_direction(msg_);
  }

private:
  ::data_flow::msg::NavigationData msg_;
};

class Init_NavigationData_coord_y
{
public:
  explicit Init_NavigationData_coord_y(::data_flow::msg::NavigationData & msg)
  : msg_(msg)
  {}
  Init_NavigationData_distance coord_y(::data_flow::msg::NavigationData::_coord_y_type arg)
  {
    msg_.coord_y = std::move(arg);
    return Init_NavigationData_distance(msg_);
  }

private:
  ::data_flow::msg::NavigationData msg_;
};

class Init_NavigationData_coord_x
{
public:
  Init_NavigationData_coord_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NavigationData_coord_y coord_x(::data_flow::msg::NavigationData::_coord_x_type arg)
  {
    msg_.coord_x = std::move(arg);
    return Init_NavigationData_coord_y(msg_);
  }

private:
  ::data_flow::msg::NavigationData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::msg::NavigationData>()
{
  return data_flow::msg::builder::Init_NavigationData_coord_x();
}

}  // namespace data_flow

#endif  // DATA_FLOW__MSG__DETAIL__NAVIGATION_DATA__BUILDER_HPP_
