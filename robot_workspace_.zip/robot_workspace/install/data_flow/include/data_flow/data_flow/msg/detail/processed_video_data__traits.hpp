// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from data_flow:msg/ProcessedVideoData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__DETAIL__PROCESSED_VIDEO_DATA__TRAITS_HPP_
#define DATA_FLOW__MSG__DETAIL__PROCESSED_VIDEO_DATA__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "data_flow/msg/detail/processed_video_data__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace data_flow
{

namespace msg
{

inline void to_flow_style_yaml(
  const ProcessedVideoData & msg,
  std::ostream & out)
{
  out << "{";
  // member: target_deviation_pourcentage
  {
    out << "target_deviation_pourcentage: ";
    rosidl_generator_traits::value_to_yaml(msg.target_deviation_pourcentage, out);
    out << ", ";
  }

  // member: target_detection
  {
    out << "target_detection: ";
    rosidl_generator_traits::value_to_yaml(msg.target_detection, out);
    out << ", ";
  }

  // member: target_navigation_detection
  {
    out << "target_navigation_detection: ";
    rosidl_generator_traits::value_to_yaml(msg.target_navigation_detection, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ProcessedVideoData & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: target_deviation_pourcentage
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "target_deviation_pourcentage: ";
    rosidl_generator_traits::value_to_yaml(msg.target_deviation_pourcentage, out);
    out << "\n";
  }

  // member: target_detection
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "target_detection: ";
    rosidl_generator_traits::value_to_yaml(msg.target_detection, out);
    out << "\n";
  }

  // member: target_navigation_detection
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "target_navigation_detection: ";
    rosidl_generator_traits::value_to_yaml(msg.target_navigation_detection, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ProcessedVideoData & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace data_flow

namespace rosidl_generator_traits
{

[[deprecated("use data_flow::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const data_flow::msg::ProcessedVideoData & msg,
  std::ostream & out, size_t indentation = 0)
{
  data_flow::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use data_flow::msg::to_yaml() instead")]]
inline std::string to_yaml(const data_flow::msg::ProcessedVideoData & msg)
{
  return data_flow::msg::to_yaml(msg);
}

template<>
inline const char * data_type<data_flow::msg::ProcessedVideoData>()
{
  return "data_flow::msg::ProcessedVideoData";
}

template<>
inline const char * name<data_flow::msg::ProcessedVideoData>()
{
  return "data_flow/msg/ProcessedVideoData";
}

template<>
struct has_fixed_size<data_flow::msg::ProcessedVideoData>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<data_flow::msg::ProcessedVideoData>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<data_flow::msg::ProcessedVideoData>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DATA_FLOW__MSG__DETAIL__PROCESSED_VIDEO_DATA__TRAITS_HPP_
