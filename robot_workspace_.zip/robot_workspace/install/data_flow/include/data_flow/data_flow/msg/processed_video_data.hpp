// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__MSG__PROCESSED_VIDEO_DATA_HPP_
#define DATA_FLOW__MSG__PROCESSED_VIDEO_DATA_HPP_

#include "data_flow/msg/detail/processed_video_data__struct.hpp"
#include "data_flow/msg/detail/processed_video_data__builder.hpp"
#include "data_flow/msg/detail/processed_video_data__traits.hpp"

#endif  // DATA_FLOW__MSG__PROCESSED_VIDEO_DATA_HPP_
