// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from data_flow:srv/RemoteControlServiceData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__SRV__DETAIL__REMOTE_CONTROL_SERVICE_DATA__STRUCT_H_
#define DATA_FLOW__SRV__DETAIL__REMOTE_CONTROL_SERVICE_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'FORWARD'.
static const char * const data_flow__srv__RemoteControlServiceData_Request__FORWARD = "forward";

/// Constant 'BACKWARD'.
static const char * const data_flow__srv__RemoteControlServiceData_Request__BACKWARD = "backward";

/// Constant 'RIGHT'.
static const char * const data_flow__srv__RemoteControlServiceData_Request__RIGHT = "right";

/// Constant 'LEFT'.
static const char * const data_flow__srv__RemoteControlServiceData_Request__LEFT = "left";

/// Constant 'LOW_LEVEL_SPEED'.
static const char * const data_flow__srv__RemoteControlServiceData_Request__LOW_LEVEL_SPEED = "lls";

/// Constant 'MEDIUM_LEVEL_SPEED'.
static const char * const data_flow__srv__RemoteControlServiceData_Request__MEDIUM_LEVEL_SPEED = "mls";

/// Constant 'MAX_LEVEL_SPEED'.
static const char * const data_flow__srv__RemoteControlServiceData_Request__MAX_LEVEL_SPEED = "Mls";

/// Constant 'STOP'.
static const char * const data_flow__srv__RemoteControlServiceData_Request__STOP = "stop";

// Include directives for member types
// Member 'order'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/RemoteControlServiceData in the package data_flow.
typedef struct data_flow__srv__RemoteControlServiceData_Request
{
  rosidl_runtime_c__String order;
} data_flow__srv__RemoteControlServiceData_Request;

// Struct for a sequence of data_flow__srv__RemoteControlServiceData_Request.
typedef struct data_flow__srv__RemoteControlServiceData_Request__Sequence
{
  data_flow__srv__RemoteControlServiceData_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__srv__RemoteControlServiceData_Request__Sequence;

// Constants defined in the message

/// Struct defined in srv/RemoteControlServiceData in the package data_flow.
typedef struct data_flow__srv__RemoteControlServiceData_Response
{
  bool response;
} data_flow__srv__RemoteControlServiceData_Response;

// Struct for a sequence of data_flow__srv__RemoteControlServiceData_Response.
typedef struct data_flow__srv__RemoteControlServiceData_Response__Sequence
{
  data_flow__srv__RemoteControlServiceData_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__srv__RemoteControlServiceData_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  data_flow__srv__RemoteControlServiceData_Event__request__MAX_SIZE = 1
};
// response
enum
{
  data_flow__srv__RemoteControlServiceData_Event__response__MAX_SIZE = 1
};

/// Struct defined in srv/RemoteControlServiceData in the package data_flow.
typedef struct data_flow__srv__RemoteControlServiceData_Event
{
  service_msgs__msg__ServiceEventInfo info;
  data_flow__srv__RemoteControlServiceData_Request__Sequence request;
  data_flow__srv__RemoteControlServiceData_Response__Sequence response;
} data_flow__srv__RemoteControlServiceData_Event;

// Struct for a sequence of data_flow__srv__RemoteControlServiceData_Event.
typedef struct data_flow__srv__RemoteControlServiceData_Event__Sequence
{
  data_flow__srv__RemoteControlServiceData_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__srv__RemoteControlServiceData_Event__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DATA_FLOW__SRV__DETAIL__REMOTE_CONTROL_SERVICE_DATA__STRUCT_H_
