// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from data_flow:srv/StrategyServiceData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__SRV__DETAIL__STRATEGY_SERVICE_DATA__STRUCT_H_
#define DATA_FLOW__SRV__DETAIL__STRATEGY_SERVICE_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'STRATEGY_A'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_A = "a";

/// Constant 'STRATEGY_B'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_B = "b";

/// Constant 'STRATEGY_C'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_C = "c";

/// Constant 'STRATEGY_D'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_D = "d";

/// Constant 'STRATEGY_E'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_E = "e";

/// Constant 'STRATEGY_F'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_F = "f";

/// Constant 'STRATEGY_G'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_G = "g";

/// Constant 'STRATEGY_H'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_H = "h";

/// Constant 'STRATEGY_I'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_I = "i";

/// Constant 'STRATEGY_J'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_J = "j";

/// Constant 'STRATEGY_K'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_K = "k";

/// Constant 'STRATEGY_L'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_L = "l";

/// Constant 'STRATEGY_M'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_M = "m";

/// Constant 'STRATEGY_N'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_N = "n";

/// Constant 'STRATEGY_O'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_O = "o";

/// Constant 'STRATEGY_P'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_P = "p";

/// Constant 'STRATEGY_Q'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_Q = "q";

/// Constant 'STRATEGY_R'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_R = "r";

/// Constant 'STRATEGY_S'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_S = "s";

/// Constant 'STRATEGY_T'.
static const char * const data_flow__srv__StrategyServiceData_Request__STRATEGY_T = "t";

/// Constant 'SUCCESS_RESPONSE'.
static const char * const data_flow__srv__StrategyServiceData_Request__SUCCESS_RESPONSE = "order received";

/// Constant 'ERROR_RESPONSE'.
static const char * const data_flow__srv__StrategyServiceData_Request__ERROR_RESPONSE = "order not received";

// Include directives for member types
// Member 'order'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/StrategyServiceData in the package data_flow.
typedef struct data_flow__srv__StrategyServiceData_Request
{
  rosidl_runtime_c__String order;
} data_flow__srv__StrategyServiceData_Request;

// Struct for a sequence of data_flow__srv__StrategyServiceData_Request.
typedef struct data_flow__srv__StrategyServiceData_Request__Sequence
{
  data_flow__srv__StrategyServiceData_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__srv__StrategyServiceData_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'response'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in srv/StrategyServiceData in the package data_flow.
typedef struct data_flow__srv__StrategyServiceData_Response
{
  rosidl_runtime_c__String response;
} data_flow__srv__StrategyServiceData_Response;

// Struct for a sequence of data_flow__srv__StrategyServiceData_Response.
typedef struct data_flow__srv__StrategyServiceData_Response__Sequence
{
  data_flow__srv__StrategyServiceData_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__srv__StrategyServiceData_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  data_flow__srv__StrategyServiceData_Event__request__MAX_SIZE = 1
};
// response
enum
{
  data_flow__srv__StrategyServiceData_Event__response__MAX_SIZE = 1
};

/// Struct defined in srv/StrategyServiceData in the package data_flow.
typedef struct data_flow__srv__StrategyServiceData_Event
{
  service_msgs__msg__ServiceEventInfo info;
  data_flow__srv__StrategyServiceData_Request__Sequence request;
  data_flow__srv__StrategyServiceData_Response__Sequence response;
} data_flow__srv__StrategyServiceData_Event;

// Struct for a sequence of data_flow__srv__StrategyServiceData_Event.
typedef struct data_flow__srv__StrategyServiceData_Event__Sequence
{
  data_flow__srv__StrategyServiceData_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__srv__StrategyServiceData_Event__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DATA_FLOW__SRV__DETAIL__STRATEGY_SERVICE_DATA__STRUCT_H_
