// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from data_flow:srv/StrategyServiceData.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__SRV__DETAIL__STRATEGY_SERVICE_DATA__BUILDER_HPP_
#define DATA_FLOW__SRV__DETAIL__STRATEGY_SERVICE_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "data_flow/srv/detail/strategy_service_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace data_flow
{

namespace srv
{

namespace builder
{

class Init_StrategyServiceData_Request_order
{
public:
  Init_StrategyServiceData_Request_order()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::data_flow::srv::StrategyServiceData_Request order(::data_flow::srv::StrategyServiceData_Request::_order_type arg)
  {
    msg_.order = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::srv::StrategyServiceData_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::srv::StrategyServiceData_Request>()
{
  return data_flow::srv::builder::Init_StrategyServiceData_Request_order();
}

}  // namespace data_flow


namespace data_flow
{

namespace srv
{

namespace builder
{

class Init_StrategyServiceData_Response_response
{
public:
  Init_StrategyServiceData_Response_response()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::data_flow::srv::StrategyServiceData_Response response(::data_flow::srv::StrategyServiceData_Response::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::srv::StrategyServiceData_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::srv::StrategyServiceData_Response>()
{
  return data_flow::srv::builder::Init_StrategyServiceData_Response_response();
}

}  // namespace data_flow


namespace data_flow
{

namespace srv
{

namespace builder
{

class Init_StrategyServiceData_Event_response
{
public:
  explicit Init_StrategyServiceData_Event_response(::data_flow::srv::StrategyServiceData_Event & msg)
  : msg_(msg)
  {}
  ::data_flow::srv::StrategyServiceData_Event response(::data_flow::srv::StrategyServiceData_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::srv::StrategyServiceData_Event msg_;
};

class Init_StrategyServiceData_Event_request
{
public:
  explicit Init_StrategyServiceData_Event_request(::data_flow::srv::StrategyServiceData_Event & msg)
  : msg_(msg)
  {}
  Init_StrategyServiceData_Event_response request(::data_flow::srv::StrategyServiceData_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_StrategyServiceData_Event_response(msg_);
  }

private:
  ::data_flow::srv::StrategyServiceData_Event msg_;
};

class Init_StrategyServiceData_Event_info
{
public:
  Init_StrategyServiceData_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_StrategyServiceData_Event_request info(::data_flow::srv::StrategyServiceData_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_StrategyServiceData_Event_request(msg_);
  }

private:
  ::data_flow::srv::StrategyServiceData_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::srv::StrategyServiceData_Event>()
{
  return data_flow::srv::builder::Init_StrategyServiceData_Event_info();
}

}  // namespace data_flow

#endif  // DATA_FLOW__SRV__DETAIL__STRATEGY_SERVICE_DATA__BUILDER_HPP_
