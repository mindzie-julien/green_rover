// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from data_flow:srv/RemoteControlServiceData.idl
// generated code does not contain a copyright notice
#include "data_flow/srv/detail/remote_control_service_data__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"

// Include directives for member types
// Member `order`
#include "rosidl_runtime_c/string_functions.h"

bool
data_flow__srv__RemoteControlServiceData_Request__init(data_flow__srv__RemoteControlServiceData_Request * msg)
{
  if (!msg) {
    return false;
  }
  // order
  if (!rosidl_runtime_c__String__init(&msg->order)) {
    data_flow__srv__RemoteControlServiceData_Request__fini(msg);
    return false;
  }
  return true;
}

void
data_flow__srv__RemoteControlServiceData_Request__fini(data_flow__srv__RemoteControlServiceData_Request * msg)
{
  if (!msg) {
    return;
  }
  // order
  rosidl_runtime_c__String__fini(&msg->order);
}

bool
data_flow__srv__RemoteControlServiceData_Request__are_equal(const data_flow__srv__RemoteControlServiceData_Request * lhs, const data_flow__srv__RemoteControlServiceData_Request * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // order
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->order), &(rhs->order)))
  {
    return false;
  }
  return true;
}

bool
data_flow__srv__RemoteControlServiceData_Request__copy(
  const data_flow__srv__RemoteControlServiceData_Request * input,
  data_flow__srv__RemoteControlServiceData_Request * output)
{
  if (!input || !output) {
    return false;
  }
  // order
  if (!rosidl_runtime_c__String__copy(
      &(input->order), &(output->order)))
  {
    return false;
  }
  return true;
}

data_flow__srv__RemoteControlServiceData_Request *
data_flow__srv__RemoteControlServiceData_Request__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_flow__srv__RemoteControlServiceData_Request * msg = (data_flow__srv__RemoteControlServiceData_Request *)allocator.allocate(sizeof(data_flow__srv__RemoteControlServiceData_Request), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(data_flow__srv__RemoteControlServiceData_Request));
  bool success = data_flow__srv__RemoteControlServiceData_Request__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
data_flow__srv__RemoteControlServiceData_Request__destroy(data_flow__srv__RemoteControlServiceData_Request * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    data_flow__srv__RemoteControlServiceData_Request__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
data_flow__srv__RemoteControlServiceData_Request__Sequence__init(data_flow__srv__RemoteControlServiceData_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_flow__srv__RemoteControlServiceData_Request * data = NULL;

  if (size) {
    data = (data_flow__srv__RemoteControlServiceData_Request *)allocator.zero_allocate(size, sizeof(data_flow__srv__RemoteControlServiceData_Request), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = data_flow__srv__RemoteControlServiceData_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        data_flow__srv__RemoteControlServiceData_Request__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
data_flow__srv__RemoteControlServiceData_Request__Sequence__fini(data_flow__srv__RemoteControlServiceData_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      data_flow__srv__RemoteControlServiceData_Request__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

data_flow__srv__RemoteControlServiceData_Request__Sequence *
data_flow__srv__RemoteControlServiceData_Request__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_flow__srv__RemoteControlServiceData_Request__Sequence * array = (data_flow__srv__RemoteControlServiceData_Request__Sequence *)allocator.allocate(sizeof(data_flow__srv__RemoteControlServiceData_Request__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = data_flow__srv__RemoteControlServiceData_Request__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
data_flow__srv__RemoteControlServiceData_Request__Sequence__destroy(data_flow__srv__RemoteControlServiceData_Request__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    data_flow__srv__RemoteControlServiceData_Request__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
data_flow__srv__RemoteControlServiceData_Request__Sequence__are_equal(const data_flow__srv__RemoteControlServiceData_Request__Sequence * lhs, const data_flow__srv__RemoteControlServiceData_Request__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!data_flow__srv__RemoteControlServiceData_Request__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
data_flow__srv__RemoteControlServiceData_Request__Sequence__copy(
  const data_flow__srv__RemoteControlServiceData_Request__Sequence * input,
  data_flow__srv__RemoteControlServiceData_Request__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(data_flow__srv__RemoteControlServiceData_Request);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    data_flow__srv__RemoteControlServiceData_Request * data =
      (data_flow__srv__RemoteControlServiceData_Request *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!data_flow__srv__RemoteControlServiceData_Request__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          data_flow__srv__RemoteControlServiceData_Request__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!data_flow__srv__RemoteControlServiceData_Request__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


bool
data_flow__srv__RemoteControlServiceData_Response__init(data_flow__srv__RemoteControlServiceData_Response * msg)
{
  if (!msg) {
    return false;
  }
  // response
  return true;
}

void
data_flow__srv__RemoteControlServiceData_Response__fini(data_flow__srv__RemoteControlServiceData_Response * msg)
{
  if (!msg) {
    return;
  }
  // response
}

bool
data_flow__srv__RemoteControlServiceData_Response__are_equal(const data_flow__srv__RemoteControlServiceData_Response * lhs, const data_flow__srv__RemoteControlServiceData_Response * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // response
  if (lhs->response != rhs->response) {
    return false;
  }
  return true;
}

bool
data_flow__srv__RemoteControlServiceData_Response__copy(
  const data_flow__srv__RemoteControlServiceData_Response * input,
  data_flow__srv__RemoteControlServiceData_Response * output)
{
  if (!input || !output) {
    return false;
  }
  // response
  output->response = input->response;
  return true;
}

data_flow__srv__RemoteControlServiceData_Response *
data_flow__srv__RemoteControlServiceData_Response__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_flow__srv__RemoteControlServiceData_Response * msg = (data_flow__srv__RemoteControlServiceData_Response *)allocator.allocate(sizeof(data_flow__srv__RemoteControlServiceData_Response), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(data_flow__srv__RemoteControlServiceData_Response));
  bool success = data_flow__srv__RemoteControlServiceData_Response__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
data_flow__srv__RemoteControlServiceData_Response__destroy(data_flow__srv__RemoteControlServiceData_Response * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    data_flow__srv__RemoteControlServiceData_Response__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
data_flow__srv__RemoteControlServiceData_Response__Sequence__init(data_flow__srv__RemoteControlServiceData_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_flow__srv__RemoteControlServiceData_Response * data = NULL;

  if (size) {
    data = (data_flow__srv__RemoteControlServiceData_Response *)allocator.zero_allocate(size, sizeof(data_flow__srv__RemoteControlServiceData_Response), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = data_flow__srv__RemoteControlServiceData_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        data_flow__srv__RemoteControlServiceData_Response__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
data_flow__srv__RemoteControlServiceData_Response__Sequence__fini(data_flow__srv__RemoteControlServiceData_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      data_flow__srv__RemoteControlServiceData_Response__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

data_flow__srv__RemoteControlServiceData_Response__Sequence *
data_flow__srv__RemoteControlServiceData_Response__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_flow__srv__RemoteControlServiceData_Response__Sequence * array = (data_flow__srv__RemoteControlServiceData_Response__Sequence *)allocator.allocate(sizeof(data_flow__srv__RemoteControlServiceData_Response__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = data_flow__srv__RemoteControlServiceData_Response__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
data_flow__srv__RemoteControlServiceData_Response__Sequence__destroy(data_flow__srv__RemoteControlServiceData_Response__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    data_flow__srv__RemoteControlServiceData_Response__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
data_flow__srv__RemoteControlServiceData_Response__Sequence__are_equal(const data_flow__srv__RemoteControlServiceData_Response__Sequence * lhs, const data_flow__srv__RemoteControlServiceData_Response__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!data_flow__srv__RemoteControlServiceData_Response__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
data_flow__srv__RemoteControlServiceData_Response__Sequence__copy(
  const data_flow__srv__RemoteControlServiceData_Response__Sequence * input,
  data_flow__srv__RemoteControlServiceData_Response__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(data_flow__srv__RemoteControlServiceData_Response);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    data_flow__srv__RemoteControlServiceData_Response * data =
      (data_flow__srv__RemoteControlServiceData_Response *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!data_flow__srv__RemoteControlServiceData_Response__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          data_flow__srv__RemoteControlServiceData_Response__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!data_flow__srv__RemoteControlServiceData_Response__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `info`
#include "service_msgs/msg/detail/service_event_info__functions.h"
// Member `request`
// Member `response`
// already included above
// #include "data_flow/srv/detail/remote_control_service_data__functions.h"

bool
data_flow__srv__RemoteControlServiceData_Event__init(data_flow__srv__RemoteControlServiceData_Event * msg)
{
  if (!msg) {
    return false;
  }
  // info
  if (!service_msgs__msg__ServiceEventInfo__init(&msg->info)) {
    data_flow__srv__RemoteControlServiceData_Event__fini(msg);
    return false;
  }
  // request
  if (!data_flow__srv__RemoteControlServiceData_Request__Sequence__init(&msg->request, 0)) {
    data_flow__srv__RemoteControlServiceData_Event__fini(msg);
    return false;
  }
  // response
  if (!data_flow__srv__RemoteControlServiceData_Response__Sequence__init(&msg->response, 0)) {
    data_flow__srv__RemoteControlServiceData_Event__fini(msg);
    return false;
  }
  return true;
}

void
data_flow__srv__RemoteControlServiceData_Event__fini(data_flow__srv__RemoteControlServiceData_Event * msg)
{
  if (!msg) {
    return;
  }
  // info
  service_msgs__msg__ServiceEventInfo__fini(&msg->info);
  // request
  data_flow__srv__RemoteControlServiceData_Request__Sequence__fini(&msg->request);
  // response
  data_flow__srv__RemoteControlServiceData_Response__Sequence__fini(&msg->response);
}

bool
data_flow__srv__RemoteControlServiceData_Event__are_equal(const data_flow__srv__RemoteControlServiceData_Event * lhs, const data_flow__srv__RemoteControlServiceData_Event * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // info
  if (!service_msgs__msg__ServiceEventInfo__are_equal(
      &(lhs->info), &(rhs->info)))
  {
    return false;
  }
  // request
  if (!data_flow__srv__RemoteControlServiceData_Request__Sequence__are_equal(
      &(lhs->request), &(rhs->request)))
  {
    return false;
  }
  // response
  if (!data_flow__srv__RemoteControlServiceData_Response__Sequence__are_equal(
      &(lhs->response), &(rhs->response)))
  {
    return false;
  }
  return true;
}

bool
data_flow__srv__RemoteControlServiceData_Event__copy(
  const data_flow__srv__RemoteControlServiceData_Event * input,
  data_flow__srv__RemoteControlServiceData_Event * output)
{
  if (!input || !output) {
    return false;
  }
  // info
  if (!service_msgs__msg__ServiceEventInfo__copy(
      &(input->info), &(output->info)))
  {
    return false;
  }
  // request
  if (!data_flow__srv__RemoteControlServiceData_Request__Sequence__copy(
      &(input->request), &(output->request)))
  {
    return false;
  }
  // response
  if (!data_flow__srv__RemoteControlServiceData_Response__Sequence__copy(
      &(input->response), &(output->response)))
  {
    return false;
  }
  return true;
}

data_flow__srv__RemoteControlServiceData_Event *
data_flow__srv__RemoteControlServiceData_Event__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_flow__srv__RemoteControlServiceData_Event * msg = (data_flow__srv__RemoteControlServiceData_Event *)allocator.allocate(sizeof(data_flow__srv__RemoteControlServiceData_Event), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(data_flow__srv__RemoteControlServiceData_Event));
  bool success = data_flow__srv__RemoteControlServiceData_Event__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
data_flow__srv__RemoteControlServiceData_Event__destroy(data_flow__srv__RemoteControlServiceData_Event * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    data_flow__srv__RemoteControlServiceData_Event__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
data_flow__srv__RemoteControlServiceData_Event__Sequence__init(data_flow__srv__RemoteControlServiceData_Event__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_flow__srv__RemoteControlServiceData_Event * data = NULL;

  if (size) {
    data = (data_flow__srv__RemoteControlServiceData_Event *)allocator.zero_allocate(size, sizeof(data_flow__srv__RemoteControlServiceData_Event), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = data_flow__srv__RemoteControlServiceData_Event__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        data_flow__srv__RemoteControlServiceData_Event__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
data_flow__srv__RemoteControlServiceData_Event__Sequence__fini(data_flow__srv__RemoteControlServiceData_Event__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      data_flow__srv__RemoteControlServiceData_Event__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

data_flow__srv__RemoteControlServiceData_Event__Sequence *
data_flow__srv__RemoteControlServiceData_Event__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_flow__srv__RemoteControlServiceData_Event__Sequence * array = (data_flow__srv__RemoteControlServiceData_Event__Sequence *)allocator.allocate(sizeof(data_flow__srv__RemoteControlServiceData_Event__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = data_flow__srv__RemoteControlServiceData_Event__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
data_flow__srv__RemoteControlServiceData_Event__Sequence__destroy(data_flow__srv__RemoteControlServiceData_Event__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    data_flow__srv__RemoteControlServiceData_Event__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
data_flow__srv__RemoteControlServiceData_Event__Sequence__are_equal(const data_flow__srv__RemoteControlServiceData_Event__Sequence * lhs, const data_flow__srv__RemoteControlServiceData_Event__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!data_flow__srv__RemoteControlServiceData_Event__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
data_flow__srv__RemoteControlServiceData_Event__Sequence__copy(
  const data_flow__srv__RemoteControlServiceData_Event__Sequence * input,
  data_flow__srv__RemoteControlServiceData_Event__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(data_flow__srv__RemoteControlServiceData_Event);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    data_flow__srv__RemoteControlServiceData_Event * data =
      (data_flow__srv__RemoteControlServiceData_Event *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!data_flow__srv__RemoteControlServiceData_Event__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          data_flow__srv__RemoteControlServiceData_Event__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!data_flow__srv__RemoteControlServiceData_Event__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
