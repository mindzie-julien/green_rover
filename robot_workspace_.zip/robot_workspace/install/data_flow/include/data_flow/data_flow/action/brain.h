// generated from rosidl_generator_c/resource/idl.h.em
// with input from data_flow:action/Brain.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__ACTION__BRAIN_H_
#define DATA_FLOW__ACTION__BRAIN_H_

#include "data_flow/action/detail/brain__struct.h"
#include "data_flow/action/detail/brain__functions.h"
#include "data_flow/action/detail/brain__type_support.h"

#endif  // DATA_FLOW__ACTION__BRAIN_H_
