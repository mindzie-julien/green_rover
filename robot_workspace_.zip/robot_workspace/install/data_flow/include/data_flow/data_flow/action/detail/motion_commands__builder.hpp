// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from data_flow:action/MotionCommands.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__ACTION__DETAIL__MOTION_COMMANDS__BUILDER_HPP_
#define DATA_FLOW__ACTION__DETAIL__MOTION_COMMANDS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "data_flow/action/detail/motion_commands__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace data_flow
{

namespace action
{

namespace builder
{

class Init_MotionCommands_Goal_order
{
public:
  explicit Init_MotionCommands_Goal_order(::data_flow::action::MotionCommands_Goal & msg)
  : msg_(msg)
  {}
  ::data_flow::action::MotionCommands_Goal order(::data_flow::action::MotionCommands_Goal::_order_type arg)
  {
    msg_.order = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::action::MotionCommands_Goal msg_;
};

class Init_MotionCommands_Goal_emergency_stop
{
public:
  explicit Init_MotionCommands_Goal_emergency_stop(::data_flow::action::MotionCommands_Goal & msg)
  : msg_(msg)
  {}
  Init_MotionCommands_Goal_order emergency_stop(::data_flow::action::MotionCommands_Goal::_emergency_stop_type arg)
  {
    msg_.emergency_stop = std::move(arg);
    return Init_MotionCommands_Goal_order(msg_);
  }

private:
  ::data_flow::action::MotionCommands_Goal msg_;
};

class Init_MotionCommands_Goal_target
{
public:
  Init_MotionCommands_Goal_target()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MotionCommands_Goal_emergency_stop target(::data_flow::action::MotionCommands_Goal::_target_type arg)
  {
    msg_.target = std::move(arg);
    return Init_MotionCommands_Goal_emergency_stop(msg_);
  }

private:
  ::data_flow::action::MotionCommands_Goal msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::action::MotionCommands_Goal>()
{
  return data_flow::action::builder::Init_MotionCommands_Goal_target();
}

}  // namespace data_flow


namespace data_flow
{

namespace action
{

namespace builder
{

class Init_MotionCommands_Result_final_distance_completed
{
public:
  explicit Init_MotionCommands_Result_final_distance_completed(::data_flow::action::MotionCommands_Result & msg)
  : msg_(msg)
  {}
  ::data_flow::action::MotionCommands_Result final_distance_completed(::data_flow::action::MotionCommands_Result::_final_distance_completed_type arg)
  {
    msg_.final_distance_completed = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::action::MotionCommands_Result msg_;
};

class Init_MotionCommands_Result_final_angle_delta_completed
{
public:
  explicit Init_MotionCommands_Result_final_angle_delta_completed(::data_flow::action::MotionCommands_Result & msg)
  : msg_(msg)
  {}
  Init_MotionCommands_Result_final_distance_completed final_angle_delta_completed(::data_flow::action::MotionCommands_Result::_final_angle_delta_completed_type arg)
  {
    msg_.final_angle_delta_completed = std::move(arg);
    return Init_MotionCommands_Result_final_distance_completed(msg_);
  }

private:
  ::data_flow::action::MotionCommands_Result msg_;
};

class Init_MotionCommands_Result_order_reached
{
public:
  explicit Init_MotionCommands_Result_order_reached(::data_flow::action::MotionCommands_Result & msg)
  : msg_(msg)
  {}
  Init_MotionCommands_Result_final_angle_delta_completed order_reached(::data_flow::action::MotionCommands_Result::_order_reached_type arg)
  {
    msg_.order_reached = std::move(arg);
    return Init_MotionCommands_Result_final_angle_delta_completed(msg_);
  }

private:
  ::data_flow::action::MotionCommands_Result msg_;
};

class Init_MotionCommands_Result_target_reached
{
public:
  Init_MotionCommands_Result_target_reached()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MotionCommands_Result_order_reached target_reached(::data_flow::action::MotionCommands_Result::_target_reached_type arg)
  {
    msg_.target_reached = std::move(arg);
    return Init_MotionCommands_Result_order_reached(msg_);
  }

private:
  ::data_flow::action::MotionCommands_Result msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::action::MotionCommands_Result>()
{
  return data_flow::action::builder::Init_MotionCommands_Result_target_reached();
}

}  // namespace data_flow


namespace data_flow
{

namespace action
{

namespace builder
{

class Init_MotionCommands_Feedback_current_distance_completed
{
public:
  explicit Init_MotionCommands_Feedback_current_distance_completed(::data_flow::action::MotionCommands_Feedback & msg)
  : msg_(msg)
  {}
  ::data_flow::action::MotionCommands_Feedback current_distance_completed(::data_flow::action::MotionCommands_Feedback::_current_distance_completed_type arg)
  {
    msg_.current_distance_completed = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::action::MotionCommands_Feedback msg_;
};

class Init_MotionCommands_Feedback_current_angle_delta
{
public:
  explicit Init_MotionCommands_Feedback_current_angle_delta(::data_flow::action::MotionCommands_Feedback & msg)
  : msg_(msg)
  {}
  Init_MotionCommands_Feedback_current_distance_completed current_angle_delta(::data_flow::action::MotionCommands_Feedback::_current_angle_delta_type arg)
  {
    msg_.current_angle_delta = std::move(arg);
    return Init_MotionCommands_Feedback_current_distance_completed(msg_);
  }

private:
  ::data_flow::action::MotionCommands_Feedback msg_;
};

class Init_MotionCommands_Feedback_coord_y
{
public:
  explicit Init_MotionCommands_Feedback_coord_y(::data_flow::action::MotionCommands_Feedback & msg)
  : msg_(msg)
  {}
  Init_MotionCommands_Feedback_current_angle_delta coord_y(::data_flow::action::MotionCommands_Feedback::_coord_y_type arg)
  {
    msg_.coord_y = std::move(arg);
    return Init_MotionCommands_Feedback_current_angle_delta(msg_);
  }

private:
  ::data_flow::action::MotionCommands_Feedback msg_;
};

class Init_MotionCommands_Feedback_coord_x
{
public:
  Init_MotionCommands_Feedback_coord_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MotionCommands_Feedback_coord_y coord_x(::data_flow::action::MotionCommands_Feedback::_coord_x_type arg)
  {
    msg_.coord_x = std::move(arg);
    return Init_MotionCommands_Feedback_coord_y(msg_);
  }

private:
  ::data_flow::action::MotionCommands_Feedback msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::action::MotionCommands_Feedback>()
{
  return data_flow::action::builder::Init_MotionCommands_Feedback_coord_x();
}

}  // namespace data_flow


namespace data_flow
{

namespace action
{

namespace builder
{

class Init_MotionCommands_SendGoal_Request_goal
{
public:
  explicit Init_MotionCommands_SendGoal_Request_goal(::data_flow::action::MotionCommands_SendGoal_Request & msg)
  : msg_(msg)
  {}
  ::data_flow::action::MotionCommands_SendGoal_Request goal(::data_flow::action::MotionCommands_SendGoal_Request::_goal_type arg)
  {
    msg_.goal = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::action::MotionCommands_SendGoal_Request msg_;
};

class Init_MotionCommands_SendGoal_Request_goal_id
{
public:
  Init_MotionCommands_SendGoal_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MotionCommands_SendGoal_Request_goal goal_id(::data_flow::action::MotionCommands_SendGoal_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_MotionCommands_SendGoal_Request_goal(msg_);
  }

private:
  ::data_flow::action::MotionCommands_SendGoal_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::action::MotionCommands_SendGoal_Request>()
{
  return data_flow::action::builder::Init_MotionCommands_SendGoal_Request_goal_id();
}

}  // namespace data_flow


namespace data_flow
{

namespace action
{

namespace builder
{

class Init_MotionCommands_SendGoal_Response_stamp
{
public:
  explicit Init_MotionCommands_SendGoal_Response_stamp(::data_flow::action::MotionCommands_SendGoal_Response & msg)
  : msg_(msg)
  {}
  ::data_flow::action::MotionCommands_SendGoal_Response stamp(::data_flow::action::MotionCommands_SendGoal_Response::_stamp_type arg)
  {
    msg_.stamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::action::MotionCommands_SendGoal_Response msg_;
};

class Init_MotionCommands_SendGoal_Response_accepted
{
public:
  Init_MotionCommands_SendGoal_Response_accepted()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MotionCommands_SendGoal_Response_stamp accepted(::data_flow::action::MotionCommands_SendGoal_Response::_accepted_type arg)
  {
    msg_.accepted = std::move(arg);
    return Init_MotionCommands_SendGoal_Response_stamp(msg_);
  }

private:
  ::data_flow::action::MotionCommands_SendGoal_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::action::MotionCommands_SendGoal_Response>()
{
  return data_flow::action::builder::Init_MotionCommands_SendGoal_Response_accepted();
}

}  // namespace data_flow


namespace data_flow
{

namespace action
{

namespace builder
{

class Init_MotionCommands_SendGoal_Event_response
{
public:
  explicit Init_MotionCommands_SendGoal_Event_response(::data_flow::action::MotionCommands_SendGoal_Event & msg)
  : msg_(msg)
  {}
  ::data_flow::action::MotionCommands_SendGoal_Event response(::data_flow::action::MotionCommands_SendGoal_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::action::MotionCommands_SendGoal_Event msg_;
};

class Init_MotionCommands_SendGoal_Event_request
{
public:
  explicit Init_MotionCommands_SendGoal_Event_request(::data_flow::action::MotionCommands_SendGoal_Event & msg)
  : msg_(msg)
  {}
  Init_MotionCommands_SendGoal_Event_response request(::data_flow::action::MotionCommands_SendGoal_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_MotionCommands_SendGoal_Event_response(msg_);
  }

private:
  ::data_flow::action::MotionCommands_SendGoal_Event msg_;
};

class Init_MotionCommands_SendGoal_Event_info
{
public:
  Init_MotionCommands_SendGoal_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MotionCommands_SendGoal_Event_request info(::data_flow::action::MotionCommands_SendGoal_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_MotionCommands_SendGoal_Event_request(msg_);
  }

private:
  ::data_flow::action::MotionCommands_SendGoal_Event msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::action::MotionCommands_SendGoal_Event>()
{
  return data_flow::action::builder::Init_MotionCommands_SendGoal_Event_info();
}

}  // namespace data_flow


namespace data_flow
{

namespace action
{

namespace builder
{

class Init_MotionCommands_GetResult_Request_goal_id
{
public:
  Init_MotionCommands_GetResult_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::data_flow::action::MotionCommands_GetResult_Request goal_id(::data_flow::action::MotionCommands_GetResult_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::action::MotionCommands_GetResult_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::action::MotionCommands_GetResult_Request>()
{
  return data_flow::action::builder::Init_MotionCommands_GetResult_Request_goal_id();
}

}  // namespace data_flow


namespace data_flow
{

namespace action
{

namespace builder
{

class Init_MotionCommands_GetResult_Response_result
{
public:
  explicit Init_MotionCommands_GetResult_Response_result(::data_flow::action::MotionCommands_GetResult_Response & msg)
  : msg_(msg)
  {}
  ::data_flow::action::MotionCommands_GetResult_Response result(::data_flow::action::MotionCommands_GetResult_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::action::MotionCommands_GetResult_Response msg_;
};

class Init_MotionCommands_GetResult_Response_status
{
public:
  Init_MotionCommands_GetResult_Response_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MotionCommands_GetResult_Response_result status(::data_flow::action::MotionCommands_GetResult_Response::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_MotionCommands_GetResult_Response_result(msg_);
  }

private:
  ::data_flow::action::MotionCommands_GetResult_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::action::MotionCommands_GetResult_Response>()
{
  return data_flow::action::builder::Init_MotionCommands_GetResult_Response_status();
}

}  // namespace data_flow


namespace data_flow
{

namespace action
{

namespace builder
{

class Init_MotionCommands_GetResult_Event_response
{
public:
  explicit Init_MotionCommands_GetResult_Event_response(::data_flow::action::MotionCommands_GetResult_Event & msg)
  : msg_(msg)
  {}
  ::data_flow::action::MotionCommands_GetResult_Event response(::data_flow::action::MotionCommands_GetResult_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::action::MotionCommands_GetResult_Event msg_;
};

class Init_MotionCommands_GetResult_Event_request
{
public:
  explicit Init_MotionCommands_GetResult_Event_request(::data_flow::action::MotionCommands_GetResult_Event & msg)
  : msg_(msg)
  {}
  Init_MotionCommands_GetResult_Event_response request(::data_flow::action::MotionCommands_GetResult_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_MotionCommands_GetResult_Event_response(msg_);
  }

private:
  ::data_flow::action::MotionCommands_GetResult_Event msg_;
};

class Init_MotionCommands_GetResult_Event_info
{
public:
  Init_MotionCommands_GetResult_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MotionCommands_GetResult_Event_request info(::data_flow::action::MotionCommands_GetResult_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_MotionCommands_GetResult_Event_request(msg_);
  }

private:
  ::data_flow::action::MotionCommands_GetResult_Event msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::action::MotionCommands_GetResult_Event>()
{
  return data_flow::action::builder::Init_MotionCommands_GetResult_Event_info();
}

}  // namespace data_flow


namespace data_flow
{

namespace action
{

namespace builder
{

class Init_MotionCommands_FeedbackMessage_feedback
{
public:
  explicit Init_MotionCommands_FeedbackMessage_feedback(::data_flow::action::MotionCommands_FeedbackMessage & msg)
  : msg_(msg)
  {}
  ::data_flow::action::MotionCommands_FeedbackMessage feedback(::data_flow::action::MotionCommands_FeedbackMessage::_feedback_type arg)
  {
    msg_.feedback = std::move(arg);
    return std::move(msg_);
  }

private:
  ::data_flow::action::MotionCommands_FeedbackMessage msg_;
};

class Init_MotionCommands_FeedbackMessage_goal_id
{
public:
  Init_MotionCommands_FeedbackMessage_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MotionCommands_FeedbackMessage_feedback goal_id(::data_flow::action::MotionCommands_FeedbackMessage::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_MotionCommands_FeedbackMessage_feedback(msg_);
  }

private:
  ::data_flow::action::MotionCommands_FeedbackMessage msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::data_flow::action::MotionCommands_FeedbackMessage>()
{
  return data_flow::action::builder::Init_MotionCommands_FeedbackMessage_goal_id();
}

}  // namespace data_flow

#endif  // DATA_FLOW__ACTION__DETAIL__MOTION_COMMANDS__BUILDER_HPP_
