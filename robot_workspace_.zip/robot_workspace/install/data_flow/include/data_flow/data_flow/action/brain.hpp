// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__ACTION__BRAIN_HPP_
#define DATA_FLOW__ACTION__BRAIN_HPP_

#include "data_flow/action/detail/brain__struct.hpp"
#include "data_flow/action/detail/brain__builder.hpp"
#include "data_flow/action/detail/brain__traits.hpp"

#endif  // DATA_FLOW__ACTION__BRAIN_HPP_
