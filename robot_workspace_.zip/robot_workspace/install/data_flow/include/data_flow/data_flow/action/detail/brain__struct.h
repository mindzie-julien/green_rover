// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from data_flow:action/Brain.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__ACTION__DETAIL__BRAIN__STRUCT_H_
#define DATA_FLOW__ACTION__DETAIL__BRAIN__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'FORWARD'.
static const char * const data_flow__action__Brain_Goal__FORWARD = "forward";

/// Constant 'BACKWARD'.
static const char * const data_flow__action__Brain_Goal__BACKWARD = "backward";

/// Constant 'SMALL_BLUE_SIDE_BLUE'.
static const char * const data_flow__action__Brain_Goal__SMALL_BLUE_SIDE_BLUE = "sbsb";

/// Constant 'SMALL_BLUE_SIDE_YELLOW'.
static const char * const data_flow__action__Brain_Goal__SMALL_BLUE_SIDE_YELLOW = "sbsy";

/// Constant 'LARGE_BLUE_AREA'.
static const char * const data_flow__action__Brain_Goal__LARGE_BLUE_AREA = "lba";

/// Constant 'SMALL_YELLOW_SIDE_BLUE'.
static const char * const data_flow__action__Brain_Goal__SMALL_YELLOW_SIDE_BLUE = "sysb";

/// Constant 'SMALL_YELLOW_SIDE_YELLOW'.
static const char * const data_flow__action__Brain_Goal__SMALL_YELLOW_SIDE_YELLOW = "sysy";

/// Constant 'LARGE_YELLOW_AREA'.
static const char * const data_flow__action__Brain_Goal__LARGE_YELLOW_AREA = "lya";

/// Constant 'PLANT_AREA_FORWARD_SIDE_BLUE'.
static const char * const data_flow__action__Brain_Goal__PLANT_AREA_FORWARD_SIDE_BLUE = "pafsb";

/// Constant 'PLANT_AREA_BACKWARD_SIDE_BLUE'.
static const char * const data_flow__action__Brain_Goal__PLANT_AREA_BACKWARD_SIDE_BLUE = "pabsb";

/// Constant 'PLANT_AREA_FORWARD_SIDE_MIDDLE'.
static const char * const data_flow__action__Brain_Goal__PLANT_AREA_FORWARD_SIDE_MIDDLE = "pafsm";

/// Constant 'PLANT_AREA_BACKWARD_SIDE_MIDDLE'.
static const char * const data_flow__action__Brain_Goal__PLANT_AREA_BACKWARD_SIDE_MIDDLE = "pabsm";

/// Constant 'PLANT_AREA_FORWARD_SIDE_YELLOW'.
static const char * const data_flow__action__Brain_Goal__PLANT_AREA_FORWARD_SIDE_YELLOW = "pafsy";

/// Constant 'PLANT_AREA_BACKWARD_SIDE_YELLOW'.
static const char * const data_flow__action__Brain_Goal__PLANT_AREA_BACKWARD_SIDE_YELLOW = "pabsy";

/// Constant 'POT_AREA_FORWARD_SIDE_BLUE'.
static const char * const data_flow__action__Brain_Goal__POT_AREA_FORWARD_SIDE_BLUE = "Pafsb";

/// Constant 'POT_AREA_BACKWARD_SIDE_BLUE'.
static const char * const data_flow__action__Brain_Goal__POT_AREA_BACKWARD_SIDE_BLUE = "Pabsb";

/// Constant 'POT_AREA_FORWARD_SIDE_MIDDLE'.
static const char * const data_flow__action__Brain_Goal__POT_AREA_FORWARD_SIDE_MIDDLE = "Pafsm";

/// Constant 'POT_AREA_BACKWARD_SIDE_MIDDLE'.
static const char * const data_flow__action__Brain_Goal__POT_AREA_BACKWARD_SIDE_MIDDLE = "Pabsm";

/// Constant 'POT_AREA_FORWARD_SIDE_YELLOW'.
static const char * const data_flow__action__Brain_Goal__POT_AREA_FORWARD_SIDE_YELLOW = "Pafsy";

/// Constant 'POT_AREA_BACKWARD_SIDE_YELLOW'.
static const char * const data_flow__action__Brain_Goal__POT_AREA_BACKWARD_SIDE_YELLOW = "Pabsy";

/// Constant 'GARDEN_AREA_FORWARD_SIDE_BLUE'.
static const char * const data_flow__action__Brain_Goal__GARDEN_AREA_FORWARD_SIDE_BLUE = "gafsb";

/// Constant 'GARDEN_AREA_BACKWARD_SIDE_BLUE'.
static const char * const data_flow__action__Brain_Goal__GARDEN_AREA_BACKWARD_SIDE_BLUE = "gabsb";

/// Constant 'GARDEN_AREA_FORWARD_SIDE_MIDDLE'.
static const char * const data_flow__action__Brain_Goal__GARDEN_AREA_FORWARD_SIDE_MIDDLE = "gafsm";

/// Constant 'GARDEN_AREA_BACKWARD_SIDE_MIDDLE'.
static const char * const data_flow__action__Brain_Goal__GARDEN_AREA_BACKWARD_SIDE_MIDDLE = "gabsm";

/// Constant 'GARDEN_AREA_FORWARD_SIDE_YELLOW'.
static const char * const data_flow__action__Brain_Goal__GARDEN_AREA_FORWARD_SIDE_YELLOW = "gafsy";

/// Constant 'GARDEN_AREA_BACKWARD_SIDE_YELLOW'.
static const char * const data_flow__action__Brain_Goal__GARDEN_AREA_BACKWARD_SIDE_YELLOW = "gabsy";

/// Constant 'SOLAR_AREA_BLUE_SIDE_BLUE'.
static const char * const data_flow__action__Brain_Goal__SOLAR_AREA_BLUE_SIDE_BLUE = "sabsb";

/// Constant 'SOLAR_AREA_MIDDLE_SIDE_BLUE'.
static const char * const data_flow__action__Brain_Goal__SOLAR_AREA_MIDDLE_SIDE_BLUE = "samsb";

/// Constant 'SOLAR_AREA_YELLOW_SIDE_BLUE'.
static const char * const data_flow__action__Brain_Goal__SOLAR_AREA_YELLOW_SIDE_BLUE = "saysb";

/// Constant 'SOLAR_AREA_BLUE_SIDE_YELLOW'.
static const char * const data_flow__action__Brain_Goal__SOLAR_AREA_BLUE_SIDE_YELLOW = "sabsy";

/// Constant 'SOLAR_AREA_MIDDLE_SIDE_YELLOW'.
static const char * const data_flow__action__Brain_Goal__SOLAR_AREA_MIDDLE_SIDE_YELLOW = "samsy";

/// Constant 'SOLAR_AREA_YELLOW_SIDE_YELLOW'.
static const char * const data_flow__action__Brain_Goal__SOLAR_AREA_YELLOW_SIDE_YELLOW = "saysy";

/// Constant 'CENTER'.
static const char * const data_flow__action__Brain_Goal__CENTER = "center";

// Include directives for member types
// Member 'target'
// Member 'order'
#include "rosidl_runtime_c/string.h"

/// Struct defined in action/Brain in the package data_flow.
typedef struct data_flow__action__Brain_Goal
{
  rosidl_runtime_c__String target;
  bool emergency_stop;
  /// set true occur emergency stop
  /// set false not occur emergency stop
  /// part1: the goal
  rosidl_runtime_c__String order;
} data_flow__action__Brain_Goal;

// Struct for a sequence of data_flow__action__Brain_Goal.
typedef struct data_flow__action__Brain_Goal__Sequence
{
  data_flow__action__Brain_Goal * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__Brain_Goal__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'target_reached'
// Member 'order_reached'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in action/Brain in the package data_flow.
typedef struct data_flow__action__Brain_Result
{
  rosidl_runtime_c__String target_reached;
  rosidl_runtime_c__String order_reached;
  float final_angle_delta_completed;
  float final_distance_completed;
} data_flow__action__Brain_Result;

// Struct for a sequence of data_flow__action__Brain_Result.
typedef struct data_flow__action__Brain_Result__Sequence
{
  data_flow__action__Brain_Result * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__Brain_Result__Sequence;

// Constants defined in the message

/// Struct defined in action/Brain in the package data_flow.
typedef struct data_flow__action__Brain_Feedback
{
  float coord_x;
  float coord_y;
  float current_angle_delta;
  float current_distance_completed;
} data_flow__action__Brain_Feedback;

// Struct for a sequence of data_flow__action__Brain_Feedback.
typedef struct data_flow__action__Brain_Feedback__Sequence
{
  data_flow__action__Brain_Feedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__Brain_Feedback__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'goal'
#include "data_flow/action/detail/brain__struct.h"

/// Struct defined in action/Brain in the package data_flow.
typedef struct data_flow__action__Brain_SendGoal_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
  data_flow__action__Brain_Goal goal;
} data_flow__action__Brain_SendGoal_Request;

// Struct for a sequence of data_flow__action__Brain_SendGoal_Request.
typedef struct data_flow__action__Brain_SendGoal_Request__Sequence
{
  data_flow__action__Brain_SendGoal_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__Brain_SendGoal_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in action/Brain in the package data_flow.
typedef struct data_flow__action__Brain_SendGoal_Response
{
  bool accepted;
  builtin_interfaces__msg__Time stamp;
} data_flow__action__Brain_SendGoal_Response;

// Struct for a sequence of data_flow__action__Brain_SendGoal_Response.
typedef struct data_flow__action__Brain_SendGoal_Response__Sequence
{
  data_flow__action__Brain_SendGoal_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__Brain_SendGoal_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  data_flow__action__Brain_SendGoal_Event__request__MAX_SIZE = 1
};
// response
enum
{
  data_flow__action__Brain_SendGoal_Event__response__MAX_SIZE = 1
};

/// Struct defined in action/Brain in the package data_flow.
typedef struct data_flow__action__Brain_SendGoal_Event
{
  service_msgs__msg__ServiceEventInfo info;
  data_flow__action__Brain_SendGoal_Request__Sequence request;
  data_flow__action__Brain_SendGoal_Response__Sequence response;
} data_flow__action__Brain_SendGoal_Event;

// Struct for a sequence of data_flow__action__Brain_SendGoal_Event.
typedef struct data_flow__action__Brain_SendGoal_Event__Sequence
{
  data_flow__action__Brain_SendGoal_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__Brain_SendGoal_Event__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"

/// Struct defined in action/Brain in the package data_flow.
typedef struct data_flow__action__Brain_GetResult_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
} data_flow__action__Brain_GetResult_Request;

// Struct for a sequence of data_flow__action__Brain_GetResult_Request.
typedef struct data_flow__action__Brain_GetResult_Request__Sequence
{
  data_flow__action__Brain_GetResult_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__Brain_GetResult_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'result'
// already included above
// #include "data_flow/action/detail/brain__struct.h"

/// Struct defined in action/Brain in the package data_flow.
typedef struct data_flow__action__Brain_GetResult_Response
{
  int8_t status;
  data_flow__action__Brain_Result result;
} data_flow__action__Brain_GetResult_Response;

// Struct for a sequence of data_flow__action__Brain_GetResult_Response.
typedef struct data_flow__action__Brain_GetResult_Response__Sequence
{
  data_flow__action__Brain_GetResult_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__Brain_GetResult_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
// already included above
// #include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  data_flow__action__Brain_GetResult_Event__request__MAX_SIZE = 1
};
// response
enum
{
  data_flow__action__Brain_GetResult_Event__response__MAX_SIZE = 1
};

/// Struct defined in action/Brain in the package data_flow.
typedef struct data_flow__action__Brain_GetResult_Event
{
  service_msgs__msg__ServiceEventInfo info;
  data_flow__action__Brain_GetResult_Request__Sequence request;
  data_flow__action__Brain_GetResult_Response__Sequence response;
} data_flow__action__Brain_GetResult_Event;

// Struct for a sequence of data_flow__action__Brain_GetResult_Event.
typedef struct data_flow__action__Brain_GetResult_Event__Sequence
{
  data_flow__action__Brain_GetResult_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__Brain_GetResult_Event__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'feedback'
// already included above
// #include "data_flow/action/detail/brain__struct.h"

/// Struct defined in action/Brain in the package data_flow.
typedef struct data_flow__action__Brain_FeedbackMessage
{
  unique_identifier_msgs__msg__UUID goal_id;
  data_flow__action__Brain_Feedback feedback;
} data_flow__action__Brain_FeedbackMessage;

// Struct for a sequence of data_flow__action__Brain_FeedbackMessage.
typedef struct data_flow__action__Brain_FeedbackMessage__Sequence
{
  data_flow__action__Brain_FeedbackMessage * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__Brain_FeedbackMessage__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DATA_FLOW__ACTION__DETAIL__BRAIN__STRUCT_H_
