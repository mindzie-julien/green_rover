// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from data_flow:action/ActuatorCommands.idl
// generated code does not contain a copyright notice

#ifndef DATA_FLOW__ACTION__DETAIL__ACTUATOR_COMMANDS__STRUCT_H_
#define DATA_FLOW__ACTION__DETAIL__ACTUATOR_COMMANDS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'actuator_data'
#include "rosidl_runtime_c/string.h"

/// Struct defined in action/ActuatorCommands in the package data_flow.
typedef struct data_flow__action__ActuatorCommands_Goal
{
  rosidl_runtime_c__String actuator_data;
} data_flow__action__ActuatorCommands_Goal;

// Struct for a sequence of data_flow__action__ActuatorCommands_Goal.
typedef struct data_flow__action__ActuatorCommands_Goal__Sequence
{
  data_flow__action__ActuatorCommands_Goal * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__ActuatorCommands_Goal__Sequence;

// Constants defined in the message

/// Struct defined in action/ActuatorCommands in the package data_flow.
typedef struct data_flow__action__ActuatorCommands_Result
{
  bool action_reached;
} data_flow__action__ActuatorCommands_Result;

// Struct for a sequence of data_flow__action__ActuatorCommands_Result.
typedef struct data_flow__action__ActuatorCommands_Result__Sequence
{
  data_flow__action__ActuatorCommands_Result * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__ActuatorCommands_Result__Sequence;

// Constants defined in the message

/// Struct defined in action/ActuatorCommands in the package data_flow.
typedef struct data_flow__action__ActuatorCommands_Feedback
{
  bool feedback;
} data_flow__action__ActuatorCommands_Feedback;

// Struct for a sequence of data_flow__action__ActuatorCommands_Feedback.
typedef struct data_flow__action__ActuatorCommands_Feedback__Sequence
{
  data_flow__action__ActuatorCommands_Feedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__ActuatorCommands_Feedback__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'goal'
#include "data_flow/action/detail/actuator_commands__struct.h"

/// Struct defined in action/ActuatorCommands in the package data_flow.
typedef struct data_flow__action__ActuatorCommands_SendGoal_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
  data_flow__action__ActuatorCommands_Goal goal;
} data_flow__action__ActuatorCommands_SendGoal_Request;

// Struct for a sequence of data_flow__action__ActuatorCommands_SendGoal_Request.
typedef struct data_flow__action__ActuatorCommands_SendGoal_Request__Sequence
{
  data_flow__action__ActuatorCommands_SendGoal_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__ActuatorCommands_SendGoal_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in action/ActuatorCommands in the package data_flow.
typedef struct data_flow__action__ActuatorCommands_SendGoal_Response
{
  bool accepted;
  builtin_interfaces__msg__Time stamp;
} data_flow__action__ActuatorCommands_SendGoal_Response;

// Struct for a sequence of data_flow__action__ActuatorCommands_SendGoal_Response.
typedef struct data_flow__action__ActuatorCommands_SendGoal_Response__Sequence
{
  data_flow__action__ActuatorCommands_SendGoal_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__ActuatorCommands_SendGoal_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  data_flow__action__ActuatorCommands_SendGoal_Event__request__MAX_SIZE = 1
};
// response
enum
{
  data_flow__action__ActuatorCommands_SendGoal_Event__response__MAX_SIZE = 1
};

/// Struct defined in action/ActuatorCommands in the package data_flow.
typedef struct data_flow__action__ActuatorCommands_SendGoal_Event
{
  service_msgs__msg__ServiceEventInfo info;
  data_flow__action__ActuatorCommands_SendGoal_Request__Sequence request;
  data_flow__action__ActuatorCommands_SendGoal_Response__Sequence response;
} data_flow__action__ActuatorCommands_SendGoal_Event;

// Struct for a sequence of data_flow__action__ActuatorCommands_SendGoal_Event.
typedef struct data_flow__action__ActuatorCommands_SendGoal_Event__Sequence
{
  data_flow__action__ActuatorCommands_SendGoal_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__ActuatorCommands_SendGoal_Event__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"

/// Struct defined in action/ActuatorCommands in the package data_flow.
typedef struct data_flow__action__ActuatorCommands_GetResult_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
} data_flow__action__ActuatorCommands_GetResult_Request;

// Struct for a sequence of data_flow__action__ActuatorCommands_GetResult_Request.
typedef struct data_flow__action__ActuatorCommands_GetResult_Request__Sequence
{
  data_flow__action__ActuatorCommands_GetResult_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__ActuatorCommands_GetResult_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'result'
// already included above
// #include "data_flow/action/detail/actuator_commands__struct.h"

/// Struct defined in action/ActuatorCommands in the package data_flow.
typedef struct data_flow__action__ActuatorCommands_GetResult_Response
{
  int8_t status;
  data_flow__action__ActuatorCommands_Result result;
} data_flow__action__ActuatorCommands_GetResult_Response;

// Struct for a sequence of data_flow__action__ActuatorCommands_GetResult_Response.
typedef struct data_flow__action__ActuatorCommands_GetResult_Response__Sequence
{
  data_flow__action__ActuatorCommands_GetResult_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__ActuatorCommands_GetResult_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
// already included above
// #include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  data_flow__action__ActuatorCommands_GetResult_Event__request__MAX_SIZE = 1
};
// response
enum
{
  data_flow__action__ActuatorCommands_GetResult_Event__response__MAX_SIZE = 1
};

/// Struct defined in action/ActuatorCommands in the package data_flow.
typedef struct data_flow__action__ActuatorCommands_GetResult_Event
{
  service_msgs__msg__ServiceEventInfo info;
  data_flow__action__ActuatorCommands_GetResult_Request__Sequence request;
  data_flow__action__ActuatorCommands_GetResult_Response__Sequence response;
} data_flow__action__ActuatorCommands_GetResult_Event;

// Struct for a sequence of data_flow__action__ActuatorCommands_GetResult_Event.
typedef struct data_flow__action__ActuatorCommands_GetResult_Event__Sequence
{
  data_flow__action__ActuatorCommands_GetResult_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__ActuatorCommands_GetResult_Event__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'feedback'
// already included above
// #include "data_flow/action/detail/actuator_commands__struct.h"

/// Struct defined in action/ActuatorCommands in the package data_flow.
typedef struct data_flow__action__ActuatorCommands_FeedbackMessage
{
  unique_identifier_msgs__msg__UUID goal_id;
  data_flow__action__ActuatorCommands_Feedback feedback;
} data_flow__action__ActuatorCommands_FeedbackMessage;

// Struct for a sequence of data_flow__action__ActuatorCommands_FeedbackMessage.
typedef struct data_flow__action__ActuatorCommands_FeedbackMessage__Sequence
{
  data_flow__action__ActuatorCommands_FeedbackMessage * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_flow__action__ActuatorCommands_FeedbackMessage__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DATA_FLOW__ACTION__DETAIL__ACTUATOR_COMMANDS__STRUCT_H_
