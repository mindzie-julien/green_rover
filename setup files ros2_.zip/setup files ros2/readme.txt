1-check the root path before start installation otherwise errors occur
2-set paths variables in files : 3,
