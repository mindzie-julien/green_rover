#!/bin/sh
mkdir -p ~/robot_workspace/src

#creation package principal
cd ~/robot_workspace/src
ros2 pkg create --build-type ament_python --license Apache-2.0 main_package

#construction du package principal
cd ~/robot_workspace
colcon build

# enable ros2 project automatic overlay sourcing
echo "# enable ros2 project automatic overlay sourcing" >> ~/.bashrc
echo "source ~/robot_workspace/install/local_setup.bash" >> ~/.bashrc
