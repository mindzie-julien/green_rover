#!/bin/sh
echo step 3 add depencies in CMakeLists.txt
pattern="# find dependencies"
adding_pattern="find_package(rosidl_default_generators REQUIRED) \n rosidl_generate_interfaces(\${PROJECT_NAME} \n \"msg/MotionData.msg\" \n \"msg/MapPositionData.msg\" \n \"msg/NavigationData.msg\" \n \"msg/SensorData.msg\" \n \"msg/MotionCommandsData.msg\" \n \"msg/HandlingCommandsData.msg\" \n \"msg/ProcessedVideoData.msg\" \n \"msg/ActionCommandsData.msg\" \n \"srv/RemoteControlServiceData.srv\" \n \"srv/StrategyServiceData.srv\" \n \"action/ActuatorCommands.action\" \n \"action/MotionCommands.action\" \n \"action/SensorFeedback.action\")"
file_path="/home/esigtronix/robot_workspace/src/data_flow/CMakeLists.txt"

if grep -q "$pattern" "$file_path"; then
	sed -i "/$pattern/a $adding_pattern" "$file_path"
	echo cmake depencies added
else
	echo error cmake depencies not added
fi

pattern="<buildtool_depend>"
adding_pattern="  \ \n  <buildtool_depend>rosidl_default_generators</buildtool_depend> \n\n  <exec_depend>rosidl_default_runtime</exec_depend> \n\n  <member_of_group>rosidl_interface_packages</member_of_group>"
file_path="/home/esigtronix/robot_workspace/src/data_flow/package.xml"

if grep -q "$pattern" "$file_path"; then
	sed -i "/$pattern/a $adding_pattern" "$file_path"
	echo depencies added
else
	echo error depencies not added
fi
