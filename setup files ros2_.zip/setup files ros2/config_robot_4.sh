#!/bin/sh
echo step 4 build data flow interface
# build data_flow interface
echo build data_flow interface
cd ~/robot_workspace
colcon build --packages-select data_flow
source install/setup.bash
