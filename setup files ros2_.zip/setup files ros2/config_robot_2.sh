#!/bin/sh
echo step 2 create data flow interface
# create data flow interface
echo "create data flow interface"
echo ""
cd  ~/robot_workspace/src
ros2 pkg create --build-type ament_cmake --license Apache-2.0 data_flow
cd  ~/robot_workspace/src/data_flow

# create data flow .msg and .srv files
echo "create data flow .msg and .srv files"
echo ""
mkdir msg srv action

# filling out files
echo "filling out files"
# writting .msg files
echo ".msg files builder is processing"
cd ~/robot_workspace/src/data_flow/msg

# writting MotionData.msg
echo "writting MotionData.msg"
echo "string FORWARD =\"forward\"" >> MotionData.msg
echo "string BACKWARD =\"backward\"" >> MotionData.msg
echo "string RIGHT =\"right\"" >> MotionData.msg
echo "string LEFT =\"left\"" >> MotionData.msg
echo "" >> MotionData.msg
echo "string direction" >> MotionData.msg
echo "string rotation_sense" >> MotionData.msg
echo "float32 distance_completed" >> MotionData.msg

# writting MapPositionData.msg
echo "writting MapPositionData.msg"
#echo "int32 AREA_COORD_X[] =\"forward\"" >> MapPositionData.msg
#echo "int32 AREA_COORD_Y[] =\"backward\"" >> MapPositionData.msg
#echo "int32 AREA_LENGTH_X[] =\"right\"" >> MapPositionData.msg
#echo "int32 AREA_LENGTH_Y[] =\"left\"" >> MapPositionData.msg
#echo "" >> MapPositionData.msg
echo "float32 coord_x" >> MapPositionData.msg
echo "float32 coord_y" >> MapPositionData.msg

# writting NavigationData.msg
echo "writting NavigationData.msg"
echo "float32 coord_x" >> NavigationData.msg
echo "float32 coord_y" >> NavigationData.msg
echo "float32 distance" >> NavigationData.msg
echo "string LEFT =\"left\"" >> NavigationData.msg
echo "" >> NavigationData.msg
echo "string direction" >> NavigationData.msg
echo "string rotation_sense" >> NavigationData.msg
echo "float32 distance_completed" >> NavigationData.msg

# writting SensorData.msg
echo "writting SensorData.msg"
echo "float32 obstacle_distance_forward" >> SensorData.msg
echo "float32 obstacle_distance_backward" >> SensorData.msg
echo "float32 obstacle_distance_side_1" >> SensorData.msg
echo "float32 obstacle_distance_side_2" >> SensorData.msg
echo "float32 angle_delta" >> SensorData.msg
echo "float32 target_deviation_pourcentage" >> SensorData.msg
echo "float32 acceleration" >> SensorData.msg

# writting MotionCommandsData.msg
echo "writting MotionCommandsData.msg"
echo "float32 angle_delta_command" >> MotionCommandsData.msg
echo "float32 distance_motion_command" >> MotionCommandsData.msg
echo "bool emergency_stop" >> MotionCommandsData.msg
echo " # set true occur emergency stop" >> MotionCommandsData.msg
echo " # set false not occur emergency stop" >> MotionCommandsData.msg
echo "float32 target_deviation_pourcentage" >> MotionCommandsData.msg
echo "float32 acceleration" >> MotionCommandsData.msg

# writting HandlingCommandsData.msg
echo "writting HandlingCommandsData.msg"
echo "uint8[2] actuator_pliers_forward" >> HandlingCommandsData.msg
echo "uint8[2] actuator_pliers_backward" >> HandlingCommandsData.msg
echo "uint8 actuator_solar_panel_forward" >> HandlingCommandsData.msg
echo "uint8 actuator_solar_panel_backward" >> HandlingCommandsData.msg
echo "uint8 actuator_level_hand_forward" >> HandlingCommandsData.msg
echo "uint8 actuator_level_hand_backward" >> HandlingCommandsData.msg

# writting ProcessedVideoData.msg
echo "writting ProcessedVideoData.msg"
echo "string SMALL_BLUE_AREA =\"sba\"" >> ProcessedVideoData.msg
echo "string LARGE_BLUE_AREA =\"lba\"" >> ProcessedVideoData.msg
echo "string SMALL_YELLOW_AREA =\"sya\"" >> ProcessedVideoData.msg
echo "string LARGE_YELLOW_AREA =\"lya\"" >> ProcessedVideoData.msg
echo "string SOLAR_PANEL_AREA =\"spa\"" >> ProcessedVideoData.msg
echo "string NORMAL_PLANT =\"np\"" >> ProcessedVideoData.msg
echo "string FRAGILE_PLANT =\"fp\"" >> ProcessedVideoData.msg
echo "string PLANT_UPSIDE_DOWN_RIGHT =\"pudr\"" >> ProcessedVideoData.msg
echo "string PLANT_UPSIDE_DOWN_LEFT =\"pudl\"" >> ProcessedVideoData.msg
echo "string PLANT_UPSIDE_DOWN_FORWARD =\"pudf\"" >> ProcessedVideoData.msg
echo "string PLANT_UPSIDE_DOWN_BACKWARD =\"pudb\"" >> ProcessedVideoData.msg
echo "string OVERTUNED_POT_RIGHT =\"opr\"" >> ProcessedVideoData.msg
echo "string OVERTUNED_POT_LEFT =\"opl\"" >> ProcessedVideoData.msg
echo "string OVERTUNED_POT_FORWARD =\"opf\"" >> ProcessedVideoData.msg
echo "string OVERTUNED_POT_BACKWARD =\"opb\"" >> ProcessedVideoData.msg
echo "string CENTER =\"center\"" >> ProcessedVideoData.msg
echo "" >> ProcessedVideoData.msg
echo "float32 target_deviation_pourcentage" >> ProcessedVideoData.msg
echo "string target_detection" >> ProcessedVideoData.msg
echo "string target_navigation_detection" >> ProcessedVideoData.msg

# writting ActionCommandsData.msg
echo "writting ActionCommandsData.msg"
echo "string SMALL_BLUE_SIDE_BLUE =\"sbsb\"" >> ActionCommandsData.msg
echo "string SMALL_BLUE_SIDE_YELLOW =\"sbsy\"" >> ActionCommandsData.msg
echo "string LARGE_BLUE_AREA =\"lba\"" >> ActionCommandsData.msg
echo "string SMALL_YELLOW_SIDE_BLUE =\"sysb\"" >> ActionCommandsData.msg
echo "string SMALL_YELLOW_SIDE_YELLOW =\"sysy\"" >> ActionCommandsData.msg
echo "string LARGE_YELLOW_AREA =\"lya\"" >> ActionCommandsData.msg
echo "string PLANT_AREA_FORWARD_SIDE_BLUE =\"pafsb\"" >> ActionCommandsData.msg
echo "string PLANT_AREA_BACKWARD_SIDE_BLUE =\"pabsb\"" >> ActionCommandsData.msg
echo "string PLANT_AREA_FORWARD_SIDE_MIDDLE =\"pafsm\"" >> ActionCommandsData.msg
echo "string PLANT_AREA_BACKWARD_SIDE_MIDDLE =\"pabsm\"" >> ActionCommandsData.msg
echo "string PLANT_AREA_FORWARD_SIDE_YELLOW =\"pafsy\"" >> ActionCommandsData.msg
echo "string PLANT_AREA_BACKWARD_SIDE_YELLOW =\"pabsy\"" >> ActionCommandsData.msg
echo "string POT_AREA_FORWARD_SIDE_BLUE =\"Pafsb\"" >> ActionCommandsData.msg
echo "string POT_AREA_BACKWARD_SIDE_BLUE =\"Pabsb\"" >> ActionCommandsData.msg
echo "string POT_AREA_FORWARD_SIDE_MIDDLE =\"Pafsm\"" >> ActionCommandsData.msg
echo "string POT_AREA_BACKWARD_SIDE_MIDDLE =\"Pabsm\"" >> ActionCommandsData.msg
echo "string POT_AREA_FORWARD_SIDE_YELLOW =\"Pafsy\"" >> ActionCommandsData.msg
echo "string POT_AREA_BACKWARD_SIDE_YELLOW =\"Pabsy\"" >> ActionCommandsData.msg
echo "string GARDEN_AREA_FORWARD_SIDE_BLUE =\"gafsb\"" >> ActionCommandsData.msg
echo "string GARDEN_AREA_BACKWARD_SIDE_BLUE =\"gabsb\"" >> ActionCommandsData.msg
echo "string GARDEN_AREA_FORWARD_SIDE_MIDDLE =\"gafsm\"" >> ActionCommandsData.msg
echo "string GARDEN_AREA_BACKWARD_SIDE_MIDDLE =\"gabsm\"" >> ActionCommandsData.msg
echo "string GARDEN_AREA_FORWARD_SIDE_YELLOW =\"gafsy\"" >> ActionCommandsData.msg
echo "string GARDEN_AREA_BACKWARD_SIDE_YELLOW =\"gabsy\"" >> ActionCommandsData.msg
echo "string SOLAR_AREA_BLUE_SIDE_BLUE =\"sabsb\"" >> ActionCommandsData.msg
echo "string SOLAR_AREA_MIDDLE_SIDE_BLUE =\"samsb\"" >> ActionCommandsData.msg
echo "string SOLAR_AREA_YELLOW_SIDE_BLUE =\"saysb\"" >> ActionCommandsData.msg
echo "string SOLAR_AREA_BLUE_SIDE_YELLOW =\"sabsy\"" >> ActionCommandsData.msg
echo "string SOLAR_AREA_MIDDLE_SIDE_YELLOW =\"samsy\"" >> ActionCommandsData.msg
echo "string SOLAR_AREA_YELLOW_SIDE_YELLOW =\"saysy\"" >> ActionCommandsData.msg
echo "string CENTER =\"center\"" >> ActionCommandsData.msg
echo "" >> ActionCommandsData.msg
echo "string target" >> ActionCommandsData.msg
echo "bool emergency_stop" >> ActionCommandsData.msg
echo " # set true occur emergency stop" >> ActionCommandsData.msg
echo " # set false not occur emergency stop" >> ActionCommandsData.msg

# writting .srv files
echo ".srv files builder is processing"
cd ~/robot_workspace/src/data_flow/srv

# writting RemoteControlServiceData.srv
echo "writting RemoteControlServiceData.srv"
echo "string FORWARD =\"forward\"" >> RemoteControlServiceData.srv
echo "string BACKWARD =\"backward\"" >> RemoteControlServiceData.srv
echo "string RIGHT =\"right\"" >> RemoteControlServiceData.srv
echo "string LEFT =\"left\"" >> RemoteControlServiceData.srv
echo "string LOW_LEVEL_SPEED =\"lls\"" >> RemoteControlServiceData.srv
echo "string MEDIUM_LEVEL_SPEED =\"mls\"" >> RemoteControlServiceData.srv
echo "string MAX_LEVEL_SPEED =\"Mls\"" >> RemoteControlServiceData.srv
echo "string STOP =\"stop\"" >> RemoteControlServiceData.srv
echo "string order" >> RemoteControlServiceData.srv
echo "---" >> RemoteControlServiceData.srv
echo "bool response" >> RemoteControlServiceData.srv

# writting StrategyServiceData.srv
echo "writting StrategyServiceData.srv"
echo "string STRATEGY_A =\"a\"" >> StrategyServiceData.srv
echo "string STRATEGY_B =\"b\"" >> StrategyServiceData.srv
echo "string STRATEGY_C =\"c\"" >> StrategyServiceData.srv
echo "string STRATEGY_D =\"d\"" >> StrategyServiceData.srv
echo "string STRATEGY_E =\"e\"" >> StrategyServiceData.srv
echo "string STRATEGY_F =\"f\"" >> StrategyServiceData.srv
echo "string STRATEGY_G =\"g\"" >> StrategyServiceData.srv
echo "string STRATEGY_H =\"h\"" >> StrategyServiceData.srv
echo "string STRATEGY_I =\"i\"" >> StrategyServiceData.srv
echo "string STRATEGY_J =\"j\"" >> StrategyServiceData.srv
echo "string STRATEGY_K =\"k\"" >> StrategyServiceData.srv
echo "string STRATEGY_L =\"l\"" >> StrategyServiceData.srv
echo "string STRATEGY_M =\"m\"" >> StrategyServiceData.srv
echo "string STRATEGY_N =\"n\"" >> StrategyServiceData.srv
echo "string STRATEGY_O =\"o\"" >> StrategyServiceData.srv
echo "string STRATEGY_P =\"p\"" >> StrategyServiceData.srv
echo "string STRATEGY_Q =\"q\"" >> StrategyServiceData.srv
echo "string STRATEGY_R =\"r\"" >> StrategyServiceData.srv
echo "string STRATEGY_S =\"s\"" >> StrategyServiceData.srv
echo "string STRATEGY_T =\"t\"" >> StrategyServiceData.srv
echo "string SUCCESS_RESPONSE =\"order received\"" >> StrategyServiceData.srv
echo "string ERROR_RESPONSE =\"order not received\"" >> StrategyServiceData.srv
echo "string order" >> StrategyServiceData.srv
echo "---" >> StrategyServiceData.srv
echo "string response" >> StrategyServiceData.srv

# writting .action files
echo ".action files builder is processing"
cd ~/robot_workspace/src/data_flow/action

# writting Brain.action
echo "writting Brain.action"
echo "# writting Brain.action" >> Brain.action
echo "string FORWARD =\"forward\"" >> Brain.action
echo "string BACKWARD =\"backward\"" >> Brain.action
echo "" >> Brain.action
echo "string SMALL_BLUE_SIDE_BLUE =\"sbsb\"" >> Brain.action
echo "string SMALL_BLUE_SIDE_YELLOW =\"sbsy\"" >> Brain.action
echo "string LARGE_BLUE_AREA =\"lba\"" >> Brain.action
echo "string SMALL_YELLOW_SIDE_BLUE =\"sysb\"" >> Brain.action
echo "string SMALL_YELLOW_SIDE_YELLOW =\"sysy\"" >> Brain.action
echo "string LARGE_YELLOW_AREA =\"lya\"" >> Brain.action
echo "string PLANT_AREA_FORWARD_SIDE_BLUE =\"pafsb\"" >> Brain.action
echo "string PLANT_AREA_BACKWARD_SIDE_BLUE =\"pabsb\"" >> MotionCommands.action
echo "string PLANT_AREA_FORWARD_SIDE_MIDDLE =\"pafsm\"" >> MotionCommands.action
echo "string PLANT_AREA_BACKWARD_SIDE_MIDDLE =\"pabsm\"" >> MotionCommands.action
echo "string PLANT_AREA_FORWARD_SIDE_YELLOW =\"pafsy\"" >> MotionCommands.action
echo "string PLANT_AREA_BACKWARD_SIDE_YELLOW =\"pabsy\"" >> MotionCommands.action
echo "string POT_AREA_FORWARD_SIDE_BLUE =\"Pafsb\"" >> MotionCommands.action
echo "string POT_AREA_BACKWARD_SIDE_BLUE =\"Pabsb\"" >> MotionCommands.action
echo "string POT_AREA_FORWARD_SIDE_MIDDLE =\"Pafsm\"" >> MotionCommands.action
echo "string POT_AREA_BACKWARD_SIDE_MIDDLE =\"Pabsm\"" >> MotionCommands.action
echo "string POT_AREA_FORWARD_SIDE_YELLOW =\"Pafsy\"" >> MotionCommands.action
echo "string POT_AREA_BACKWARD_SIDE_YELLOW =\"Pabsy\"" >> MotionCommands.action
echo "string GARDEN_AREA_FORWARD_SIDE_BLUE =\"gafsb\"" >> MotionCommands.action
echo "string GARDEN_AREA_BACKWARD_SIDE_BLUE =\"gabsb\"" >> MotionCommands.action
echo "string GARDEN_AREA_FORWARD_SIDE_MIDDLE =\"gafsm\"" >> MotionCommands.action
echo "string GARDEN_AREA_BACKWARD_SIDE_MIDDLE =\"gabsm\"" >> MotionCommands.action
echo "string GARDEN_AREA_FORWARD_SIDE_YELLOW =\"gafsy\"" >> MotionCommands.action
echo "string GARDEN_AREA_BACKWARD_SIDE_YELLOW =\"gabsy\"" >> MotionCommands.action
echo "string SOLAR_AREA_BLUE_SIDE_BLUE =\"sabsb\"" >> MotionCommands.action
echo "string SOLAR_AREA_MIDDLE_SIDE_BLUE =\"samsb\"" >> MotionCommands.action
echo "string SOLAR_AREA_YELLOW_SIDE_BLUE =\"saysb\"" >> MotionCommands.action
echo "string SOLAR_AREA_BLUE_SIDE_YELLOW =\"sabsy\"" >> MotionCommands.action
echo "string SOLAR_AREA_MIDDLE_SIDE_YELLOW =\"samsy\"" >> MotionCommands.action

# writting MotionCommands.action
echo "writting MotionCommands.action"
echo "# writting MotionCommands.action" >> MotionCommands.action
echo "string target" >> MotionCommands.action
echo "bool emergency_stop" >> MotionCommands.action
echo "# set true occur emergency stop" >> MotionCommands.action
echo "# set false not occur emergency stop" >> MotionCommands.action
echo ""
echo "# part1: the goal" >> MotionCommands.action
echo "string order" >> MotionCommands.action
echo "---" >> MotionCommands.action
echo "# part2: the result" >> MotionCommands.action
echo "string target_reached" >> MotionCommands.action
echo "string order_reached" >> MotionCommands.action
echo "float32 final_angle_delta_completed" >> MotionCommands.action
echo "float32 final_distance_completed" >> MotionCommands.action
echo "---" >> MotionCommands.action
echo "# part3: the feedback" >> MotionCommands.action
echo "float32 coord_x" >> MotionCommands.action
echo "float32 coord_y" >> MotionCommands.action
echo "float32 current_angle_delta" >> MotionCommands.action
echo "float32 current_distance_completed" >> MotionCommands.action

# writting ActuatorCommands.action
echo "writting ActuatorCommands.action"
echo "# writting ActuatorCommands.action" >> ActuatorCommands.action
echo ""
echo "# part1: the goal" >> ActuatorCommands.action
echo "string actuatorData" >> ActuatorCommands.action
echo "---" >> ActuatorCommands.action
echo "# part2: the result" >> ActuatorCommands.action
echo "bool action_reached" >> ActuatorCommands.action
echo "# if true action occur" >> MotionCommands.action
echo "# if false action not occur" >> MotionCommands.action
echo "---" >> ActuatorCommands.action
echo "# part3: the feedback" >> ActuatorCommands.action
echo "bool feedback" >> ActuatorCommands.action
echo "# if true action is occurring" >> MotionCommands.action
echo "# if false action is not occuring" >> MotionCommands.action

# writting SensorFeedback.action
echo "writting SensorFeedback.action"
echo "# writting SensorFeedback.action" >> SensorFeedback.action
echo "# part1: the goal" >> SensorFeedback.action
echo "bool stateSensor" >> SensorFeedback.action
echo "# if true start sensor" >> SensorFeedback.action
echo "# if false stop sensor" >> SensorFeedback.action
echo "---" >> SensorFeedback.action
echo "# part2: the result" >> SensorFeedback.action
echo "bool stateSensor" >> SensorFeedback.action
echo "# if true sensor online" >> SensorFeedback.action
echo "# if false sensor outline" >> SensorFeedback.action
echo "---" >> SensorFeedback.action
echo "# part3: the feedback" >> SensorFeedback.action
echo "string sensorData" >> SensorFeedback.action

