#!/bin/sh
cd  ~/robot_workspace/src/main_package/main_package

