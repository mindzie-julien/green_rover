import serial
import time
import json

ser = serial.Serial("/dev/ttyACM0", 19200, timeout=1)
time.sleep(1)
ser.reset_input_buffer()
"""def sendData(){
	
}

def getData(){
	
}"""

while True:

	time.sleep(0.1)
	data = '{"cleaner":"cleaner", "distance":100, "angle":360}'
	msg = json.dumps(data)
	ser.write(msg.encode('utf-8'))
	while ser.in_waiting <= 0:
		time.sleep(0.01)
	ack = ser.readline().decode('utf-8').rstrip()
	print(ack)
	#ser.close()
	"""ser = serial.Serial("/dev/ttyACM0", 19200, timeout=1)
	ack = ser.readline(500).decode('utf-8')
	print(ack)
	ser.close()"""
